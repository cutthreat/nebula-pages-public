# Figma Scalper Control Plane (Nebula GPT)

## Цель
- Передать управление Figma-экспортом в воспроизводимый инструментальный контур.
- Делать экспорт глубже ручного: полный индекс узлов, компонентные/стилевые инвентори, граф прототипа, трассируемые логи.

## Точка запуска
1. Поднять сервис:
   - `H:\GPT-Codex\tools\figma-scalper-chrome\start-figma-scalper-service.cmd`
2. Запустить deep-экспорт проекта:
   - `H:\Nebula\GPT\tools\run_figma_scalper_deep.cmd`

## Конфиг проекта
- `H:\Nebula\GPT\figma-manifest\figma-target.json`
- Поля:
  - `figmaUrl`
  - `mode` (`deep`)
  - `outputRoot`
  - `serviceUrl`
  - `enableResume`

## Что создаётся
- `H:\Nebula\GPT\figma-export\last-scalper-run.json`
- `H:\Nebula\GPT\figma-export\figma-scalper-ops.log.jsonl`
- `H:\Nebula\GPT\figma-export\scalper\<timestamp>-<filekey>\...`
  - `figma-manifest.json`
  - `figma-screens\...`
  - `maps\figma-state-map.json`
  - `qa\quality-gates.json`
  - `qa\run-summary.json`
  - `deep\node-index.json/csv`
  - `deep\prototype-graph.json/csv`
  - `deep\components-inventory.json`
  - `deep\styles-inventory.json`
  - `qa\playwright-snapshot-log.jsonl` (если включен snapshot fallback)

## Эксплуатационные правила
- Для baseline-захвата использовать только `mode=deep`.
- Не открывать `popup.html` напрямую через `file://`, только через popup расширения.
- Проверять сервис перед запуском:
  - `H:\GPT-Codex\tools\figma-scalper-chrome\diagnose-figma-scalper.cmd`
- Если Figma API не отдаёт скриншоты (timeout/502), использовать snapshot fallback:
  - `autoSnapshotMissingScreenshots=true` в `figma-target.json`
  - при необходимости задать `playwrightStorageState` (файл авторизованного состояния)
  - получить state-файл:
    - `H:\Nebula\GPT\tools\capture-playwright-state.cmd`

## Критерий готовности
- Есть успешный `extract_ok` в `figma-scalper-ops.log.jsonl`.
- Есть валидный `last-scalper-run.json` с путём `output_dir`.
- Есть `deep` артефакты (node/prototype/components/styles).

## Accepted 1:1 Reference Rules
- Deep export is the source package; local `_unzipped/img/breakpoints` PNGs are only cached references derived from it.
- If a local reference PNG is missing, inspect `figma-manifest/oracle-ethalon-pack-*.json` and `figma-screens/**/screenshot.png` before reporting a missing Figma ethalon.
- For each accepted page, keep a page reference map that records file key, version ref, breakpoint, node id, Figma name, local cache path, and source screenshot path.
- If several nodes match the same breakpoint, select the canonical one from the page/job contract and adjacent-breakpoint continuity, then record the rejected node in the map.
