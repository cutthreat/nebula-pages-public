# Figma Screen Spec Template

## Identity
- Screen name:
- Node ID:
- Screen order:
- Target viewport:
- Reference export file:

## Source References
- Figma file key:
- Figma version ref:
- Reference map file:
- Breakpoint references:
  - 1200:
  - 992:
  - 768:
  - 576:
  - 320:
- Alternate/rejected nodes:
- Acceptance blocker, if any:

## Layout
- Root container:
- Section order:
- Grid system:
- Key spacing values:
- Alignment notes:

## Typography
- Fonts:
- Heading sizes:
- Body sizes:
- Line heights:
- Weights:
- Letter spacing:

## Colors
- Backgrounds:
- Text colors:
- Accent colors:
- Border colors:
- Shadow / effects:

## Assets
- Images:
- SVGs:
- Icons:
- Background patterns:
- Export format:

## Interactions
- Hover:
- Active:
- Focus:
- Open / closed states:
- Carousel / slider behavior:
- Accordion / modal behavior:

## Responsive
- Desktop behavior:
- Tablet behavior:
- Mobile behavior:
- Breakpoint-specific differences:

## Notes
- Anything not obvious from the export:
- Any baseline reuse requirements:
- Any do-not-change rules:
