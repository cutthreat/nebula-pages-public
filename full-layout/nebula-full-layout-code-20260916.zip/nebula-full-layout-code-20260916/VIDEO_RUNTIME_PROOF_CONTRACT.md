# Video Runtime Proof Contract

## Purpose
- Prove interactive behavior that static screenshots cannot prove.
- Keep runtime/video evidence separate from canonical Figma/export geometry truth.

## Use For
- menu open/close
- accordion expand/collapse
- hover and focus transitions
- theme toggle
- sticky/fixed header behavior
- lazy image reveal
- scroll-triggered motion or visibility changes

## Do Not Use For
- replacing accepted Figma/export screenshots
- proving typography or spacing when a static export already exists
- hiding source-truth gaps behind a polished runtime video

## Minimum Artifact Set
- target URL
- viewport
- scenario id
- start state
- action sequence
- expected end state
- output video or frame sequence
- key still frames
- console/page error status
- timestamp and build/ref identity

## Required Scenarios
1. `menu-open-close`
2. `accordion-open-close`
3. `hover-focus-controls`
4. `theme-toggle`
5. `scroll-sticky-lazy-assets`

## Acceptance Rule
- Runtime/video proof can confirm behavior.
- Runtime/video proof cannot override a red source-truth or export-truth gate.

## Preferred Lane
- Manhattan or the local browser capture lane should record these scenarios from the real page route.
