# Nebula AGENTS

## Instruction Ownership and Lightweight Bootstrap

- Canonical contour contract: H:\GPT-Codex\.ops\docs\playbooks\CODEX-INSTRUCTION-HIERARCHY-CONTRACT.md. GPT-Codex owns interaction/native execution; Manhattan owns external execution; AI Hub owns other-LLM coordination; the owning project retains its domain and acceptance.
- Resolve project identity, read the applicable canonical AGENTS and Project Atlas entrypoint/registry, then run H:\GPT-Codex\tools\Resolve-ProjectAtlasContext.ps1 with the task text. Load only selected blocks/scenario and required source refs; do not reread unchanged context.
- These rules govern this project only. Child AGENTS adds local constraints without granting broader permissions. A service dependency is not a transfer of final product ownership; an unregistered Hub is not a requirement to create a new user task.


- Current Nebula implementation root is `F:\CodexProjects\confideline-nebula\implementation\nebula-gpt`. For page/code/Figma/export/compare-board work, use this root as the primary source of truth.
- `H:\GPT-Codex` is shared Codex Hub/global ops/knowledge/governance. Use it for route cards, knowledge intake, verifiers, skills, and Head registries, not as the primary Nebula implementation workspace.
- Figma operator contour for this project lives at `F:\CodexProjects\confideline-nebula\implementation\nebula-gpt\docs\oracle-nebula\ORACLE-NEBULA-FIGMA-OPERATOR-CONTOUR.md` with machine registry `F:\CodexProjects\confideline-nebula\implementation\nebula-gpt\figma-manifest\oracle-nebula-figma-operator-contour.registry.json`.

- For tasks resolved to this Nebula implementation (including its page-readiness / product-strategy / parity work), run the Nebula knowledge intake from `H:\GPT-Codex`:
  1. `H:\GPT-Codex\.ops\docs\projects\NEBULA-MASTER.md`.
  2. `H:\GPT-Codex\.ops\knowledge\nebula\00-DASHBOARD.md`.
  3. `H:\GPT-Codex\.ops\knowledge\nebula\answers\00-ANSWER-CARDS.md` plus the relevant answer card.
  4. `H:\GPT-Codex\.ops\knowledge\nebula\quality\00-QUALITY-GATE.md`.
  5. Current source files, runtime artifacts, Figma/source proof, and verifier output for the exact task.
- Obsidian is an advisory navigation layer, not source truth. Close Nebula tasks only from current repo/runtime/verifier evidence plus the consulted knowledge route.
- For Figma/CSS/responsive/compare-board/visual parity tasks, also read `docs/oracle-nebula/CODEX_OPERATING_CONTRACT.md` and follow `H:\GPT-Codex\.ops\docs\playbooks\ORACLE-NEBULA-SKILL-WHITELIST-ROUTING.md`.
- Preserve the reference bundle and the established screen order.
- Do not change approved blocks unless the task explicitly targets them.
- Keep browser-export artifacts in the documented folders.
- If a Figma extraction is blocked, document the blocker instead of inventing structure.
- Include changed files, visual risks, and validation notes in every substantial change.
- Micro BG/surface tolerance: when a residual background/surface mismatch is small and not human-visible, use an exact Figma BG/panel asset if available; otherwise limit repair to 2-3 source-backed attempts. If those attempts do not materially improve the result, record the measured residual as `non_blocking_visual_tolerance` and move the region/screen forward instead of continuing CSS tuning.
- CSS bloat guard: page CSS growth is an alarm. Run the CSS bloat guard for substantial CSS work; if growth crosses warning, inspect source/component ownership before more CSS. If growth crosses alarm/stop without a source-backed justification, stop blind CSS tuning and switch to exact Figma assets, accepted heritage components, owner-level repair, or stale CSS removal/replacement.

## Oracle / NEBULA Source-Paint Contract

- Before any auth/Figma parity repair, read `docs/oracle-nebula/CODEX_OPERATING_CONTRACT.md`.
- Do not tune colors, gradients, opacity, shadows, social icons, panels, or button fills by eye.
- If a CSS paint value exists because a Figma-exported carrier is transparent, annotate it with a `source:` comment that names the Figma frame/export proof.
- Run `tools/verify_auth_paint_source_contract.ps1` before showing or closing auth compare-board work.
- User screenshots and compare-board screenshots are defect evidence only; implementation source must be Figma export, source asset, node map, or documented source-derived proof.


## Project-scoped application secrets

- Namespace: nebula; use only %LOCALAPPDATA%\Codex\project-secrets\nebula\secrets.env.
- Use the approved wrapper and keep values out of chat, logs, memory, proofs, screenshots, arguments, source control, and backups.
- This is not permission to handle cookies, OAuth/session tokens, browser profiles, VPN/OpenAI routes, payment credentials, or raw runtime dumps.
- Contract: H:\GPT-Codex\.ops\docs\playbooks\PROJECT-SECRET-HANDLING-CONTRACT.md.

<!-- CODEX_AGENTS_EOF:nebula -->
