# Figma to LLM Verstka Benchmark

## Purpose
- Compare the NEBULA 1:1 contour against current Figma-to-code and LLM-assisted frontend practices.
- Convert useful external patterns into local, verifiable gates.
- Avoid copying vendor promises that do not improve accepted_1to1 fidelity.

## Current Market Patterns

### Figma MCP + Code Connect
- Figma MCP is strongest as design context, not as production code output.
- Code Connect improves LLM output by mapping design components to real code components and component-specific instructions.
- Useful local equivalent: `figma-manifest/nebula-code-component-map.json` plus `tools/audit_figma_component_mapping.ps1`.
- Sources: Figma Code Connect introduction, Figma MCP Code Connect integration, Figma MCP catalog.

### Figma Make / v0 / Prompt-to-App Tools
- Strong for interactive prototypes, fast ideation, and point-and-edit iteration.
- Not sufficient as final source truth for NEBULA accepted_1to1 because generated code must still be adapted to project patterns, assets, and runtime behavior.
- Useful local equivalent: keep prototype/control references diagnostic-only unless they are frozen as explicit Figma/export references.
- Sources: Figma design-to-code / Figma Make product page.

### Builder Visual Copilot / Anima / Locofy
- Strong patterns:
  - component mapping to existing code
  - code-style adaptation
  - responsive/autolayout awareness
  - interaction extraction from Figma prototypes
- Weakness for NEBULA:
  - generated code still needs project-specific cascade, breakpoint, asset, and runtime verification.
- Useful local equivalent: owner map, reference maps, layout capture, accordion contract, breakpoint compare.
- Sources: Builder Figma-to-code visual editor docs, Locofy Lightning docs.

### Research Direction
- Recent UI-to-code research emphasizes semantic block segmentation, reusable components, and element-wise feedback.
- NEBULA already has detector-first QA, but needs stronger reusable component ownership and pattern-level feedback loops.

## NEBULA Strengths
- Fail-close source contract: Figma/export reference maps are required for accepted_1to1.
- Diagnostic layers are correctly separated from acceptance truth.
- Capture contract handles lazy images and fixed/sticky artifacts.
- Readiness audit decomposes the contour into docs, source, runtime, syntax, preview, capture, compare, and learning.
- Accordion and interaction contracts exist for common static-screenshot failure modes.

## NEBULA Gaps Closed In This Pass
- Added a local Code Connect-like component/code owner map.
- Added a component mapping audit that classifies all current unmapped Figma publishables.
- Integrated component mapping into the full 1:1 readiness audit.

## Remaining Improvement Backlog
- Add page-specific Figma compare smoke, not only Home 1200, for the page being worked on.
- Add token drift audit: collect CSS custom properties, font families, radii, shadows, gradients, and compare against Figma/export token inventory.
- Add interaction state capture for hover/focus/theme/menu states, not only static card captures.
- Add per-page owner graph: HTML/CSS/JS files, late cascade owners, source refs, verifier commands, accepted status.
- Add semantic segmentation helper for long pages: detect repeated cards/sections and require shared owner repair when the same pattern recurs.

## Operating Rule
- Use external tools and patterns as inspiration, not as authority.
- For NEBULA, accepted_1to1 requires source map + owner map + focused detector + breakpoint/capture proof.

## Source Links
- Figma Code Connect: https://developers.figma.com/docs/code-connect/
- Figma MCP Code Connect integration: https://developers.figma.com/docs/figma-mcp-server/code-connect-integration/
- Figma MCP catalog: https://www.figma.com/mcp-catalog/
- Figma design-to-code / Make: https://www.figma.com/solutions/design-to-code/
- Locofy Lightning: https://www.locofy.ai/docs/lightning/
- Builder Figma-to-code visual editor: https://site.builder.io/c/docs/figma-to-code-visual-editor
