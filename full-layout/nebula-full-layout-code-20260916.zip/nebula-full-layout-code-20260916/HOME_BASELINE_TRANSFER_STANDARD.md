# Home Baseline Transfer Standard

Updated: 2026-05-13

## Result
Home is the human-approved implementation baseline for NEBULA layout work, but it must be transferred as a process, not copied as raw CSS.

Full workspace playbook:

`H:\GPT-Codex\.ops\docs\playbooks\ORACLE-NEBULA-HOME-BASELINE-FAST-VERSTKA-STANDARD-2026-05-13.md`

## What Home Proves
- Source truth is frozen per breakpoint in `_unzipped\img\breakpoints\home-reference-map.json`.
- The accepted breakpoint set is `1200 / 992 / 768 / 576 / 320`.
- Home has hierarchy maps, selector maps, screen contracts, reverse contracts, shell drift summary, and screen audits under `H:\GPT-Codex\artifacts\`.
- The real code pattern is semantic HTML, Bootstrap 4.6 primitives, BEM-like selectors, `Manrope`, real controls, and separate CSS/JS files.
- Runtime states are part of the contract: menu, FAQ accordion, video, slider, sticky header, theme.

## Required Before New Page Work
Do not start CSS/HTML implementation unless the target page has:

1. reference map or explicit Figma/source blocker;
2. Figma hierarchy map for the selected breakpoint;
3. section selector map;
4. layer-stack plan for source-backed layers;
5. reverse page or screen contract;
6. known target files;
7. exact verifier commands;
8. stop condition after repeated failed candidates.

## Fast Path
1. Freeze `page + breakpoint + Figma node`.
2. Build source/hierarchy/selector/layer artifacts.
3. Write a one-page 1:1 blueprint: shell, grid, type, assets, runtime states, breakpoints.
4. Patch one owner class only: source, verifier, shell, grid, component, asset, typography, runtime, or cascade.
5. Verify the owner lane first, then run visual proof.
6. If two candidate families fail, stop tuning and run blocker diagnosis.

## Core Commands
```powershell
$workspaceRoot = (Get-Location).Path
powershell -ExecutionPolicy Bypass -File (Join-Path $workspaceRoot 'tools\test_visual_contour_contract.ps1') -WorkspaceRoot $workspaceRoot
powershell -ExecutionPolicy Bypass -File (Join-Path $workspaceRoot 'tools\audit_figma_component_mapping.ps1') -WorkspaceRoot $workspaceRoot
powershell -ExecutionPolicy Bypass -File (Join-Path $workspaceRoot 'tools\audit_figma_handoff_contract.ps1') -WorkspaceRoot $workspaceRoot
```

В исходном checkout исторический путь `H:\Nebula\GPT` встречается только как provenance; в распакованном transfer-пакете используйте `$workspaceRoot` и соответствующий каталог `TOOLS/`.

Bounded Home runtime proof:

```powershell
$env:NODE_PATH='C:\Users\alexe\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\node_modules'
& 'C:\Users\alexe\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe' H:\Nebula\GPT\tools\verify_runtime_state_proof.js --spec H:\Nebula\GPT\tools\runtime-proof-specs\home.runtime-proof.json --scenario accordion-open-close --strict
```

## Non-Negotiable
No page is `accepted_1to1` from visual similarity alone. It must be source-backed, owner-classified, breakpoint-verified, and runtime-checked where state exists.
