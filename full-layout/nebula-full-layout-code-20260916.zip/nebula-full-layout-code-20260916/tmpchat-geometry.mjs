import { chromium } from 'file:///C:/Users/alexe/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';
const b = await chromium.launch({headless:true});
for (const w of [1200,992,768,576,320]) {
 const p = await b.newPage({viewport:{width:w,height:900}});
 await p.goto('http://127.0.0.1:4180/nebula-account/chatroom.html');
 await p.waitForTimeout(100);
 const d = await p.evaluate(()=>{const q=s=>{const e=document.querySelector(s);if(!e)return null;const r=e.getBoundingClientRect();return {x:r.x,y:r.y,w:r.width,h:r.height,right:r.right,bottom:r.bottom,display:getComputedStyle(e).display,position:getComputedStyle(e).position,z:getComputedStyle(e).zIndex}}; const b=document.querySelector('[data-consultation-control]'); const r=b.getBoundingClientRect(); return {button:q('[data-consultation-control]'),head:q('.c76-chat-head'),identity:q('.c76-chat-identity'),actions:q('.c76-chat-actions'),favorite:q('[data-chat-action=favorite]'),search:q('[data-chat-action=search]'),more:q('[data-chat-action=more]'),center:document.elementFromPoint(r.left+r.width/2,r.top+r.height/2)?.outerHTML.slice(0,80),scrollWidth:document.documentElement.scrollWidth,innerWidth:innerWidth}});
 console.log(JSON.stringify({w,...d})); await p.close();
}
await b.close();
