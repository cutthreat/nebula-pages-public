# Auth Slice Execution Contract

Updated: 2026-05-03

## Goal
Bring the first auth slice to a verifiable Oracle / NEBULA workflow before broad page production:

1. LOG in 1200+
2. FORGOT YOUR PASSWORD 1200+
3. Sign in CREATE 1200+
4. Sign in 2 STEP 1200+

## Facts
- Canonical implementation root: `H:\Nebula\GPT\_unzipped`.
- Preview server: `http://127.0.0.1:4175`.
- Login has source-ready review manifest:
  - page: `_unzipped/login.html`
  - node: `366:1100`
  - manifest: `_unzipped/login-review-manifest.json`
  - reference: `_unzipped/img/login-figma-reference.png`
- Forgot password has source-ready review manifest:
  - page: `_unzipped/auth-forgot-new.html`
  - node: `375:1160`
  - manifest: `_unzipped/forgot-review-manifest.json`
  - references: `_unzipped/img/forgot-proto-frame.png`, `_unzipped/img/forgot-export-raster.png`, `_unzipped/img/forgot-export-source.svg`
- Signup create and signup step 2 currently have weak specs only:
  - `_unzipped/signup-step-1.html`
  - `_unzipped/signup-step-2.html`
  - `figma-export/20260326-135858/screen-specs/signup-step-1/01-na-auth-page-panel.json`
  - `figma-export/20260326-135858/screen-specs/signup-step-2/01-na-auth-page-panel.json`

## Current Decision
- Start production repair with Login and Forgot password because their source truth is usable.
- Do not claim 1:1 readiness for Signup create or Signup step 2 until a full-screen 1200+ Figma/reference capture exists.
- Use `signup-step-1.html` and `signup-step-2.html` as canonical signup pages.
- Treat `auth-create-new.html` and `auth-step2-new.html` as legacy aliases, not canonical targets.
- Signup Step 2 has been provisionally aligned with the weak local spec by adding the missing legal consent and product-updates consent text. This is a spec-debt repair, not Figma parity acceptance.

## Implemented Guardrails
- Auth contract: `_unzipped/auth-screen-contract.json`
- Verification script: `tools/verify_auth_slice_contract.ps1`
- Signup source-truth finder: `tools/find_auth_signup_source_truth.ps1`
- Signup source-truth importer: `tools/import_auth_signup_source_truth.ps1`
- Control board: `_unzipped/auth-slice-control-board.html`
- Compare board: `_unzipped/auth-compare-board.html`
- Login root has `data-figma-id="366:1100"`.
- Forgot password root has `data-figma-id="375:1160"`.
- Signup step 2 Previous step link points to `signup-step-1.html`, not stale `auth-create-new.html`.
- Legacy alias pages `auth-create-new.html` and `auth-step2-new.html` are redirect shims to canonical `signup-step-1.html` and `signup-step-2.html`; they no longer contain parallel live forms.
- The auth contract binds the latest source-ready visual proof report and the verifier checks that it exists, has `pass`, and covers Login/Forgot.
- The visual runner now reads source-ready screens from `_unzipped/auth-screen-contract.json` instead of hardcoding only Login/Forgot.
- The verifier rejects too-small source-ready visual references, preventing component/card exports from being promoted to full-screen auth truth.
- The verifier blocks auth HTML/CSS `data:image`, inline `style=`, and `!important`; current auth slice has zero hits for these patterns.
- Surface parity signals: `_unzipped/auth-surface-signals.json`
- Surface parity gate: `tools/verify_auth_surface_parity.ps1`
- The surface parity gate normalizes Figma/reference rasters to the selected 1200-plane before comparison. It checks the light panel bbox, key purple controls, and fixed background/glow RGB sample points. This prevents a 2x source image, wrong root plane, missing glow, or 1280px prototype frame from passing as a 1200+ implementation.
- Responsive smoke gate: `tools/verify_auth_responsive_smoke.ps1`
- The responsive smoke gate captures source-ready auth pages at `1200/992/768/576/320`, blocks blank renders and horizontal overflow, and produces an overview board. It is not a replacement for breakpoint-specific Figma parity when breakpoint exports are missing.
- Control board proof screenshot: `_unzipped/visual-review/auth-slice-control-board-20260503.png`
- Compare board proof screenshot: `_unzipped/visual-review/auth-compare-board-20260503.png`

## Verification
Run:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File H:\Nebula\GPT\tools\verify_auth_slice_contract.ps1
```

Expected current result:

```json
{
  "status": "blocked",
  "sourceReadyScreens": ["login", "forgot-password"],
  "sourceBlockedScreens": ["signup-create", "signup-step-2"],
  "issueCount": 0
}
```

`blocked` is intentional: it prevents false readiness while allowing source-ready screens to proceed.

For source-ready visual measurement, run:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File H:\Nebula\GPT\tools\verify_auth_surface_parity.ps1
```

This produces current live PNGs, normalized reference PNGs, amplified diff PNGs, and `auth-surface-parity-report.json`.

When the source reference changes, regenerate the extracted signal map first:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File H:\Nebula\GPT\tools\verify_auth_surface_parity.ps1 -UpdateSignals -NoFail
```

For Signup/Create source-truth intake, run:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File H:\Nebula\GPT\tools\find_auth_signup_source_truth.ps1 -TryFigmaApi
```

Expected current result: `blocked`. The finder confirms weak local specs, false `93.4% Accuracy` card exports, and current Figma API `404` for known file keys.

When real full-screen signup refs are available, dry-run the import first:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File H:\Nebula\GPT\tools\import_auth_signup_source_truth.ps1 `
  -SignupCreateNodeId "<figma-node-id>" `
  -SignupCreateReferencePath "<full-screen-create-reference.png>" `
  -SignupStep2NodeId "<figma-node-id>" `
  -SignupStep2ReferencePath "<full-screen-step2-reference.png>"
```

Only if the dry-run validates full-screen references, repeat with `-Apply`. The importer copies reference assets, writes review manifests, sets root `data-figma-id`, updates the contract to `source_ready`, and expands visual proof required keys.

For source-ready responsive smoke across all supported breakpoints, run:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File H:\Nebula\GPT\tools\verify_auth_responsive_smoke.ps1
```

This produces live screenshots for `1200/992/768/576/320`, `auth-responsive-smoke-report.json`, and `auth-responsive-smoke-board.png`.

Current source-ready pass run:

- folder: `_unzipped/visual-review/auth-surface-parity-20260503-015619`
- status: `pass` for source-ready screens only
- Login: normalized reference `2560x1710 -> 1200x802`, panel delta `0`, components `pass`, surface samples `pass`
- Forgot password: normalized reference `1280x855 -> 1200x802`, panel delta `0`, components `pass`, surface samples `pass`
- Capture detail: Chrome headless on Windows is captured as raw viewport plus browser chrome compensation and cropped to the common `1200x855` comparison plane.
- responsive smoke folder: `_unzipped/visual-review/auth-responsive-smoke-20260503-015619`
- responsive smoke status: `pass` for Login/Forgot at `1200/992/768/576/320`
- provisional all-auth smoke folder: `_unzipped/visual-review/auth-responsive-smoke-20260503-020005`
- provisional all-auth smoke status: `pass` for Login/Forgot/Create/Step2 at `1200/992/768/576/320`; Create/Step2 remain source-blocked for parity.

## Next Packages

### P0
- Regenerate current live screenshots for Login and Forgot at 1200+.
- Compare against the source references.
- Convert concrete visual deltas into bounded repair tasks.
- Keep Create/Step2 in source-blocked mode unless real references are found.

### P1
- Add full-screen source truth for Signup create and Signup step 2.
- Add root `data-figma-id` only after real node ids are known.
- Add review manifests for both signup screens.
- Do not use nodes `917:20580`, `883:15282`, `893:12242`, or `462:2637` as signup screen references; Figma API export proved they are `93.4% Accuracy` cards.

### P2
- Done: duplicated legacy auth pages are explicit redirects to canonical signup pages.
- Extend the auth gate to check stale links across all pages that enter signup.
- Add DOM coverage once full Figma hierarchy maps exist for the four screens.
