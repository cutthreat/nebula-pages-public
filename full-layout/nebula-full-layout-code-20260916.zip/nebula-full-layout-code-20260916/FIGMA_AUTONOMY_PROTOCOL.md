# Figma Autonomy Protocol

## Objective
- Build pages and sections from Figma with minimal human prompting.
- Use Figma as the source of truth.
- Use the approved Neuro Home and release `1.0` as the implementation baseline.
- Verify every change with local rendering before moving on.

## Core Principle
- Do not guess from memory.
- Do not infer hidden details from semantics if the Figma order or export shows the screen explicitly.
- Do not advance to the next screen until the current screen is verified.
- Do not infer that Figma lacks a breakpoint because a local PNG cache file is absent. Search the export manifest and `figma-screens` package first.

## What We Use
- Figma MCP as the primary extraction layer
- Figma Scalper Deep (project-bound API extraction with deep node graph/index)
- Dev Mode / exports as the reference layer
- Local static render + Playwright screenshots as the verification layer
- Existing project code as the implementation layer
- Optional external AI review tools only as a fallback critique layer, not as the primary source of truth

## Source-of-Truth Gate
1. Primary: exact Figma/export screenshot and node metadata for the target page and breakpoint.
2. Traceability: `figma-manifest/oracle-ethalon-pack-*.json`, `figma-export/**/figma-screens/**/screen.json`, and `screenshot.png`.
3. Local cache: `_unzipped/img/breakpoints/<page>-<breakpoint>-reference.png` is only a cached copy derived from the export.
4. Diagnostic layer: Pavlo/control page, Layout Capture Card, compare-board overlays, and implementation screenshots are useful for finding drift, but they are not accepted references.
5. Acceptance: `accepted_1to1` requires a recorded reference map for every required breakpoint, or an explicit Figma/API blocker with the affected breakpoint named.

## Live Browser Export Mode
- If Figma MCP is quota-limited, use the live browser session against the Figma web file as the next extraction layer.
- Read the file tree, page list, layer names, and selected-node metadata from the browser session before guessing anything.
- Use browser screenshots for screen-level visual capture when native export is blocked.
- Treat the browser session as a live read-only source of truth, not as a place to invent missing structure.
- Package all browser-captured outputs under `H:\Nebula\GPT\figma-export\<timestamp>\`.

## Deep Extraction Control (Nebula)
- Primary command:
  - `H:\Nebula\GPT\tools\run_figma_scalper_deep.cmd`
- Config source of truth:
  - `H:\Nebula\GPT\figma-manifest\figma-target.json`
- Expected mode:
  - `deep` (mandatory for full fidelity audit and traceability)
- Logs:
  - `H:\Nebula\GPT\figma-export\figma-scalper-ops.log.jsonl`
  - `H:\GPT-Codex\output\figma-scalp\_service\service-log.jsonl`

Rule:
- Do not run `full/current_node` for production baseline capture in Nebula.
- Baseline capture must run `deep`, then implementation can scope down to screen-level tasks.

## Why This Works
- Figma MCP gives structured design context and screenshots directly from the file.
- Dev Mode and Code Connect make Figma more developer-friendly and reduce interpretation drift.
- Local screenshot comparison catches the small details that text-only inspection misses.

## Per-Screen Workflow
1. Identify the exact Figma node or screen.
2. Build the hierarchy/source-truth map before interpreting any visual:
   - `python H:\GPT-Codex\tools\nebula-audit-factory\build_figma_hierarchy_map.py --page <page-slug>`
   - For breakpoint-specific work add `--variant <1200|992|768|576|320>`.
3. Inspect the owning subtree and classify critical children:
   - `BG`, `ФОН`, `FON` -> background by default.
   - `IMG`, `VIDEO`, `PATTERN`, `avatar`, `play`, `star`, `quote`, CTA text -> exact source node or explicit exception.
4. Extract:
   - design context
   - metadata if needed
   - screenshot
   - variable definitions if useful
   - assets
5. Build a screen spec from the extracted data.
6. Implement the screen in code using the approved baseline patterns.
7. Render locally.
8. Compare against the Figma screenshot.
9. Fix differences.
10. Repeat until the screen matches the target closely.

## Required Extraction Fields
- Screen name
- Node ID
- Screen order
- Layout structure
- Typography
- Colors
- Spacing
- Asset list
- Interaction states
- Responsive behavior
- Notes about non-obvious details

## Rules for Ambiguity
- If the export shows a screen number, that number controls ordering.
- If a component exists in the approved baseline, reuse it.
- If a detail is not visible in the export or the current reference, stop and re-check Figma rather than inventing behavior.
- If a section is already approved in Home, do not modify it unless the current task explicitly targets it.

## Verification Gates
- The hierarchy/source-truth map exists for the page or selected breakpoint.
- The reference map exists for every required accepted breakpoint, and local missing cache files were cross-checked against export manifests before being reported missing.
- Full-page visual capture handled lazy images and fixed/sticky overlays; naive `fullPage` output is not sufficient for acceptance on long pages.
- All explicit `BG` / `ФОН` / `IMG` / `PATTERN` / quote / rating / CTA nodes are resolved before accepting visual parity.
- The rendered page must match section order.
- The rendered page must not introduce horizontal scroll.
- The rendered page must not change approved baseline sections.
- The rendered page must not replace coded UI with images.
- The rendered page must remain clean in console.

## Anti-Repeat Experience Rule
- Every repeated visual miss must become one of: a detector, a verifier rule, a source-reference map rule, a checklist item, or a documented stop condition.
- Do not rely on operator memory as the enforcement layer. If the mistake is deterministic enough to repeat, encode it in a script or required gate.
- Do not add process weight when a direct verifier is enough. Experience should reduce careless work and unnecessary ceremony at the same time.

## Escalation Rule
- If a screen still diverges after a local implementation pass and one verification pass, gather the exact unresolved differences and re-check the Figma node rather than widening the scope.
- If the missing detail cannot be extracted from Figma context, use an external visual review only for the specific discrepancy.

## Context Compression Rule
- Before compressing context, re-read:
  - `AGENTS.md`
  - `VERSTKA_STANDARD.md`
  - `NEURO_VERSTKA_PREP.md`
  - `FIGMA_AUTONOMY_PROTOCOL.md`
- Never compact from memory alone.
