# Nebula Figma Verstka Sprint Plan

## Goal
Bring the Figma-derived layout set to a strong implementation baseline before touching edge-case publishables.

## Execution Order
1. `home.html`
2. `home-popup-open.html`
3. `psychic-reading-new.html`
4. `signup-step-1.html`
5. `signup-step-2.html`
6. `unmapped` publishables and remaining component gaps

## Why This Order
- `home.html` establishes the visual system.
- `home-popup-open.html` validates the same system under modal or overlay states.
- `psychic-reading-new.html` is the main product trust/conversion surface.
- `signup-step-1.html` and `signup-step-2.html` are narrower and should inherit the stabilized patterns.
- Unmapped publishables should be postponed until the shell and shared patterns are stable.

## Procedure Per Screen
1. Align the screen against the current Figma spec and existing implementation.
2. Identify the minimum set of reusable blocks before editing page-specific markup.
3. Fix layout structure first, then typography, spacing, and responsive behavior.
4. Check the visual hierarchy against the reference and make the page stronger, not just equivalent.
5. Rebuild the screen in the existing project conventions instead of introducing a parallel style system.
6. Verify for desktop and mobile parity.

## Screen-Level Criteria

### home.html
- Hero, trust, topics, video, steps, situation, and FAQ sections read as one system.
- CTA hierarchy is unambiguous.
- Background treatment is intentional and consistent across sections.
- No section feels visually weaker than the reference baseline.

### home-popup-open.html
- Modal or popup state does not break the landing flow.
- Overlay layering, spacing, and focus remain controlled.
- Shared sections keep their proportions and rhythm in the open state.

### psychic-reading-new.html
- The reading flow feels premium and clear.
- Trust and expert sections land with stronger hierarchy than home.
- Content density stays readable at the intended breakpoints.

### signup-step-1.html
- Form structure is clear and fast to scan.
- Labels, inputs, helper text, and CTA are balanced.
- Error and inactive states remain visually coherent.

### signup-step-2.html
- Second-step continuity is obvious.
- No redundant visual noise from step 1 is repeated unnecessarily.
- The page feels like a continuation, not a separate design.

## Quality Gate
- Desktop and mobile sanity pass.
- No obvious overflow, overlap, or broken spacing.
- Shared components are reused instead of duplicated.
- If the screen can be improved by reusing an existing block, do that before inventing a new one.
- If a screen regresses the visual standard, stop and correct the underlying pattern before continuing.

## Working Rule
- Optimize for the strongest stable baseline first, then refine.
- Do not spend early time on unmapped publishables while the main screens are still weak.
- Treat the current Figma reference as the minimum quality bar, not the target ceiling.

