# Figma Handoff Hypotheses

## Goal
- Turn current Figma-to-code weak points into explicit, testable hypotheses with clear verifiers.

## Phase 0: Human Figma Authoring
- Fact: many publishable names are generic, typo-prone, or state-only.
- Hypothesis: if top-level publishables are renamed with family + role + breakpoint + state, routing errors and wrong exports drop sharply.
- Verify: `audit_figma_handoff_contract.ps1` reduces weak name counts.

## Phase 1: Export Capture
- Fact: current publishable/export lane preserves `node_id` and `page_name`, but not enough breadcrumb context.
- Hypothesis: if export artifacts preserve parent-chain or breadcrumb fields, the agent can stop inferring ownership from visuals.
- Verify: breadcrumb fields become present in manifest rows and handoff audit stops failing on breadcrumb loss.

## Phase 2: Manifest / Spec Compilation
- Fact: many screen specs point to `Button_GET_STARTED__587-8603.pdf`, which is semantically unrelated to their screens.
- Hypothesis: if `reference_export_file` is generated from the matching screen/breakpoint family instead of one fallback export, false source truth will collapse.
- Verify: `weakScreenSpecRefs` drops from `494` toward `0`.

## Phase 3: Encoding / Copy Truth
- Fact: contract-bearing titles contain mojibake.
- Hypothesis: if manifest/CSV/JSON writing is normalized to UTF-8 end-to-end, text contracts become safe for copy-sensitive implementation.
- Verify: `mojibakePages` drops from `51` toward `0`.

## Phase 4: Code Routing
- Fact: component classification works, but many source names are still weak.
- Hypothesis: if weak source names are normalized before or during publishable mapping, component routing stays deterministic under LLM use.
- Verify: `weakComponentNames` drops while `figma-component-mapping` remains green.

## Phase 5: Runtime States
- Fact: current contour already knows static compare, layout cards, and accordion proof, but interactive truth is still under-specified.
- Hypothesis: if a dedicated runtime video/state lane is added for hover, menu, theme, accordion, scroll, and lazy assets, fewer state defects will hide behind static screenshots.
- Verify: state scenarios produce repeatable runtime artifacts under `VIDEO_RUNTIME_PROOF_CONTRACT.md`.

## Stop Condition
- Do not call the contour battle-ready while:
  - weak publishable names remain high,
  - breadcrumbs are absent,
  - screen specs point at unrelated exports,
  - mojibake persists in contract-bearing text.
