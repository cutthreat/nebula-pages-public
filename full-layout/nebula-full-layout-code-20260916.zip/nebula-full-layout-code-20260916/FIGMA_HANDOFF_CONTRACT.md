# Figma Handoff Contract

## Purpose
- Freeze the exact intake contract between human-made Figma files and NEBULA 1:1 implementation.
- Fail closed before CSS/HTML work when naming, breadcrumbs, source linkage, or proof artifacts are weak.
- Keep `accepted_1to1` tied to source truth, not to plausible-looking exports.

## Result
- The agent can map `figma node -> breadcrumb -> screen/page -> export artifact -> code owner -> verifier` without guessing.

## Scope
- Figma page/frame/component/layer naming.
- Browser/native export artifacts and local manifest/spec bundles.
- Runtime state proof for interactive surfaces.
- Video/proto proof as diagnostic runtime evidence only.

## Done When
- Every implementation unit has stable source breadcrumbs.
- Weak or generic Figma names are detected before implementation.
- Screen specs do not point at semantically unrelated export artifacts.
- Export/manifests are UTF-8 clean and free from mojibake in contract-bearing fields.
- Interactive states have a separate proof lane and are not judged by static screenshots only.

## Source Of Truth Order
1. Frozen Figma node plus node id.
2. Matching export screenshot or exact node export.
3. Page reference map.
4. Code owner map.
5. Runtime state proof.
6. Diagnostic compare/video layers.

## Phase Contract

### Phase 0: Figma Authoring
- Pages and top-level frames must use human-readable names.
- Repeated components must use slash-based family naming.
- Variants and states must carry semantic state names, not only `Default`, `Variant2`, `Hover`, or `Click`.
- Important text layers should keep stable, role-based names across variants.
- Decorative internals may stay simple only if they do not become publishable/source nodes.

### Phase 1: Export Intake
- Every exported node must keep `node_id`, `node_name`, `page_name`, and a breadcrumb or parent-chain equivalent.
- Publishable exports without family/breadcrumb context are not implementation-ready.
- Generic names such as `Frame 280`, `Component 1`, `Rectangle 6`, `Property 1=Default`, `Card 1`, `1 step`, `1 review` are weak by default.
- If the export lane cannot preserve breadcrumbs, the source Figma naming must be repaired before relying on those exports.

### Phase 2: Manifest Compilation
- Screen specs must map to the correct screen family and breakpoint.
- `reference_export_file` must be semantically related to the screen identity.
- UTF-8 is mandatory for contract-bearing JSON/CSV files.
- Mojibake in titles, headings, or text samples means the artifact is untrusted for copy-sensitive work.

### Phase 3: Implementation Routing
- Every screen must resolve to a code owner before edits start.
- Repeated pattern fixes must route to the shared owner when safe.
- Unmapped publishables may be diagnostic, but cannot silently become source truth.

### Phase 4: Runtime Proof
- Hover, focus, open, theme, menu, accordion, lazy-media, and scroll-dependent states require runtime proof.
- Static screenshots are insufficient for state acceptance.
- Video/state capture is diagnostic proof for interactions, not a replacement for canonical Figma/export reference.

## Failure Modes
- Generic node names destroy semantic routing.
- Missing breadcrumbs force the agent to infer parentage from visuals.
- Wrong export artifacts can produce coherent but false implementation.
- Encoding corruption poisons copy truth and text contracts.
- State-only components named without owner context create false “same-looking” mappings.

## Verifiers
- `tools\\audit_figma_handoff_contract.ps1`
- `tools\\audit_figma_component_mapping.ps1`
- `tools\\test_visual_contour_contract.ps1`
- `tools\\audit_verstka_1to1_readiness.ps1`

## Video Lane
- Use a dedicated state/video lane to capture interactions:
  - menu open/close
  - accordion open/close
  - hover/focus transitions
  - theme toggle
  - lazy asset reveal
  - scroll-triggered fixed/sticky behavior
- This lane proves runtime behavior and timing, not source geometry truth.

## Finish Gate
- The contour is finish-ready only when the checklist passes with no red items and every open hypothesis has a verifier or an explicit blocker state.
