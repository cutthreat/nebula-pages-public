# Figma Handoff Checklist

## Pre-Intake
- [ ] The target page/screen and breakpoint are explicit.
- [ ] The accepted reference lane is frozen.
- [ ] The target files and primary verifier are known.

## Naming
- [ ] Top-level frames/pages use semantic names.
- [ ] Publishable/component names are not generic.
- [ ] Variants/states include owner context, not only `Default/Hover/Click/Variant2`.
- [ ] Repeated internals use stable role-based names where text/style extraction matters.
- [ ] Obvious typos (`Sing`, `DEFOLT`) are fixed or quarantined.

## Breadcrumbs
- [ ] Export/manifests preserve `node_id`.
- [ ] Export/manifests preserve `page_name`.
- [ ] Export/manifests preserve breadcrumb or parent-chain context.
- [ ] Screen specs point to the correct family and breakpoint.

## Export Truth
- [ ] Exact export artifact exists for the unit being implemented.
- [ ] `reference_export_file` is semantically related to the screen.
- [ ] Unmapped/generic publishables are not used as silent source truth.
- [ ] UTF-8 contract files parse cleanly.
- [ ] No mojibake remains in contract-bearing fields.

## Routing
- [ ] Code owner is known before edits.
- [ ] Shared patterns route to shared owners where safe.
- [ ] Diagnostic layers are kept separate from accepted reference.

## Runtime States
- [ ] Hover/focus/open states have a runtime verifier.
- [ ] Menu/accordion/theme/scroll behavior is captured separately from static compare.
- [ ] Video/state lane is treated as diagnostic runtime evidence only.

## Finish
- [ ] `audit_figma_handoff_contract.ps1` passes.
- [ ] `audit_figma_component_mapping.ps1` passes.
- [ ] `test_visual_contour_contract.ps1` passes.
- [ ] `audit_verstka_1to1_readiness.ps1` passes for the selected proof mode.
- [ ] Any remaining blocker is explicit, source-backed, and not hidden inside implementation.
