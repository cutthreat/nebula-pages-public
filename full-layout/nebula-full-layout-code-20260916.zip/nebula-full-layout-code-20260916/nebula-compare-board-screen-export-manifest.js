window.NEBULA_SCREEN_EXPORT_MANIFEST = {
  schema: "oracle_nebula.c76_screen_export_manifest.v2",
  status: "verified",
  generated_at: "2026-08-20",
  file_key: "C76M54fY7z926wIQoWFh8Y",
  design_url: "https://www.figma.com/design/C76M54fY7z926wIQoWFh8Y/%D0%9D%D0%95%D0%91%D0%A3%D0%9B%D0%90---MASTER-MAP",
  view_token: "6mfP2NGTaA5Kdhgy-0",
  source_manifest_sha256: "E2FBBDAD06BD85FC81DC3686418D0CE899654F75F1025F20075AC80B189E63E1",
  verifier: "local_png_integrity_verifier:9/9:sha256+png-ihdr",
  entries: [
    { page_id: "aura-colors", variant_id: "1200", node_id: "902:13666", local_path: "compare-board-sources/c76-screen-exports-20260820/aura-colors-1200-node-902-13666.png", source_sha256: "40FB8117FCD34B91371B047DAB2E789A82B0BA3B459DABFAF9716FAD6103C0F5", dimensions: "690x217", binding: "direct_screen_png_export" },
    { page_id: "aura-colors", variant_id: "992", node_id: "902:13899", local_path: "compare-board-sources/c76-screen-exports-20260820/aura-colors-992-node-902-13899.png", source_sha256: "FEEA6DE6D42C153275C34F819B3135A2DB04005236794ACE8A5DE07383ABBE8B", dimensions: "980x217", binding: "direct_screen_png_export" },
    { page_id: "aura-colors", variant_id: "768", node_id: "902:14134", local_path: "compare-board-sources/c76-screen-exports-20260820/aura-colors-768-node-902-14134.png", source_sha256: "25DA9E35B2D9DAF8220DE8C4080141B10D5EF04EE35A76F40215DAEBBB5720B5", dimensions: "930x217", binding: "direct_screen_png_export" },
    { page_id: "aura-colors", variant_id: "576", node_id: "906:17915", local_path: "compare-board-sources/c76-screen-exports-20260820/aura-colors-576-node-906-17915.png", source_sha256: "E388097690257B260AC3C8CA2493A39F71251FA801E89BD49ECFA8152ADC035B", dimensions: "510x211", binding: "direct_screen_png_export" },
    { page_id: "palm-reading-scanner", variant_id: "1200", node_id: "910:23048", local_path: "compare-board-sources/c76-screen-exports-20260820/palm-reading-scanner-1200-node-910-23048.png", source_sha256: "B198A69488D8A13DF83338F97994EF4353F9ACF304075EBB7C8DAFC59B0FA5B9", dimensions: "1200x1180", binding: "direct_screen_png_export" },
    { page_id: "palm-reading-scanner", variant_id: "992", node_id: "910:23063", local_path: "compare-board-sources/c76-screen-exports-20260820/palm-reading-scanner-992-node-910-23063.png", source_sha256: "6B42DA2B2D507FE4BD302DD3B8F7579D400977496D687A638CFA84798471F328", dimensions: "992x1180", binding: "direct_screen_png_export" },
    { page_id: "palm-reading-scanner", variant_id: "768", node_id: "910:23924", local_path: "compare-board-sources/c76-screen-exports-20260820/palm-reading-scanner-768-node-910-23924.png", source_sha256: "51DE4D69998B8954160E843690B58F078816016BF2ECA333009196C8EB6D1228", dimensions: "768x1210", binding: "direct_screen_png_export" },
    { page_id: "palm-reading-scanner", variant_id: "576", node_id: "910:23957", local_path: "compare-board-sources/c76-screen-exports-20260820/palm-reading-scanner-576-node-910-23957.png", source_sha256: "E57C5CEF3A13FB11192A8BEE8B6EC92E38CD0F917B7B71EDD03B12203EC5562C", dimensions: "576x1100", binding: "direct_screen_png_export" },
    { page_id: "palm-reading-scanner", variant_id: "320", node_id: "912:11647", local_path: "compare-board-sources/c76-screen-exports-20260820/palm-reading-scanner-320-node-912-11647.png", source_sha256: "0534FE7527B0D8AFCC6BEFCC10E293B0BF1D3A989FCA9F23371E46395B346217", dimensions: "320x1740", binding: "direct_screen_png_export" }
  ]
};
