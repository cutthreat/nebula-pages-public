# NEBULA Verstka Standard

## Goal
- Produce code that is visually and structurally one-to-one with the approved Neuro reference.
- Treat the existing Home implementation as the project baseline.
- Treat Figma export order as authoritative when screen numbers are present.

## Home Baseline Transfer
- Home baseline transfer rules live in `H:\Nebula\GPT\HOME_BASELINE_TRANSFER_STANDARD.md`.
- The full Codex Hub playbook is `H:\GPT-Codex\.ops\docs\playbooks\ORACLE-NEBULA-HOME-BASELINE-FAST-VERSTKA-STANDARD-2026-05-13.md`.
- The reuse-first contract lives in `H:\GPT-Codex\docs\oracle-nebula\ORACLE_REUSE_FIRST_IMPLEMENTATION_CONTRACT.md`.
- Transfer Home as a process: source map -> selector map -> layer stack -> reverse contract -> owner-classified implementation -> breakpoint/runtime proof.
- Do not copy Home CSS values into another page unless the target page has matching Figma source, breakpoint, selector owner, and verification proof.
- Before writing a new block, run or inspect the reuse candidate map. If an existing source-backed component family matches, adapt that family instead of creating a parallel implementation.
- Current mandatory preflight command for reusable families:
  `python -u H:\GPT-Codex\tools\nebula-audit-factory\build_oracle_reuse_candidate_map.py --pages home all-psychic phone-psychic psychic-reading cheap-psychic love-reading aura-reading 404 zodiac-compatibility --out H:\GPT-Codex\artifacts\oracle-reuse-candidate-map\oracle-reuse-candidate-map.v2.json --out-md H:\GPT-Codex\artifacts\oracle-reuse-candidate-map\oracle-reuse-candidate-map.v2.md`
- Treat `reuse_candidate_found` as a stop sign against fresh implementation: first inspect/adapt the canonical family, then patch only the target-specific delta.
- Treat `weak_source_evidence` as "use for grammar, not for source proof": Home can guide shell/header/footer/CTA behavior, but exact paint/geometry still comes from the current Figma export.

## Reference Hierarchy
1. Exact Figma export for the target screen / node
2. Approved reference Home and release `1.0`
3. Existing project code in `_unzipped`
4. Local implementation changes

## Accepted 1:1 Source Contract
- `accepted_1to1` may be assigned only against an actual Figma/export reference or a deliberately frozen local reference map derived from Figma/export.
- Local cache absence is not source absence. If `_unzipped/img/breakpoints/<page>-<breakpoint>-reference.png` is missing, inspect `figma-manifest/oracle-ethalon-pack-*.json` and `figma-export/**/figma-screens/**/screenshot.png` before saying the reference does not exist.
- Diagnostic controls such as Pavlo, Layout Capture Card, compare-board overlays, browser screenshots, and current implementation screenshots can identify defects but cannot replace the accepted reference.
- Every accepted multi-breakpoint page must have `<page>-reference-map.json` or an equivalent manifest that lists `fileKey`, `figmaVersionRef`, `breakpoint`, `figmaNodeId`, `figmaName`, local reference path, and source screenshot path.
- If two Figma nodes match one breakpoint, choose the canonical node by page/job contract and visual continuity across adjacent breakpoints. Record the rejected node and reason in the reference map.
- `missingFigmaReferences` must be `0` for all required breakpoints unless a Figma/API blocker is explicitly documented in the task result.
- A page can be called visually improved without this gate, but it cannot be called `accepted_1to1`.

## Capture Contract
- Do not close visual QA from a naive Chrome `fullPage` screenshot when the page has `loading="lazy"` images, fixed headers, sticky controls, popups, or long-page content.
- Before full-page comparison, force lazy images to eager, wait until images are complete, and record document height / scroll width / horizontal overflow.
- For long static pages, prefer full-document viewport capture when document height is within the browser bitmap limit. If the page is taller, use a stitched capture that hides fixed overlays after the first slice.
- Section-scoped Layout Capture Card output is diagnostic evidence. It freezes DOM planes, boxes, styles, and snippets; it does not replace Figma/export reference truth.

## Experience / Wisdom Gate
- Experience is valid only when it changes the next action. A lesson that does not change source choice, edit order, verifier, or stop condition is not accepted as operational experience.
- Start from current source truth, not from memory. Old green artifacts, prior screenshots, Pavlo/control pages, and cached local refs are weaker than the current Figma/export reference map.
- If the user disproves a green status with visual evidence, reset trust for that defect class. Add or run a detector before another repair pass.
- Fix the owner of the defect, not the visible symptom. Section flow defects are fixed in section hosts; repeated component defects are fixed in the shared component contract; source asset defects are fixed from exact Figma nodes/assets.
- Do not turn a verifier defect into CSS work. If a probe uses the wrong viewport, stale artifact, wrong launch mode, missing lazy images, or bad text-model assumption, repair the verifier first.
- Responsive work is not a single desktop-to-mobile scaling pass. Each accepted breakpoint needs its own source reference, explicit viewport, and fresh proof.
- Late cascade files are active runtime owners. If a repair is made in main CSS, inspect later owner files before claiming the value holds in browser.
- A visual shortcut is allowed only when the context matches a proven pattern and a small verifier proves it still holds. If context, source version, breakpoint, or risk changed, return to source-first inspection.
- Consequence rule: a wrong first source choice creates coherent but wrong CSS; a wrong capture creates false visual evidence; a wrong verifier creates false green/red; a missing stop condition creates repeated rework. Any one of these blocks acceptance.

## Experienced Execution Order
1. Normalize the user request to result, scope, done criteria, verifier, and stop condition.
2. Freeze the current Figma/export reference for the exact page and breakpoint.
3. Classify the defect owner: source, verifier, shell flow, component, asset, typography, interaction, or responsive cascade.
4. Inspect current runtime and late owner files before editing.
5. Make the smallest owner-level repair.
6. Run the specific detector/probe first; run broader visual proof only after the owner detector is clean.
7. Record a reusable lesson only if it changes future behavior or adds a verifier/checklist rule.

## What "One-to-One" Means
- Same section order
- Same spacing rhythm
- Same typography scale and line-height logic
- Same responsive breakpoint behavior
- Same component style and naming conventions
- Same interaction style for hover, focus, active, accordion, slider, and similar patterns

## Source Bundle
- `https://pavlo-bondarchuk.github.io/neuro/home.html`
- `https://github.com/pavlo-bondarchuk/neuro`
- `https://github.com/pavlo-bondarchuk/neuro/releases/tag/1.0`
- `H:\Nebula\GPT\_unzipped`
- `H:\Nebula\GPT\Export НЕБУЛА 1200+`

## Coding Rules
- Use semantic HTML
- Reuse existing Bootstrap 4.6 layout primitives
- Keep CSS in separate files
- Keep JS in separate files
- Avoid global style overrides unless the reference already relies on them
- Prefer existing BEM-style naming and component structure
- Do not introduce image-based substitutes when the block can be built correctly in HTML/CSS
- A repeated block must name one physical component or accepted heritage owner. Do not copy a shared header, footer, card, CTA, FAQ, review, or LK shell and then evolve the copy independently.
- Static HTML remains the delivery artifact, but shared markup/style/behavior must come from the registered owner; each page contains only its source-backed delta.
- One selector/property/state has one owning declaration. Delete or consolidate losing declarations instead of appending a later override.
- New or touched production pages may not contain inline `<style>` or executable inline `<script>` blocks. JSON/JSON-LD data blocks are the only inline-script exception.
- Every local CSS/JS reference must resolve before compare-board review.
- `Test-OracleNebulaPageImplementationCompliance.ps1 -StrictQuality` must return schema `oracle_nebula_page_implementation_compliance_check.v2`, `production_code_ready=true`, and `failures=[]` before ready/accepted promotion.

## Production Code Architecture Gate

The code path is now:

`deep Figma map -> screen contract -> accepted component/heritage owner -> page delta -> separate HTML/CSS/JS -> implementation compliance V2 -> breakpoint/runtime proof -> compare board -> promotion gate`.

Rules:

1. Source truth decides appearance; the component owner decides where shared code lives.
2. A page-specific file may bind content, assets, order, variants, and measured geometry, but must not fork a shared component silently.
3. Existing legacy pages are not mass-refactored merely for style. Once a page is touched or promoted, its active scope must pass the strict production-code gate.
4. A visually accurate page with broken references, inline executable code, conflicting owner declarations, or missing breakpoint behavior remains blocked.
5. A clean technical packet is not visual acceptance; both production-code and source/live proof gates must pass.

## Decision Rules
- If the same pattern already exists in the approved Home, reuse that pattern
- If the Figma export names a screen number, that order wins
- If Figma and current reference appear to conflict, preserve the approved baseline and implement the new block without breaking the baseline pattern
- Never invent new section order based on content semantics alone

## Workflow for Every Task
1. Read `AGENTS.md`
2. Read this standard
3. Read `NEURO_VERSTKA_PREP.md`
4. Read `FIGMA_AUTONOMY_PROTOCOL.md`
5. Read `FIGMA_PATTERN_LIBRARY.md`
6. Read the latest entries in `FIGMA_LESSONS.jsonl`
7. Inspect the current reference file(s)
8. Inspect the exact export screen(s)
9. Implement in code
10. Verify responsive behavior and visual consistency

## Quality Gates
- No horizontal scroll
- No accidental layout shifts
- No regression in already approved blocks
- No new console errors from the change
- No mismatch with export order
- Section shell heights on content-driven blocks must use `min-height`, not fixed `height`, when the block contains FAQ/accordion text, repeated cards, footer menus, or copy that can wrap differently across browsers.
- Responsive breakpoint ranges must not overlap at exact handoff points. Use fractional mobile caps such as `max-width: 575.98px` and start the next shell at `min-width: 576px`; always verify both sides of the seam (`575/576/577`) before accepting a page.
- Late owner files such as `*-reverse-shell-owner.css` and `*-reverse-type-owner.css` are part of the active cascade, not passive documentation. They must not reintroduce fixed shell heights, stale breakpoint ranges, or type values that override the repaired runtime contract.
- For visually risky sections, create a Layout Capture Card before and after the change:
  - capture the exact DOM planes being judged, not only a full-page screenshot
  - record bounding boxes, key computed styles, text snippets, and per-section screenshots
  - use `H:\Nebula\GPT\tools\capture_layout_cards.js` for the capture manifest
  - treat the manifest like a VFX track file: it is diagnostic evidence, not a replacement for Figma/source truth
- Any Figma accordion / FAQ / SEO dropdown is not accepted as a static screenshot state:
  - every visible item must have non-empty body content
  - click on the title / plus control must open the item
  - single-open accordions must close sibling items
  - `open`, `aria-expanded`, visual icon state, and open-state class must stay synchronized
  - opening an item must not move the title/toggle anchor: open-state CSS must not switch `summary` to a different layout model or change the title-side padding unless the Figma open state explicitly does so
  - opened item height must be content-driven; do not use fixed/min heights that leave a large empty tail below answer text
  - run `H:\Nebula\GPT\tools\verify_accordion_contract.js` before closing an accordion-related task

## Context Compression Rule
- Before compacting context, reread this document
- Also reread `FIGMA_AUTONOMY_PROTOCOL.md`
- Also reread `FIGMA_PATTERN_LIBRARY.md`
- Also reread `FIGMA_LESSONS.jsonl`
- Include:
  - goal
  - completed work
  - changed files
  - risks
  - open questions
  - next actions
- Never compress purely from memory
