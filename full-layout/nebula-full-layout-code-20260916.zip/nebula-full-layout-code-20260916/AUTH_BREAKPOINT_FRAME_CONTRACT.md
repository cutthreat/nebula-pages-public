# Auth Breakpoint Frame Contract

## Hard Rule
Each auth breakpoint is a separate Figma frame and must be implemented as its own source target.

Do not treat `1200+`, `960-1200`, `640-960`, `480-640`, and `320-480` as scaled variants of one layout.

## Figma Source First Rule (Hard)
Assume that 99.99% of visible UI elements already exist in Figma as nodes, vectors, images, text styles, fills, strokes, effects, or exports.

The implementation route is mandatory:
1. find the exact breakpoint frame;
2. find the exact Figma node for the visible element;
3. copy its bbox, render bounds, typography, fills, strokes, effects, vectors, and image refs;
4. bind the DOM/CSS/asset to that source;
5. verify against the screenshot.

It is forbidden to invent, redraw, approximate, or tune a visually similar element while the matching Figma node/export exists.

`Take from reference` means take from the Figma source node/export used to produce the reference. It never means:
- manually drawing a similar CSS shape before reading the node;
- guessing colors, shadows, font sizes, spacing, icon shape, or asset bounds from the screenshot;
- using generic Unicode glyphs where Figma has a vector;
- replacing source-backed elements with screenshots or crops.

Screenshot comparison is only a defect locator and final proof. It is not a source of design values.

If the node cannot be found, the task state is `source_blocked` until the missing source is located or explicitly registered as an exception.

## Visibility Gate (Hard)
Finding a Figma node is not enough to render it.

Before binding or implementing any node, verify in the exact breakpoint `screen.json`:
- the node is visible in that frame;
- its parent chain is visible;
- the node belongs to the current visible composition, not a hidden legacy/component branch;
- the visible reference PNG confirms the element appears on that breakpoint.

If a node exists but is hidden, keep it unrendered unless the task explicitly targets a hidden-state implementation. For example, `signup-step-2` contains hidden social/divider descendants from a reused component branch; they are source evidence for the component library, not visible UI for the current screen.

## Required Order
1. Select one screen and one breakpoint.
2. Read that breakpoint's `screen.json`.
3. Extract bbox values from the exact frame.
4. Extract exact visible strings from the same frame. Do not normalize copy, spelling, punctuation, or arrows.
5. Bind DOM/CSS to those values.
6. Run a single-target parity proof with asset-ready capture.
7. Inspect zoom crops for topbar, form title/subtitle, controls, divider/social, and background glow.
8. Move to the next breakpoint only after the current proof artifact exists and the zoom crops show no visible mismatch.

## Scoped Edit Rule
Auth CSS contains repeated selectors across breakpoint layers. A proof run is invalid if the intended final breakpoint override was not actually changed.

Before running a proof after a CSS edit:
- re-read the final breakpoint block at EOF;
- confirm the edited selector is inside the target breakpoint scope;
- confirm no earlier same-name selector was changed by mistake;
- if an edit accidentally lands in a non-target layer, revert that accidental edit before testing.

## Source-Fidelity Rule For Micro Nodes
Do not replace Figma vector/image micro-nodes with visually similar Unicode characters or generic assets.

Examples:
- language chevron must come from the exact Figma vector/export or an exact vector reconstruction, not `▾`;
- login arrow must come from the exact Figma vector/export or an exact vector reconstruction, not `→`;
- social icons and logo variants must use the breakpoint-specific Figma asset when such asset exists.

If a visible mismatch is found in a micro-node, first inspect that node in the breakpoint `screen.json`, then bind the DOM/CSS to the node bbox and asset source before tuning opacity, blur, or color.

When Figma bbox coordinates contain `.5px`, treat the half-pixel as source truth. Do not round it away silently. Use a scoped transform or explicit coordinate binding, then verify with a zoom crop.

## No Visual Guessing Rule
Screenshot diff is a locator, not a design source.

When a text/control/icon mismatch is visible:
- find the exact node in the breakpoint `screen.json`;
- record node id, bbox, render bounds, typography, fills, strokes, and effects;
- apply those values to the bound DOM/CSS first;
- only after source values are applied, use a scoped browser-render normalization for known Figma-vs-Chrome rendering differences;
- do not tune color, font size, weight, line height, shadow, or asset dimensions from the screenshot by guesswork while the Figma node data exists.

For `signup-step-1 / 320x760`, known source nodes:
- selected radio: `579:6731`, ellipse `16x16`, fill `#673eda`, stroke `#d9d9d9` `4px`, shadow `0 4px 4px rgba(0,0,0,.25)`;
- selected label: `579:6732`, Manrope `16px/30px`, weight `500`, letter spacing `-0.16px`, fill `#673eda`;
- inactive label: `I579:6733;579:6619`, Manrope `16px/30px`, weight `500`, letter spacing `-0.16px`, fill `#9e9e9e`;
- social divider text: `380:1857`, bbox `94x10`, render height `13.76px`, Manrope `14px`, weight `500`, letter spacing `-0.14px`, fill `#673eda`;
- divider lines: `380:1856` and `380:1858`, x `.5`, width `84px`, stroke `#7653d9`, `1px`.

## Proof Preflight
Before every screenshot proof, verify that the local preview endpoint is healthy.

The proof is invalid if the live capture contains a browser error page, connection-refused page, unloaded asset state, or any non-target document.

A proof is also invalid when the live panel is blank/dark while the reference is populated. Treat extreme metrics such as `MAE > 100` on this auth frame as a capture failure first, not as a CSS regression. Re-read the target CSS block, kill stale temporary Chrome processes if needed, and rerun the same proof before making visual decisions.

Required local health URL:

```powershell
Invoke-WebRequest -Uri "http://127.0.0.1:4175/_unzipped/capture-auth-frame.html?page=signup-step-1.html&w=320&h=760" -UseBasicParsing
```

If this fails, restart the preview with `tools/start_compare_board_preview.ps1` and rerun the last proof. Do not interpret the failed screenshot as a visual regression.

## Page Close Rule
Never mark a page or breakpoint as complete while the reference and prototype screenshots have visible differences.

`ready` is split into two explicit statuses:
- `human_ready`: the reference and prototype are visually equivalent for a normal human reviewer; remaining differences are only registered Figma-vs-browser raster/render artifacts.
- `math_ready`: all deterministic gates pass without unregistered exceptions.

`human_ready` requires:
- exact Figma source binding for visible geometry, assets, typography, fills, strokes, and effects;
- side-by-side screenshot for the exact breakpoint;
- zoomed side-by-side crops for high-risk regions;
- no visible layout, color, asset, spacing, text, or background mismatch to a normal human reviewer;
- every remaining difference is recorded as a bounded `render_raster_exception` with Figma node id, evidence path, and reason.

`math_ready` requires:
- side-by-side screenshots for the exact breakpoint;
- zoomed side-by-side crops for high-risk regions when any mismatch is suspected;
- the reference and prototype must be visually identical without compromise;
- numeric diff is supporting evidence, not a replacement for visual proof;
- if `screen.json` component metadata conflicts with the visible reference PNG, the visible reference PNG wins for that breakpoint;
- if a mismatch is visible, create a bounded repair target and continue from the last failing breakpoint;
- do not advance to the next breakpoint as "done" until the current breakpoint is honestly 1-to-1.

The operator acceptance phrases are:
- `human_ready`: reference and prototype are equivalent to a normal human reviewer; only registered raster/render exceptions remain.
- `math_ready`: reference and prototype are fully identical on the screenshot.

## Verification
Use `tools/verify_auth_signup_breakpoint_parity.ps1` with single-target filters:

```powershell
& .\tools\verify_auth_signup_breakpoint_parity.ps1 -OnlyKey 'signup-step-1' -OnlyWidth 320
```

Valid keys:
- `signup-step-1`
- `signup-step-2`

Valid widths:
- `1280` for `1200+`
- `960`
- `640`
- `480`
- `320`

## Failure Mode Prevented
The old route rendered one responsive adaptation and compared it against multiple independent Figma designs. That created false confidence and caused fixes for one breakpoint to damage another.

Additional blocked failure modes:
- capturing before Figma-exported background assets are loaded;
- trusting thumbnail boards without zoom crops;
- correcting Figma copy into "better" product copy;
- using numeric diff as a readiness verdict when the screenshot still visibly differs;
- moving to the next breakpoint after an improvement that is not yet visually identical.
