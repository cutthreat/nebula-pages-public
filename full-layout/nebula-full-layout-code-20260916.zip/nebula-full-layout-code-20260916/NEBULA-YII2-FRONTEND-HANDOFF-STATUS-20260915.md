# Nebula: статус передачи фронтенда в Yii2

Дата среза: 2026-09-15 23:05 (Europe/Minsk)

Этот документ фиксирует доказанный фронтенд-срез и границы утверждений. Он не означает готовность backend, платежей, realtime или production-auth.

Машинная матрица требований и claim ceiling: `PROOF/frontend-completion-audit.json` в transfer-архиве.

## Портативная карта доказательств

Этот документ сохраняет исторические имена исходного checkout в описании среза, но в другой Codex-среде нужно использовать только archive-relative пути:

- публичный catalog/transition: `PROOF/public-catalog/catalog-dom-smoke.json`, `PROOF/public-catalog/transition-matrix.json`, `PROOF/public-catalog/transient-taurus-576-recheck.json`;
- auth: `PROOF/auth-interaction-smoke.json`;
- account/chat: `PROOF/account-chat/QA-REPORT-2026-09-15.md` и `PROOF/account-chat/mobile-hit-area-repair-20260915.json`;
- Yii2 host/package: `PROOF/yii2-host/LOCAL-HOST-DOM-SMOKE.json`, `PROOF/yii2-package-proof.json`, `PROOF/yii2-package/`;
- sliders and compare-board: `PROOF/interactions/all-psychic-slider-contract.json`, `PROOF/interactions/slider-responsive-smoke-20260916.json`, `PROOF/compare-board/acceptance-surface-20260916.json`;
- Figma/readiness: `PROOF/figma-readiness/20260916-011915/` и `PROOF/figma-handoff-audit-rebound-20260916.json`;
- implementation source: `SOURCE/PUBLIC-STATIC/`, `SOURCE/ACCOUNT-CHAT-MODULE/`, `SOURCE/YII2-LANDING-PACKAGE/`, `SOURCE/YII2-HOST/`.

Ссылки вида `artifacts/...`, `experiments/...`, `H:\\GPT-Codex\\...` ниже — provenance исходного checkout, а не обязательные пути назначения. Если archive-relative proof отсутствует, это нужно фиксировать как `source_blocked`, а не подменять соседним asset или старым абсолютным путём.

## Что доказано локально

- Публичные маршруты: `transition-matrix` — 75/75 ячеек (15 шаблонов × 5 ширин), HTTP 200 — 75/75, navigation/page/request failures — 0, click/back/forward — 75/75. Артефакт: `artifacts/nebula-unified-compare-20260913/transition-matrix/transition-matrix.json`.
- DOM smoke: 75/75, HTTP 200 — 75/75, horizontal overflow — 0, inner vertical scroll owners — 0, broken/pending images after scroll — 0. Артефакт: `artifacts/nebula-unified-compare-20260913/dom-smoke/dom-smoke.json`.
- Последний чистый catalog DOM receipt: 66 страниц × 5 ширин = 330/330 ячеек, HTTP 200 — 330/330, navigation/page/console/local-request failures — 0, horizontal overflow — 0, inner vertical scroll owners — 0, broken images — 0, visible pending images после вертикального и горизонтального settle — 0, interactive rows — 330/330. Один промежуточный повтор 2026-09-15 дал transient `net::ERR_NO_BUFFER_SPACE` на `taurus-compatibility@576` для уже существующего `zodiac-sign-03-gemini.webp`; isolated recheck прошёл: HTTP 200, 31 710 bytes, broken/console/request failures — 0. После этого полный exhaustive rerun под свежим resource budget снова прошёл чисто: 330/330 и все failure counters — 0. Транзиент сохранён отдельно в `artifacts/nebula-catalog-dom-smoke-20260915/transient-taurus-576-recheck.json` и не классифицирован как source/UI defect. Проверяющий отдельно проходит горизонтальные carousel tracks и не считает hidden desktop-only lazy images блокером. Артефакт clean receipt: `artifacts/nebula-catalog-dom-smoke-20260915/catalog-dom-smoke.json`; runner: `tools/run_nebula_catalog_dom_smoke.mjs`.
- Catalog viewport visual receipt: сохранены 330 текущих PNG (66 маршрутов × 5 ширин) и contact sheets `contact-sheets/catalog-{1200,992,768,576,320}-contact.png`. Просмотр representative sheets на 1200/768/576/320 показал согласованный header/hero/card shell без blank viewport, clipping или горизонтального overflow. Это receipt текущего runtime-viewport, не Figma 1:1 acceptance; full-page visual/source acceptance остаётся отдельным gate.
- Auth preview: 8/8 сценариев (login, forgot-password, signup step 1/2 на 1200/320). Empty submit — invalid, заполненный submit — честное `unavailable` с сообщением о подключённом сервисе; page/console errors — 0, overflow — 0. Артефакт: `artifacts/nebula-auth-interaction-smoke-20260915.json`.
- Свежий auth responsive visual/DOM smoke через Playwright: 4 source-ready экрана (`login`, `forgot`, `signup-step-1`, `signup-step-2`) × 5 ширин `1200/992/768/576/320` = `20/20 PASS`; page errors — 0, console errors — 0, horizontal overflow — 0. Представительные 1200px и 320px PNG просмотрены. Receipt: `artifacts/auth-responsive-playwright-20260916/receipt.json`. Старый Chrome-wrapper не использован как acceptance proof: он не создал screenshot в текущей среде.
- Account/chat UI: 160 локальных и 160 внешних экранов на пяти ширинах; overflow — 0, изображения — 0 ошибок, active controls — 0 fail. Полный отчёт: `artifacts/nebula-cabinet-deep-qa-20260915/QA-REPORT-2026-09-15.md`.
- Mobile hit-area repair: на реальном Yii2-host для `chatroom` и статического `expert-picker-details` при 576/320px подтверждены 44×44 CSS-пикселя для chat actions, search filter и favorite controls; исходная иконографика сохранена в диапазоне 17–22px. `scrollWidth === clientWidth`, page/console/request errors — 0. Динамический owner — `experiments/nebula-account-chat-live-20260809/yii2/modules/nebulaAccount`, implementation mirror — `nebula-account/...`; asset receipt: `artifacts/nebula-cabinet-deep-qa-20260915/mobile-hit-area-repair-20260915.json`.
- Canonical local Yii2 host (`127.0.0.1:8776`): 15 core routes × 5 ширин = 75/75, expected HTTP statuses — 75/75, navigation/page/request failures — 0, horizontal overflow — 0, inner vertical scroll owners — 0, broken images — 0, actionable pending images — 0; 3 deferred offscreen lazy images оставлены в inventory. Для повторяемости smoke кэширует только immutable static assets, повторяет их fetch при transport error и имеет отдельный source-backed guard для route-specific `sprite.svg`; в текущем receipt `sourceBackedSpriteDirectFetches=4`, `sourceBackedSpriteFallbacks=0`, `fetchRetries=0`. Артефакт: `artifacts/nebula-final-site-audit-20260912/yii2-host/LOCAL-HOST-DOM-SMOKE.json`; runner: `tools/run_nebula_yii2_host_dom_smoke.mjs`.
- Canonical Yii2 host smoke повторён после account/chat mobile repair: результат снова `75/75 PASS`, actionable pending images — 0; receipt обновлён 2026-09-15 17:29 Europe/Minsk.
- Yii2 package contract suite: PHP lint — 70/70, основной module verifier, frozen static pages, `all-psychics`, FAQ и 404 package proofs — `pass`; актуальный package hash `015b8ecb83b9367a389729edb17054e5b1d965d03d6b78d5b389624d3cc2775a`. В пакет добавлены четыре source-backed `blog-input` image assets (`blog-source-card-4` PNG/WebP и `blog-input-person-c76` PNG/WebP); их hashes pinned в основном proof. Актуальный полный proof: `artifacts/nebula-yii2-package-proof-20260915.json`, отдельный All Psychics proof: `artifacts/nebula-yii2-package-proof-20260916.json`. Статус остаётся `package_ready_host_mount_pending`: host mount и production runtime не доказаны.
- `all-psychic`: карточные блоки `Best Online Psychics` и `Real Reviews from Users` имеют горизонтальный native touch-scroll с snap, стрелками, keyboard support, ARIA и disabled-state; актуальная проверка на 320/576 включает `tabIndex=0` для track, ArrowRight, next-arrow и CDP touch swipe без page/console/request errors. Proof: `artifacts/nebula-yii2-all-psychic-slider-20260916/slider-responsive-smoke.json`.
- Свежая проверка после bounded accessibility repair: на public easy-route и canonical Yii2 host текущего checkout треки `Best in Love readings`, `Best Online Psychics` и `Real reviews` получили `tabIndex=0`; при 320/576 `ArrowRight`, next-arrow и CDP touch swipe реально продвигают native snap track, `overflowX=auto`, `touchAction=pan-x pan-y`, page/console/request errors — 0. Receipts: `artifacts/nebula-all-psychic-slider-20260916/slider-responsive-smoke.json` и `artifacts/nebula-yii2-all-psychic-slider-20260916/slider-responsive-smoke.json`.
- `love-reading`: exact C76 reference map добавлен для 1200/992/768/576/320. Файл: `_unzipped/img/breakpoints/love-reading-reference-map.json`. Все пять `localReference` существуют и связаны с node id/hash C76-20260727.
- Compare-board second-scroll probe: для `love-reading` 320px live iframe имеет `scrolling="no"`, `overflow:hidden`, `clientWidth=scrollWidth=320` и `clientHeight=scrollHeight=9037`; внутренний вертикальный scrollbar не воспроизводится. Артефакты: `artifacts/nebula-compare-board-iframe-scroll-proof-20260915.json` и свежий acceptance-surface proof `artifacts/nebula-compare-board-acceptance-live-20260916.json` (`issue_count=0`).
- Portable 1:1 readiness rerun на текущем source snapshot: `58 pass / 0 warn / 1 fail / 0 skip`; единственный fail — ожидаемый `gate:figma-handoff-contract`. Preview launcher проверяет SHA-256 текущего `_unzipped/home.html`; local layout capture для `all-psychic` и `home` дал `findings/pageErrors/overflow = 0`, home/Figma 1200 compare сформировал локальный report без внешнего URL, runtime proof прошёл 3 сценария с console/page errors — 0. Свежий артефакт: `artifacts/nebula-1to1-readiness-current/20260916-011915/readiness-report.json`.
- Runtime state proof home: accordion open/close, theme toggle и scroll-sticky header — pass; console/page errors — 0. Артефакт: `H:\GPT-Codex\artifacts\runtime-state-proof\home-runtime-proof-v1\1200x1000\20260915-132927\manifest.json`.
- Source coverage: 66 страниц × 5 breakpoint rows = 330; issue count — 0; `source_missing_proven` — 0; exact-source rows — 89; source-present pending rows — 241. Проверка: `tools/Test-NebulaCompareBoardSourceCoverage.ps1 -Json`.
- Coverage builder regression: 21/21 checks pass, включая byte-deterministic повторную сборку, сохранение браузерного payload, reject drift/missing identity и запрет ложного `source_missing_proven`. Проверка: `tools/Test-NebulaCompareBoardSourceCoverageBuilder.ps1`.
- Compare-board contracts: acceptance-surface — `pass`, issue count 0; panel availability — `pass`, HTTP 200 для board/catalog/coverage/home и idempotent start.
- Acceptance-surface verifier повторён на текущем source snapshot: `pass`, 66 страниц, 330 coverage rows, width truth/screen corridor/frame ownership/lens settlement — pass, issue count 0. Свежий receipt: `artifacts/nebula-compare-board-acceptance-live-20260916.json`.
- Source-truth guard: `Test-NebulaCompareBoardSourceTruth.ps1` — `pass`, 66 страниц, issue count 0; acceptance-surface rerun после recovery-index также `pass`, issue count 0, 330 coverage rows.
- Figma source recheck: 8 exact manifest-backed refs переведены на прямые portable paths (включая `404-new`, `all-psychic-new`, `aura-reading-new`, `blog-input-new`, `blog-new`, `faq-new`, `taurus-compatibility-new`, `zodiac-compatibility-new`); ещё 27 refs подтверждены через recovery-index и 19 через строгий local rebind `normalized export-folder key + adjacent screen.json node_id + PNG SHA-256`; generic/cross-page substitution не допускается. Свежий receipt: `artifacts/nebula-figma-source-blocker-recheck-after-hero-path-repair-20260916.json` (`directPortableRepairs=8`, `canonicalRecoveredScreenSpecRefs=27`, `localReboundScreenSpecRefs=19`, `stableExactReferenceTotal=54`).
- Bounded Figma recheck после последнего smoke-среза: 8 exact manifest-backed portable paths подтверждены; оставшиеся 326 refs остаются source-blocked и не синтезируются из соседних raster-файлов.

## Незакрытые source/contract ограничения

`tools/audit_figma_handoff_contract.ps1` сейчас намеренно возвращает `ok=false` (fail-closed). Это не скрывается за runtime smoke:

- 42 weak publishable names;
- 17 weak component-map names;
- 9 weak browser-layer names;
- 326 screen-spec references без доверенного reference export; 54 стабильных exact refs подтверждены source-backed доказательством: 8 direct portable paths, 27 через recovery-index и 19 через строгий local rebind по normalized export-folder key + adjacent `screen.json` `node_id` + PNG SHA-256.

Свежий срез этого gate сохранён в `artifacts/nebula-figma-handoff-audit-after-hero-path-repair-20260916.json`: 95 publishables, 42 weak publishable names, 17 weak component-map names, 39 browser-layer names / 9 weak, 326 missing reference exports, mojibake — 0. Прямые пути и recovery refs проверяются отдельным source receipt; strict local rebind не делает semantic substitution и не заменяет отсутствующие exports соседними файлами. Реестр: `figma-manifest/reference-export-recovery.json`.

`tools/audit_figma_component_mapping.ps1` при этом проходит: все 95 publishables классифицированы, 24 unmapped имеют явную классификацию, missing owners — 0. До устранения source-ограничений нельзя объявлять полный Figma 1:1 handoff или подменять отсутствующие exports соседними asset-файлами. Strict readiness для `love-reading` теперь падает только на общий handoff-contract; reference map и source-файлы проходят.

## Граница Yii2-интеграции

При переносе сохранять route/page id, breakpoint variant, source/owner map, asset manifest и runtime interaction spec. UI не должен превращать недоступный сервис в успешный результат.

До backend-контракта остаются `NOT_PROVEN`:

- регистрация, login, reset, session, identity и RBAC;
- сохранение профиля/настроек и серверная история чата;
- realtime transport, presence, typing, reconnect и уведомления;
- credits/payment, idempotency, callbacks/refunds;
- production API и integration-sandbox (fallback/404 не являются backend proof).

Обязательные решения владельца продукта для Yii2: точная auth state machine (accepted/invalid/unavailable/unknown), session/RBAC модель, chat state machine и transport, payment/credits ledger с idempotency, а также правила asset URL/cache invalidation.

## Проверочные команды

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File tools/Test-NebulaCompareBoardSourceCoverage.ps1 -Json
powershell -NoProfile -ExecutionPolicy Bypass -File tools/verify_auth_source_lineage.ps1
powershell -NoProfile -ExecutionPolicy Bypass -File tools/verify_auth_paint_source_contract.ps1
powershell -NoProfile -ExecutionPolicy Bypass -File tools/audit_figma_component_mapping.ps1
powershell -NoProfile -ExecutionPolicy Bypass -File tools/audit_figma_handoff_contract.ps1
node tools/run_nebula_catalog_dom_smoke.mjs
node tools/run_nebula_yii2_host_dom_smoke.mjs
php integrations/yii2/nebulaLanding/tests/verify.php artifacts/nebula-yii2-package-proof-20260915.json
php integrations/yii2/nebulaLanding/tests/verify-frozen-static-pages.php artifacts/nebula-yii2-package-proof-20260915/frozen-static-pages.json
php integrations/yii2/nebulaLanding/tests/verify-all-psychics.php artifacts/nebula-yii2-package-proof-20260915/all-psychics.json
php integrations/yii2/nebulaLanding/tests/verify-faq.php artifacts/nebula-yii2-package-proof-20260915/faq.json
php integrations/yii2/nebulaLanding/tests/verify-404.php artifacts/nebula-yii2-package-proof-20260915/error404.json
```

Ожидаемая интерпретация: coverage, auth lineage, paint contract и component mapping должны быть `pass`; handoff audit остаётся `fail`, пока source-владелец не восстановит имена/breadcrumbs и missing reference exports. Это отдельный gate, его нельзя закрывать только исправлениями CSS/HTML.

## Изменения текущего среза

- `tools/Build-NebulaCompareBoardSourceCoverage.ps1` и `tools/Test-NebulaCompareBoardSourceCoverage.ps1`: сохраняют исходную ISO-строку `generated_at`, не допуская локальной DateTime-сериализации PowerShell.
- `tools/verify_runtime_state_proof.js`: использует установленный Chrome через `CHROME_BIN`, если он доступен, с безопасным fallback на bundled Playwright Chromium.
- `tools/Test-NebulaCompareBoardAcceptanceSurface.ps1`: regex с русскими текстовыми литералами переведены в Unicode escapes, чтобы verifier стабильно парсился в Windows PowerShell независимо от code page.
- `tools/run_nebula_catalog_dom_smoke.mjs`: добавлен exhaustive runtime/DOM smoke для всех 66 catalog routes на 1200/992/768/576/320; lazy-media settle проходит вертикальные документы и горизонтальные tracks, а image gate разделяет видимые pending-ресурсы и уже декодированные/скрытые изображения.
- `tools/run_nebula_catalog_dom_smoke.mjs`: навигационный timeout получает один bounded retry на новой page с сохранением route/listener proof; после возврата из full-page settle даётся отдельное lazy-media окно до 3 секунд. Текущий результат после чистого повторного прогона — `330/330`, HTTP `200/200`, navigation/page/console/local-request failures — `0`, overflow — `0`, broken/pending images — `0`, interactive rows — `330/330`.
- `tools/compare_home_png_breakpoints.ps1`, `tools/start_compare_board_preview.ps1`, `tools/start_compare_board_preview_hidden.vbs`, `tools/smoke_layout_capture_cards.ps1`: убрана зависимость readiness от исторического checkout и обязательного внешнего control URL; root/asset paths вычисляются локально, preview подтверждает hash served source, transient transport errors получают только один bounded retry.
- `tools/run_nebula_yii2_host_dom_smoke.mjs`: bounded lazy-media settle расширен на вертикальные документы и горизонтальные tracks; immutable static assets кэшируются между route/width cells, transport fetch повторяется, а только для source-backed route-specific `sprite.svg` предусмотрен явный fallback с отдельным счётчиком. Текущий Yii2-host gate — 75/75 pass.
- `tools/audit_figma_handoff_contract.ps1` и `figma-manifest/reference-export-recovery.json`: добавлена fail-closed проверка 54 стабильных exact Figma references (8 direct portable, 27 recovery-index, 19 strict local rebind) по node id, соседнему `screen.json` и SHA-256; остальные 326 missing references остаются блокером.
- `integrations/yii2/nebulaLanding`: source-backed frozen resources и pinned `PageData` hashes синхронизированы с текущим implementation source; добавлены отсутствовавшие blog/offcanvas/404 assets. Повторный PHP package suite — pass; это не отменяет host-mount/backend границу.
- `integrations/yii2/nebulaLanding/resources/frozen/blog-input/_unzipped/img/`: добавлены четыре отсутствовавших source-backed assets, которые ранее давали 404 на mounted Yii2 host; package proof теперь фиксирует их exact SHA-256.
- Public root `img/`: добавлены пять отсутствовавших WebP-представлений из `_unzipped/img` без изменения визуального источника: `love-hero-art-figma.webp`, `love-best-online-art-figma.webp`, `prn-hero-eye-clean.webp`, `prn-transform-img-1200-node-426-4581.webp`, `prn-tailored-art-figma-631.webp`; catalog smoke подтверждает их загрузку на целевых ширинах.
- `integrations/yii2/nebulaLanding/tests/verify-404.php`: static candidate pins обновлены до текущих source hashes после source-backed layout repair; проверка relocation/assets/route/render contract — pass.
- `_unzipped/img/breakpoints/love-reading-reference-map.json`: exact C76 map для пяти breakpoint exports.
- `experiments/nebula-account-chat-live-20260809/yii2/modules/nebulaAccount/resources/css/chatroom.css`: mobile chat actions и conversation filter получили отдельный 44×44 finger-target contract при сохранении компактной иконки.
- `experiments/nebula-account-chat-live-20260809/yii2/modules/nebulaAccount/resources/css/chat-overlays.css`: live chat expert-details favorite controls получили 44×44 target на desktop-mobile breakpoint и 18–21px source glyph.
- `experiments/nebula-account-chat-live-20260809/yii2/modules/nebulaAccount/resources/css/expert-picker-details.css`: expert-picker favorite получил 44×44 target на 576/320; те же изменения синхронизированы в `nebula-account/...` и текущем generated Yii2 asset `host/yii2/web/assets/3f6bda43/css/`.
- `artifacts/nebula-cabinet-deep-qa-20260915/mobile-hit-area-repair-20260915.json`: зафиксирован runtime proof 4 cases / 2 widths, без overflow и ошибок.
- `artifacts/nebula-yii2-frontend-completion-audit-20260915.json`: requirement-by-requirement completion audit; общий objective намеренно остаётся `false` до восстановления Figma source и owner decisions/backend handoff. Свежий portable readiness report `artifacts/nebula-1to1-readiness-current/20260916-011915/readiness-report.json` подтверждает: единственный fail — Figma handoff source gate.
