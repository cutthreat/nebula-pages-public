# Nebula Runbook

## Before Any Task
1. Read `AGENTS.md`
2. Read `VERSTKA_STANDARD.md`
3. Read `NEURO_VERSTKA_PREP.md`
4. Read `FIGMA_AUTONOMY_PROTOCOL.md`
5. Read `FIGMA_PATTERN_LIBRARY.md`
6. Read `FIGMA_LESSONS.jsonl`
7. Inspect the current reference files in `_unzipped`
8. Inspect the exported Figma screens in `Export НЕБУЛА 1200+`

## Bootstrap
- From the current checkout root, run `setup_env.ps1` through an explicit local path:
  ```powershell
  $workspaceRoot = (Get-Location).Path
  powershell -ExecutionPolicy Bypass -File (Join-Path $workspaceRoot 'setup_env.ps1')
  ```
- This installs and verifies:
  - `python-docx`
  - `lxml`
  - `playwright`
  - `pillow`
- It also checks that Chrome/Edge is available

## Local Preview
1. If needed, refresh the environment:
   ```powershell
   $workspaceRoot = (Get-Location).Path
   powershell -ExecutionPolicy Bypass -File (Join-Path $workspaceRoot 'setup_env.ps1') -SkipBrowserCheck
   ```
2. Start a static server:
   ```powershell
   $workspaceRoot = (Get-Location).Path
   Start-Process python -ArgumentList '-m http.server 8123' -WorkingDirectory (Join-Path $workspaceRoot '_unzipped') -WindowStyle Hidden
   ```
3. Open:
   - `http://127.0.0.1:8123/home.html`

## Compare Board Preview
- Canonical hidden launcher for the topnav compare board:
  ```powershell
  $workspaceRoot = (Get-Location).Path
  wscript.exe //B //NoLogo (Join-Path $workspaceRoot 'tools\start_compare_board_preview_hidden.vbs')
  ```
- This serves the workspace root on:
  - `http://127.0.0.1:4175/nebula-topnav-compare-board.html`
- To stop the preview cleanly:
  ```powershell
  $workspaceRoot = (Get-Location).Path
  powershell -ExecutionPolicy Bypass -File (Join-Path $workspaceRoot 'tools\stop_compare_board_preview.ps1') -Port 4175
  ```
- Do not start compare-board preview as a foreground `python -m http.server 4175` console if you want to avoid popup windows.

## Visual Check
- Compare the rendered page with:
  - the exact local Figma/export references recorded by the active screen spec and breakpoint map;
  - local export bundles under `figma-export/` when present;
  - local `_unzipped/img/breakpoints/*-reference-map.json` files for the corresponding page family.
- Check:
  - block order
  - typography
  - spacing
  - card sizes
  - quote block and image treatment
  - responsive behavior

## Accepted 1:1 Visual Gate
- Портативный запуск в другой Codex-среде: не подставляйте исторический `H:\\Nebula\\GPT` буквально. Сначала задайте корень текущего checkout; все четыре fail-closed аудитора принимают локальный `-WorkspaceRoot`, а handoff-аудитор сам находит `figma-export/**/browser-layer-index.json` или принимает явный `-BrowserLayerIndexPath`.
  ```powershell
  $workspaceRoot = (Get-Location).Path
  powershell -ExecutionPolicy Bypass -File (Join-Path $workspaceRoot 'tools\\audit_figma_component_mapping.ps1') -WorkspaceRoot $workspaceRoot
  powershell -ExecutionPolicy Bypass -File (Join-Path $workspaceRoot 'tools\\audit_figma_handoff_contract.ps1') -WorkspaceRoot $workspaceRoot
  powershell -ExecutionPolicy Bypass -File (Join-Path $workspaceRoot 'tools\\test_visual_contour_contract.ps1') -WorkspaceRoot $workspaceRoot
  powershell -ExecutionPolicy Bypass -File (Join-Path $workspaceRoot 'tools\\audit_verstka_1to1_readiness.ps1') -WorkspaceRoot $workspaceRoot -Page home
  ```
- Если в новом checkout несколько экспортов, для воспроизводимости можно указать `-BrowserLayerIndexPath (Join-Path $workspaceRoot 'figma-export\\<run>\\logs\\browser-layer-index.json')`; отсутствие индекса остаётся ошибкой, а не превращается в pass.
- Before saying a page is `accepted_1to1`, verify the actual Figma/export references for every required breakpoint. Local `_unzipped/img/breakpoints` files are a cache, not proof that Figma has or lacks an ethalon.
- Full readiness audit before a serious 1:1 task:
  ```powershell
  powershell -ExecutionPolicy Bypass -File (Join-Path $workspaceRoot 'tools\audit_verstka_1to1_readiness.ps1') -WorkspaceRoot $workspaceRoot -Page home -RunCaptureSmoke -RunHomeCompareSmoke -RunRuntimeStateProof
  ```
- For a heavier proof packet, add `-RunHomeCompareSmoke`; this runs a 1200px Figma-vs-live diff and can take longer.
- Component/code owner audit:
  ```powershell
  powershell -ExecutionPolicy Bypass -File (Join-Path $workspaceRoot 'tools\audit_figma_component_mapping.ps1') -WorkspaceRoot $workspaceRoot
  ```
- This is the local Code Connect-like layer: every recurring Figma component group must map to a code owner and verifier, and every `other/unmapped` item must be classified before 1:1 work can rely on it.
- Handoff naming/breadcrumb/export audit:
  ```powershell
  powershell -ExecutionPolicy Bypass -File (Join-Path $workspaceRoot 'tools\audit_figma_handoff_contract.ps1') -WorkspaceRoot $workspaceRoot
  ```
- This gate is fail-close. It blocks trust in Figma handoff when publishable names are generic, breadcrumbs are missing, screen specs point at unrelated export files, or contract-bearing text shows mojibake.
- For Home, the current frozen reference map is:
  - `H:\Nebula\GPT\_unzipped\img\breakpoints\home-reference-map.json`
- Runtime interaction proof for Home:
  ```powershell
  $env:NODE_PATH='C:\Users\alexe\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\node_modules'
  & 'C:\Users\alexe\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe' (Join-Path $workspaceRoot 'tools\verify_runtime_state_proof.js') --spec (Join-Path $workspaceRoot 'tools\runtime-proof-specs\home.runtime-proof.json') --strict
  ```
- This proof is diagnostic-only. It validates runtime states like accordion/theme/sticky behavior and must not override Figma/export acceptance.
- Contract verifier:
  ```powershell
  powershell -ExecutionPolicy Bypass -File (Join-Path $workspaceRoot 'tools\test_visual_contour_contract.ps1') -WorkspaceRoot $workspaceRoot
  ```
- Home breakpoint compare against Figma refs:
  ```powershell
  $workspaceRoot = (Get-Location).Path
  powershell -ExecutionPolicy Bypass -File (Join-Path $workspaceRoot 'tools\compare_home_png_breakpoints.ps1') -WorkspaceRoot $workspaceRoot -OutDir (Join-Path $workspaceRoot 'artifacts\visual-diff\home-figma-all-breakpoints')
  ```
- PASS for reference readiness means `missingFigmaReferences = 0`, every required breakpoint has a source node in the map, and the comparison report contains Figma comparisons, not only Pavlo/control comparisons.
- Control URL comparison is optional and diagnostic-only; by default the compare tool uses local Figma/export references and does not require network access. Pavlo/control and Layout Capture Card are diagnostic controls. They can show defects and good responsive behavior, but they cannot replace Figma/export in the acceptance decision.
- The finish checklist for this layer lives in:
  - `H:\Nebula\GPT\FIGMA_HANDOFF_CHECKLIST.md`

## Experience-Led Repair Order
- If evidence is stale, refresh proof before editing.
- If proof is produced by the wrong tool mode, fix the tool mode before editing CSS.
- If a defect repeats across a page family, repair the shared owner instead of patching one visible instance.
- If a user points to a missed visual defect, add or run a detector for that defect class before doing another broad polish pass.
- If the page has late owner CSS, inspect it as runtime source, not as documentation.
- If a breakpoint is involved, verify both canonical widths and seam widths when the defect touches media-query handoff.

## Accordion / FAQ Contract Check
- Use this gate whenever a page contains FAQ, SEO dropdowns, native `<details>`, or `data-accordion` blocks.
- Selected page:
  ```powershell
  $env:NODE_PATH='C:\Users\alexe\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\node_modules'
  & 'C:\Users\alexe\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe' H:\Nebula\GPT\tools\verify_accordion_contract.js --page all-psychic-new.html --viewport 1200 --out H:\GPT-Codex\artifacts\nebula-debug\accordion-contract-all-psychic-1200.json
  ```
- All accordion pages:
  ```powershell
  $env:NODE_PATH='C:\Users\alexe\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\node_modules'
  & 'C:\Users\alexe\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe' H:\Nebula\GPT\tools\verify_accordion_contract.js --all --accordion-only --out H:\GPT-Codex\artifacts\nebula-debug\accordion-contract-all-accordion-pages-1200.json
  ```
- For breakpoint-sensitive pages, run the same page at `1200`, `992`, `768`, `576`, and `320`.
- PASS means: body content exists, click opens the target item, single-open roots close siblings, and `aria-expanded` / open classes / icon state remain synchronized.

## Layout Capture Card Check
- Use this diagnostic gate before and after visually risky layout repairs: hero, repeated cards, FAQ/SEO blocks, wide-screen shell, and mobile collapse.
- Fast metrics mode, no PNG artifacts:
  ```powershell
  $env:NODE_PATH='C:\Users\alexe\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\node_modules'
  & 'C:\Users\alexe\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe' H:\Nebula\GPT\tools\capture_layout_cards.js --file-url --page all-psychic-new.html --viewport 1200 --height 1000 --card 'header=.site-header' --card 'hero=.apn-hero' --card 'answers=.apn-answers, .apn-answer-item' --max-per-card 3 --strict --out H:\GPT-Codex\artifacts\layout-cards\all-psychic-1200-fast.json
  ```
- Prefer local HTTP over `--file-url` when the page uses SVG sprites, fonts, or runtime paths that depend on same-origin loading.
- Bounded proof mode with section PNGs:
  ```powershell
  $env:NODE_PATH='C:\Users\alexe\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\node_modules'
  & 'C:\Users\alexe\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe' H:\Nebula\GPT\tools\capture_layout_cards.js --file-url --page all-psychic-new.html --viewport 1200 --height 1000 --card 'header=.site-header' --card 'hero=.apn-hero' --max-per-card 1 --card-screenshots --strict --out H:\GPT-Codex\artifacts\layout-cards\all-psychic-1200-proof.json
  ```
- Full contour smoke before relying on the tool:
  ```powershell
  powershell -ExecutionPolicy Bypass -File H:\Nebula\GPT\tools\smoke_layout_capture_cards.ps1
  ```
- PASS means: script syntax is valid, target pages open through local HTTP, no horizontal overflow findings, no page errors, and each capture stays below the configured duration threshold.
- Treat Layout Capture Card JSON as diagnostic evidence. It does not replace Figma export, compare-board, or accepted reference truth.
- If screenshots are used, first ensure lazy images are loaded. Do not use a naive long-page `fullPage` screenshot as acceptance proof when fixed headers or sticky elements are present.

## Implementation Rules
- Do not introduce new libraries unless explicitly required
- Do not replace coded blocks with images when the block can be built in HTML/CSS
- Keep Bootstrap 4.6 and existing jQuery behavior
- Reuse the approved Home patterns first
- Use Figma export numbering as the order source

## Context Compression
- Before compacting context, reread:
  - `AGENTS.md`
  - `VERSTKA_STANDARD.md`
  - `NEURO_VERSTKA_PREP.md`
  - `FIGMA_PATTERN_LIBRARY.md`
  - `FIGMA_LESSONS.jsonl`
- Include:
  - current goal
  - finished work
  - changed files
  - risks
  - open questions
  - next actions

## Offline Figma Fallback
- If Figma MCP quota blocks extraction, generate the local manifest instead:
  - `powershell -ExecutionPolicy Bypass -File H:\Nebula\GPT\tools\generate_figma_manifest.ps1`
- Read the results from:
  - `H:\Nebula\GPT\figma-manifest\figma-manifest.local.json`
  - `H:\Nebula\GPT\figma-manifest\figma-links.local.csv`
- Use the fallback manifest together with `_unzipped` and the export bundle to implement and verify screens without guessing.

## Live Browser Export Mode
- When the live browser session can open the Figma file, use it before falling back to offline-only extraction.
- Capture:
  - file metadata
  - page tree
  - visible layer names
  - selected frame / node state
  - screenshots for review
- Store package outputs in:
  - `H:\Nebula\GPT\figma-export\<timestamp>\`
- Package the outputs with:
  - `powershell -ExecutionPolicy Bypass -File H:\Nebula\GPT\tools\build_figma_export_package.ps1 -WorkspaceRoot H:\Nebula\GPT`
- If native export is blocked by permissions, keep the blocker in the package and continue with manifest + screenshots.

## Figma Scalper Deep Control Plane (Primary)
- Canonical tool contract:
  - `H:\Nebula\GPT\FIGMA_SCALPER_CONTROL_PLANE.md`
- Project-bound config:
  - `H:\Nebula\GPT\figma-manifest\figma-target.json`
- Deep run command (CMD):
  - `H:\Nebula\GPT\tools\run_figma_scalper_deep.cmd`
- Deep run command (PowerShell):
  - `powershell -ExecutionPolicy Bypass -File H:\Nebula\GPT\tools\run_figma_scalper_deep.ps1 -WorkspaceRoot H:\Nebula\GPT`
- Requires running local service:
  - `H:\GPT-Codex\tools\figma-scalper-chrome\start-figma-scalper-service.cmd`

Artifacts:
- run result snapshot:
  - `H:\Nebula\GPT\figma-export\last-scalper-run.json`
- operation log:
  - `H:\Nebula\GPT\figma-export\figma-scalper-ops.log.jsonl`
- deep extraction package:
  - `H:\Nebula\GPT\figma-export\scalper\<timestamp>-<filekey>\`

Deep package adds:
- `deep/node-index.json` + `deep/node-index.csv`
- `deep/prototype-graph.json` + `deep/prototype-graph.csv`
- `deep/components-inventory.json`
- `deep/styles-inventory.json`
- Optional snapshot fallback for missing screenshots:
  - `H:\Nebula\GPT\tools\capture_missing_figma_screens_playwright.py`
  - capture auth state:
    - `H:\Nebula\GPT\tools\capture-playwright-state.cmd`

## Screen Spec Generation
- Convert the manifest into screen-level specs:
  - `powershell -ExecutionPolicy Bypass -File H:\Nebula\GPT\tools\generate_screen_specs.ps1`
- Read the results from:
  - `H:\Nebula\GPT\figma-manifest\screen-specs\`
- Use the screen-spec files as the direct input for implementation tasks.

## Autonomous Free Learning Loop
1. Run the local polygon:
   ```powershell
   powershell -ExecutionPolicy Bypass -File H:\Nebula\GPT\tools\run_autonomous_free_learning.ps1 -WorkspaceRoot H:\Nebula\GPT
   ```
2. Read the latest report:
   - `H:\Nebula\GPT\learning-reports\autonomous-free-learning-latest.json`
   - `H:\Nebula\GPT\learning-reports\autonomous-free-learning-latest.md`
3. Use the queue to decide whether to verify, harden, or implement a screen.
4. Record reusable rules in `FIGMA_LESSONS.jsonl`.
5. Promote reusable rules into `FIGMA_AUTONOMY_PROTOCOL.md`, `VERSTKA_STANDARD.md`, or `FIGMA_PATTERN_LIBRARY.md`.
6. If you want the loop to run on schedule, install the daily task:
   ```powershell
   powershell -ExecutionPolicy Bypass -File H:\Nebula\GPT\tools\install_autonomous_free_learning_task.ps1 -WorkspaceRoot H:\Nebula\GPT
   ```
7. If the Telegram bot needs a fresh payload, regenerate it:
   ```powershell
   powershell -ExecutionPolicy Bypass -File H:\Nebula\GPT\tools\export_free_learning_telegram_payload.ps1 -WorkspaceRoot H:\Nebula\GPT
   ```
8. If you are wiring Telegram, use the bridge document:
   - `H:\Nebula\GPT\TELEGRAM_BRIDGE.md`
