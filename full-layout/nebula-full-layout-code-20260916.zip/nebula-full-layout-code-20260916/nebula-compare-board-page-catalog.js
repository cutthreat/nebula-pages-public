window.NEBULA_PAGE_CATALOG = {
  "schema": "oracle_nebula.compare_board_page_catalog.v1",
  "generated_at": "2026-07-30T00:00:00Z",
  "status": "local_preview_catalog_current_source_presence_safe_no_acceptance_claim",
  "page_count": 66,
  "family_count": 7,
  "source_policy": "Figma visual source is present; exact page/breakpoint binding and panel raster readiness stay explicit; unresolved binding is never source absence or acceptance evidence",
  "families": [
    {
      "id": "public-core",
      "label": "Публичные",
      "text": "Главные, информационные, editorial и support-страницы.",
      "pages": [
        {
          "id": "404",
          "label": "404",
          "pageSrc": "nebula-easy-404.html",
          "manifestTitle": "404 · exact C76 source 1200/992/768/576",
          "lane": "public.404.default",
          "stateId": "404.default",
          "reviewClassification": "current_reviewable_source_refreshed_audit_pending",
          "governedStatus": "source_live_pair_current_strict_visual_audit_required_320_c76_frame_unproven",
          "acceptanceStatus": "not_accepted",
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [
            "320"
          ],
          "sourceRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\c76-normalized-export-20260727\\404.json",
            "C76M54fY7z926wIQoWFh8Y / ,,,",
            "F:\\Figma Nebula\\c76-source-index-20260727\\C76-PAGE-CROSSWALK-20260727.json"
          ],
          "proofRefs": [
            "H:\\GPT-Codex\\.ops\\chief-of-staff\\proofs\\oracle-nebula\\compare-board-404-source-truth-repair-20260716\\closeout.md"
          ],
          "blockedReason": "Exact C76 page-level source is bound for 1200/992/768/576. The package records no proven 320 page-level frame.",
          "variantOverrides": {
            "576": {
              "width": 576,
              "sourceWidth": 576,
              "sourceHeight": 1380,
              "reason": "Exact C76 node 1064:23692."
            },
            "768": {
              "width": 768,
              "sourceWidth": 768,
              "sourceHeight": 1550,
              "reason": "Exact C76 node 1064:23542."
            },
            "992": {
              "width": 992,
              "sourceWidth": 992,
              "sourceHeight": 1420,
              "reason": "Exact C76 node 1064:23394."
            },
            "1200": {
              "width": 1200,
              "sourceWidth": 1200,
              "sourceHeight": 1370,
              "reason": "Exact C76 node 1064:23227."
            }
          },
          "jobs": [
            {
              "name": "404-c76-1200",
              "status": "export_exists",
              "variantId": "1200",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/404-1200-1064-23227.png"
              ]
            },
            {
              "name": "404-c76-992",
              "status": "export_exists",
              "variantId": "992",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/404-992-1064-23394.png"
              ]
            },
            {
              "name": "404-c76-768",
              "status": "export_exists",
              "variantId": "768",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/404-768-1064-23542.png"
              ]
            },
            {
              "name": "404-c76-576",
              "status": "export_exists",
              "variantId": "576",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/404-576-1064-23692.png"
              ]
            }
          ]
        },
        {
          "id": "about-us",
          "label": "About Us",
          "pageSrc": "_unzipped/about-us-new.html",
          "manifestTitle": "About Us · source present / page-level crosswalk pending",
          "lane": "local.preview.public-core",
          "stateId": "local.preview.about-us",
          "reviewClassification": "source_present_page_level_unresolved",
          "governedStatus": "source_present_current_c76_page_level_crosswalk_pending",
          "acceptanceStatus": "not_accepted",
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [],
          "sourceRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\truth-packets\\about-us-c76-source-discovery-20260716\\source-discovery-manifest.json",
            "H:\\Nebula\\GPT\\figma-manifest\\truth-packets\\faq-91ku-source-publication-20260716\\public-core-91ku-node-map.json",
            "91KU4ORjZ5mQUv9PvsucGV / Page 0:1 / no exact About Us frame"
          ],
          "proofRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\status-packets\\compare-board-canonical-source-coverage.registry.json",
            "H:\\Nebula\\GPT\\docs\\oracle-nebula\\about-us-source-boundary-closeout-2026-07-12.md"
          ],
          "blockedReason": "The current C76 bundle contains relevant labels/content, but an exact public page-level frame is not yet bound. This is not source absence.",
          "sourceDiscoveryStatus": "source_present_page_level_unresolved",
          "jobs": []
        },
        {
          "id": "blog",
          "label": "Blog",
          "pageSrc": "nebula-easy-blog.html",
          "implementationAlias": "blog-new",
          "manifestTitle": "Blog · C76 source/live · strict visual audit required",
          "lane": "source.live.public-core",
          "stateId": "blog.state.default",
          "reviewClassification": "light_layout_accepted_source_exact",
          "governedStatus": "accepted",
          "acceptanceStatus": "accepted",
          "sourceComparable": true,
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [],
          "sourceRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\c76-normalized-export-20260727\\blog.json",
            "C76M54fY7z926wIQoWFh8Y / ,,,,",
            "F:\\Figma Nebula\\c76-source-index-20260727\\C76-PAGE-CROSSWALK-20260727.json"
          ],
          "proofRefs": [
            "H:\\GPT-Codex\\.ops\\chief-of-staff\\proofs\\oracle-nebula\\public-core-blog-board-materialization-source-publication-20260716\\source-authority-binding.json"
          ],
          "blockedReason": null,
          "variantOverrides": {
            "320": {
              "width": 320,
              "sourceWidth": 320,
              "sourceHeight": 6286,
              "reason": "Exact C76 node 1005:22168."
            },
            "576": {
              "width": 576,
              "sourceWidth": 576,
              "sourceHeight": 3318,
              "reason": "Exact C76 node 1002:23955."
            },
            "768": {
              "width": 768,
              "sourceWidth": 768,
              "sourceHeight": 3632,
              "reason": "Exact C76 node 1002:21942."
            },
            "992": {
              "width": 992,
              "sourceWidth": 992,
              "sourceHeight": 3292,
              "reason": "Exact C76 node 1001:20800."
            },
            "1200": {
              "width": 1200,
              "sourceWidth": 1200,
              "sourceHeight": 3142,
              "reason": "Exact C76 node 642:5788."
            }
          },
          "jobs": [
            {
              "name": "blog-c76-1200",
              "status": "export_exists",
              "variantId": "1200",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/blog-1200-642-5788.png"
              ]
            },
            {
              "name": "blog-c76-992",
              "status": "export_exists",
              "variantId": "992",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/blog-992-1001-20800.png"
              ]
            },
            {
              "name": "blog-c76-768",
              "status": "export_exists",
              "variantId": "768",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/blog-768-1002-21942.png"
              ]
            },
            {
              "name": "blog-c76-576",
              "status": "export_exists",
              "variantId": "576",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/blog-576-1002-23955.png"
              ]
            },
            {
              "name": "blog-c76-320",
              "status": "export_exists",
              "variantId": "320",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/blog-320-1005-22168.png"
              ]
            }
          ]
        },
        {
          "id": "blog-input",
          "label": "Blog Input",
          "pageSrc": "nebula-easy-blog-input.html",
          "implementationAlias": "blog-input-new",
          "manifestTitle": "Blog Input · C76 source/live · strict visual audit required",
          "lane": "source.live.public-core",
          "stateId": "blog-input.state.default",
          "reviewClassification": "current_source_live_pair_strict_visual_audit_required",
          "governedStatus": "source_live_pair_current_strict_visual_audit_required",
          "acceptanceStatus": "not_accepted",
          "sourceComparable": true,
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [],
          "sourceRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\c76-normalized-export-20260727\\blog-input.json",
            "C76M54fY7z926wIQoWFh8Y / ,,,,",
            "F:\\Figma Nebula\\c76-source-index-20260727\\C76-PAGE-CROSSWALK-20260727.json"
          ],
          "proofRefs": [
            "H:\\GPT-Codex\\.ops\\chief-of-staff\\proofs\\oracle-nebula\\blog-input-c76-source-recovery-and-publication-20260716\\source-authority-binding.json"
          ],
          "blockedReason": "Exact current C76 page-level frames are exported and hash-bound for all five widths; visual acceptance remains a separate gate.",
          "variantOverrides": {
            "320": {
              "width": 320,
              "sourceWidth": 320,
              "sourceHeight": 9886,
              "reason": "Exact C76 node 1008:23368."
            },
            "576": {
              "width": 576,
              "sourceWidth": 576,
              "sourceHeight": 6624,
              "reason": "Exact C76 node 1008:22880."
            },
            "768": {
              "width": 768,
              "sourceWidth": 768,
              "sourceHeight": 6548,
              "reason": "Exact C76 node 1006:25391."
            },
            "992": {
              "width": 992,
              "sourceWidth": 992,
              "sourceHeight": 7117,
              "reason": "Exact C76 node 1006:23266."
            },
            "1200": {
              "width": 1200,
              "sourceWidth": 1200,
              "sourceHeight": 6667,
              "reason": "Exact C76 node 643:7448."
            }
          },
          "jobs": [
            {
              "name": "blog-input-c76-1200",
              "status": "export_exists",
              "variantId": "1200",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/blog-input-1200-643-7448.png"
              ]
            },
            {
              "name": "blog-input-c76-992",
              "status": "export_exists",
              "variantId": "992",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/blog-input-992-1006-23266.png"
              ]
            },
            {
              "name": "blog-input-c76-768",
              "status": "export_exists",
              "variantId": "768",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/blog-input-768-1006-25391.png"
              ]
            },
            {
              "name": "blog-input-c76-576",
              "status": "export_exists",
              "variantId": "576",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/blog-input-576-1008-22880.png"
              ]
            },
            {
              "name": "blog-input-c76-320",
              "status": "export_exists",
              "variantId": "320",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/blog-input-320-1008-23368.png"
              ]
            }
          ]
        },
        {
          "id": "careers-join",
          "label": "Careers Join",
          "pageSrc": "_unzipped/careers-join-new.html",
          "manifestTitle": "Careers Join · local implementation fixture",
          "lane": "local.preview.public-core",
          "stateId": "local.preview.careers-join",
          "reviewClassification": "current_live_preview_source_unverified",
          "governedStatus": "local_preview_only_source_refresh_required",
          "acceptanceStatus": "not_accepted",
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "sourceRefs": [],
          "proofRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\status-packets\\compare-board-local-page-catalog-20260714.json"
          ],
          "blockedReason": "Live-верстка доступна для просмотра. Текущая source/live пара и свежая приемка не опубликованы; старые архивные exports не используются.",
          "jobs": []
        },
        {
          "id": "contact-us",
          "label": "Contact Us",
          "pageSrc": "_unzipped/contact-us-new.html",
          "manifestTitle": "Contact Us · source present / page-level crosswalk pending",
          "lane": "local.preview.public-core",
          "stateId": "local.preview.contact-us",
          "reviewClassification": "source_present_page_level_unresolved",
          "governedStatus": "source_present_current_c76_page_level_crosswalk_pending",
          "acceptanceStatus": "not_accepted",
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [],
          "sourceRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\truth-packets\\contact-us-c76-source-discovery-20260716\\source-discovery-manifest.json",
            "H:\\Nebula\\GPT\\figma-manifest\\truth-packets\\faq-91ku-source-publication-20260716\\public-core-91ku-node-map.json",
            "91KU4ORjZ5mQUv9PvsucGV / Page 0:1 / no exact public Contact Us frame"
          ],
          "proofRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\status-packets\\compare-board-canonical-source-coverage.registry.json"
          ],
          "blockedReason": "The current C76 bundle contains relevant labels/content, but an exact public page-level frame is not yet bound. This is not source absence.",
          "sourceDiscoveryStatus": "source_present_page_level_unresolved",
          "jobs": []
        },
        {
          "id": "faq",
          "label": "FAQ",
          "pageSrc": "nebula-easy-faq.html",
          "manifestTitle": "FAQ · exact 91KU source 1200/992/768/576/320",
          "lane": "source.live.public-core",
          "stateId": "faq.state.default",
          "reviewClassification": "current_source_live_pair_strict_visual_audit_required",
          "governedStatus": "source_live_pair_current_strict_visual_audit_required",
          "acceptanceStatus": "not_accepted",
          "sourceComparable": true,
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [],
          "sourceRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\c76-normalized-export-20260727\\faq.json",
            "C76M54fY7z926wIQoWFh8Y / ,,,,",
            "F:\\Figma Nebula\\c76-source-index-20260727\\C76-PAGE-CROSSWALK-20260727.json"
          ],
          "proofRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\truth-packets\\faq-91ku-source-publication-20260716\\public-core-91ku-node-map.json",
            "H:\\Nebula\\GPT\\figma-manifest\\truth-packets\\public-core-source-authority-recovery-20260716\\family-source-authority-blocker.json",
            "H:\\Nebula\\GPT\\figma-manifest\\status-packets\\compare-board-canonical-source-coverage.registry.json"
          ],
          "blockedReason": "Exact current C76 page-level frames are exported and hash-bound for all five widths; visual acceptance remains a separate gate.",
          "sourceDiscoveryStatus": "published_exact_source",
          "variantOverrides": {
            "320": {
              "width": 320,
              "sourceWidth": 320,
              "sourceHeight": 6255,
              "reason": "Exact 91KU node 868:8218."
            },
            "576": {
              "width": 576,
              "sourceWidth": 576,
              "sourceHeight": 4680,
              "reason": "Exact 91KU node 868:7775."
            },
            "768": {
              "width": 768,
              "sourceWidth": 768,
              "sourceHeight": 4780,
              "reason": "Exact 91KU node 868:7221."
            },
            "992": {
              "width": 992,
              "sourceWidth": 992,
              "sourceHeight": 4880,
              "reason": "Exact 91KU node 866:7511."
            },
            "1200": {
              "width": 1200,
              "sourceWidth": 1200,
              "sourceHeight": 4730,
              "reason": "Exact 91KU node 866:7108."
            }
          },
          "jobs": [
            {
              "name": "faq-c76-1200",
              "status": "export_exists",
              "variantId": "1200",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/faq-1200-866-7108.png"
              ]
            },
            {
              "name": "faq-c76-992",
              "status": "export_exists",
              "variantId": "992",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/faq-992-866-7511.png"
              ]
            },
            {
              "name": "faq-c76-768",
              "status": "export_exists",
              "variantId": "768",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/faq-768-868-7221.png"
              ]
            },
            {
              "name": "faq-c76-576",
              "status": "export_exists",
              "variantId": "576",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/faq-576-868-7775.png"
              ]
            },
            {
              "name": "faq-c76-320",
              "status": "export_exists",
              "variantId": "320",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/faq-320-868-8218.png"
              ]
            }
          ]
        },
        {
          "id": "home",
          "label": "Home",
          "pageSrc": "_unzipped/home.html",
          "manifestTitle": "Home · C76 source/live · strict visual audit required",
          "lane": "source.live.public-core",
          "stateId": "home.state.default",
          "reviewClassification": "current_source_live_pair_strict_visual_audit_required",
          "governedStatus": "source_live_pair_current_strict_visual_audit_required",
          "acceptanceStatus": "not_accepted",
          "sourceComparable": true,
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [],
          "sourceRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\truth-packets\\home-c76-source-refresh-20260721\\source-refresh-manifest.json",
            "C76M54fY7z926wIQoWFh8Y / 9:9,35:2,49:194,51:239,530:3176"
          ],
          "proofRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\truth-packets\\public-home-master-c76-source-packet-2026-07-13.json",
            "H:\\GPT-Codex\\.ops\\chief-of-staff\\proofs\\oracle-nebula\\home-c76-exact-raster-publication-20260721\\source-authority-binding.json"
          ],
          "blockedReason": "Точная C76 source/live пара опубликована для всех пяти canonical widths только для строгого visual audit; not_accepted, без acceptance/promotion.",
          "variantOverrides": {
            "320": {
              "width": 320,
              "sourceWidth": 320,
              "sourceHeight": 13112,
              "reason": "Exact C76 node 530:3176."
            },
            "576": {
              "width": 576,
              "sourceWidth": 576,
              "sourceHeight": 11249,
              "reason": "Exact C76 node 51:239."
            },
            "768": {
              "width": 768,
              "sourceWidth": 768,
              "sourceHeight": 11944,
              "reason": "Exact C76 node 49:194."
            },
            "992": {
              "width": 992,
              "sourceWidth": 992,
              "sourceHeight": 12265,
              "reason": "Exact C76 node 35:2."
            },
            "1200": {
              "width": 1200,
              "sourceWidth": 1200,
              "sourceHeight": 13431,
              "reason": "Exact C76 node 9:9."
            }
          },
          "jobs": [
            {
              "name": "home-c76-1200",
              "status": "export_exists",
              "variantId": "1200",
              "expectedArtifacts": [
                "compare-board-sources/home-c76-1200.png"
              ]
            },
            {
              "name": "home-c76-992",
              "status": "export_exists",
              "variantId": "992",
              "expectedArtifacts": [
                "compare-board-sources/home-c76-992.png"
              ]
            },
            {
              "name": "home-c76-768",
              "status": "export_exists",
              "variantId": "768",
              "expectedArtifacts": [
                "compare-board-sources/home-c76-768.png"
              ]
            },
            {
              "name": "home-c76-576",
              "status": "export_exists",
              "variantId": "576",
              "expectedArtifacts": [
                "compare-board-sources/home-c76-576.png"
              ]
            },
            {
              "name": "home-c76-320",
              "status": "export_exists",
              "variantId": "320",
              "expectedArtifacts": [
                "compare-board-sources/home-c76-320.png"
              ]
            }
          ]
        }
      ]
    },
    {
      "id": "money-readings",
      "label": "Лендинги / Readings",
      "text": "Коммерческие и тематические landing pages консультаций.",
      "pages": [
        {
          "id": "ask-psychic",
          "label": "Ask Psychic",
          "pageSrc": "_unzipped/ask-psychic-new.html",
          "manifestTitle": "Ask Psychic · local implementation fixture",
          "lane": "local.preview.money-readings",
          "stateId": "local.preview.ask-psychic",
          "reviewClassification": "current_live_preview_source_unverified",
          "governedStatus": "local_preview_only_source_refresh_required",
          "acceptanceStatus": "not_accepted",
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "sourceRefs": [],
          "proofRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\status-packets\\compare-board-local-page-catalog-20260714.json"
          ],
          "blockedReason": "Live-верстка доступна для просмотра. Текущая source/live пара и свежая приемка не опубликованы; старые архивные exports не используются.",
          "jobs": []
        },
        {
          "id": "astrology-reading",
          "label": "Astrology Reading",
          "pageSrc": "_unzipped/astrology-reading-new.html",
          "manifestTitle": "Astrology Reading · local implementation fixture",
          "lane": "local.preview.money-readings",
          "stateId": "local.preview.astrology-reading",
          "reviewClassification": "source_present_exact_candidate_route_unresolved",
          "governedStatus": "source_present_exact_candidate_route_semantics_open",
          "acceptanceStatus": "not_accepted",
          "sourceComparable": false,
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [],
          "sourceRefs": [
            "F:\\Figma Nebula\\c76-official-copy-pending-candidate-delta-20260728\\PENDING-OFFICIAL-COPY-CANDIDATE-DELTA.json"
          ],
          "proofRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\status-packets\\compare-board-local-page-catalog-20260714.json"
          ],
          "blockedReason": "Пять width-кандидатов из Figma найдены, но набор Astrology неоднозначен и route/state semantics не связаны доказательством.",
          "sourceDiscoveryStatus": "candidate_exact_source_route_open",
          "jobs": []
        },
        {
          "id": "aura-reading",
          "label": "Aura Reading",
          "pageSrc": "aura-reading-new.html",
          "implementationAlias": "aura-reading-new",
          "manifestTitle": "Aura Reading · C76 source/live · strict visual audit required",
          "lane": "source.live.money-readings",
          "stateId": "aura-reading.state.default",
          "reviewClassification": "current_source_live_pair_strict_visual_audit_required",
          "governedStatus": "source_live_pair_current_strict_visual_audit_required",
          "acceptanceStatus": "not_accepted",
          "sourceComparable": true,
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [],
          "sourceRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\c76-normalized-export-20260727\\aura-reading.json",
            "C76M54fY7z926wIQoWFh8Y / ,,,,",
            "F:\\Figma Nebula\\c76-source-index-20260727\\C76-PAGE-CROSSWALK-20260727.json"
          ],
          "proofRefs": [
            "H:\\GPT-Codex\\.ops\\chief-of-staff\\proofs\\oracle-nebula\\aura-reading-c76-source-publication-20260720\\source-authority-binding.json"
          ],
          "blockedReason": "Exact current C76 page-level frames are exported and hash-bound for all five widths; visual acceptance remains a separate gate.",
          "variantOverrides": {
            "320": {
              "width": 320,
              "sourceWidth": 320,
              "sourceHeight": 8516,
              "reason": "Exact C76 node 906:17985."
            },
            "576": {
              "width": 576,
              "sourceWidth": 576,
              "sourceHeight": 7430,
              "reason": "Exact C76 node 906:17772."
            },
            "768": {
              "width": 768,
              "sourceWidth": 768,
              "sourceHeight": 7290,
              "reason": "Exact C76 node 902:13500."
            },
            "992": {
              "width": 992,
              "sourceWidth": 992,
              "sourceHeight": 6917,
              "reason": "Exact C76 node 902:13967."
            },
            "1200": {
              "width": 1200,
              "sourceWidth": 1200,
              "sourceHeight": 7321,
              "reason": "Exact C76 node 902:13736."
            }
          },
          "jobs": [
            {
              "name": "aura-reading-c76-1200",
              "status": "export_exists",
              "variantId": "1200",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/aura-reading-1200-902-13736.png"
              ]
            },
            {
              "name": "aura-reading-c76-992",
              "status": "export_exists",
              "variantId": "992",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/aura-reading-992-902-13967.png"
              ]
            },
            {
              "name": "aura-reading-c76-768",
              "status": "export_exists",
              "variantId": "768",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/aura-reading-768-902-13500.png"
              ]
            },
            {
              "name": "aura-reading-c76-576",
              "status": "export_exists",
              "variantId": "576",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/aura-reading-576-906-17772.png"
              ]
            },
            {
              "name": "aura-reading-c76-320",
              "status": "export_exists",
              "variantId": "320",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/aura-reading-320-906-17985.png"
              ]
            }
          ]
        },
        {
          "id": "career-reading",
          "label": "Career Reading",
          "pageSrc": "_unzipped/career-reading-new.html",
          "manifestTitle": "Career Reading · local implementation fixture",
          "lane": "local.preview.money-readings",
          "stateId": "local.preview.career-reading",
          "reviewClassification": "current_live_preview_source_unverified",
          "governedStatus": "local_preview_only_source_refresh_required",
          "acceptanceStatus": "not_accepted",
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "sourceRefs": [],
          "proofRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\status-packets\\compare-board-local-page-catalog-20260714.json"
          ],
          "blockedReason": "Live-верстка доступна для просмотра. Текущая source/live пара и свежая приемка не опубликованы; старые архивные exports не используются.",
          "jobs": []
        },
        {
          "id": "cheap-psychic",
          "label": "Cheap Psychic",
          "pageSrc": "nebula-easy-cheap-psychic.html",
          "implementationAlias": "cheap-psychic-new",
          "manifestTitle": "Cheap Psychic · C76 source/live · strict visual audit required",
          "lane": "source.live.money-readings",
          "stateId": "cheap-psychic.state.default",
          "reviewClassification": "current_source_live_pair_strict_visual_audit_required",
          "governedStatus": "source_live_pair_current_strict_visual_audit_required",
          "acceptanceStatus": "not_accepted",
          "sourceComparable": true,
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [],
          "sourceRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\c76-normalized-export-20260727\\cheap-psychic.json",
            "C76M54fY7z926wIQoWFh8Y / ,,,,",
            "F:\\Figma Nebula\\c76-source-index-20260727\\C76-PAGE-CROSSWALK-20260727.json"
          ],
          "proofRefs": [
            "H:\\GPT-Codex\\.ops\\chief-of-staff\\proofs\\oracle-nebula\\cheap-psychic-c76-source-publication-20260720\\source-authority-binding.json"
          ],
          "blockedReason": "Exact current C76 page-level frames are exported and hash-bound for all five widths; visual acceptance remains a separate gate.",
          "variantOverrides": {
            "320": {
              "width": 320,
              "sourceWidth": 320,
              "sourceHeight": 10729,
              "reason": "Exact C76 node 917:18327."
            },
            "576": {
              "width": 576,
              "sourceWidth": 576,
              "sourceHeight": 8960,
              "reason": "Exact C76 node 917:18089."
            },
            "768": {
              "width": 768,
              "sourceWidth": 768,
              "sourceHeight": 8907,
              "reason": "Exact C76 node 917:17846."
            },
            "992": {
              "width": 992,
              "sourceWidth": 992,
              "sourceHeight": 8373,
              "reason": "Exact C76 node 917:17603."
            },
            "1200": {
              "width": 1200,
              "sourceWidth": 1200,
              "sourceHeight": 8632,
              "reason": "Exact C76 node 917:17364."
            }
          },
          "jobs": [
            {
              "name": "cheap-psychic-c76-1200",
              "status": "export_exists",
              "variantId": "1200",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/cheap-psychic-1200-917-17364.png"
              ]
            },
            {
              "name": "cheap-psychic-c76-992",
              "status": "export_exists",
              "variantId": "992",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/cheap-psychic-992-917-17603.png"
              ]
            },
            {
              "name": "cheap-psychic-c76-768",
              "status": "export_exists",
              "variantId": "768",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/cheap-psychic-768-917-17846.png"
              ]
            },
            {
              "name": "cheap-psychic-c76-576",
              "status": "export_exists",
              "variantId": "576",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/cheap-psychic-576-917-18089.png"
              ]
            },
            {
              "name": "cheap-psychic-c76-320",
              "status": "export_exists",
              "variantId": "320",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/cheap-psychic-320-917-18327.png"
              ]
            }
          ]
        },
        {
          "id": "email-psychic-reading",
          "label": "Email Psychic Reading",
          "pageSrc": "_unzipped/email-psychic-reading-new.html",
          "manifestTitle": "Email Psychic Reading · local implementation fixture",
          "lane": "local.preview.money-readings",
          "stateId": "local.preview.email-psychic-reading",
          "reviewClassification": "source_present_exact_candidate_route_unresolved",
          "governedStatus": "source_present_exact_candidate_route_semantics_open",
          "acceptanceStatus": "not_accepted",
          "sourceComparable": false,
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [],
          "sourceRefs": [
            "F:\\Figma Nebula\\c76-manual-crosswalk-adjudication-20260728\\MANUAL-CANDIDATE-ADJUDICATION.json",
            "H:\\GPT-Codex\\artifacts\\oracle-nebula-figma-normalization-readback-recheck-20260728\\SEMANTIC-CANDIDATE-EXACT-NODE-READBACK.json"
          ],
          "proofRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\status-packets\\compare-board-local-page-catalog-20260714.json"
          ],
          "blockedReason": "Пять exact Figma frames подтверждают Email reading source. Route/state semantics и implementation binding ещё не закрыты.",
          "sourceDiscoveryStatus": "candidate_exact_source_route_open",
          "jobs": []
        },
        {
          "id": "fertility-reading",
          "label": "Fertility Reading",
          "pageSrc": "_unzipped/fertility-reading-new.html",
          "manifestTitle": "Fertility Reading · local implementation fixture",
          "lane": "local.preview.money-readings",
          "stateId": "local.preview.fertility-reading",
          "reviewClassification": "current_live_preview_source_unverified",
          "governedStatus": "local_preview_only_source_refresh_required",
          "acceptanceStatus": "not_accepted",
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "sourceRefs": [],
          "proofRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\status-packets\\compare-board-local-page-catalog-20260714.json"
          ],
          "blockedReason": "Live-верстка доступна для просмотра. Текущая source/live пара и свежая приемка не опубликованы; старые архивные exports не используются.",
          "jobs": []
        },
        {
          "id": "fortune-reading",
          "label": "Fortune Reading",
          "pageSrc": "_unzipped/fortune-reading-new.html",
          "manifestTitle": "Fortune Reading · local implementation fixture",
          "lane": "local.preview.money-readings",
          "stateId": "local.preview.fortune-reading",
          "reviewClassification": "current_live_preview_source_unverified",
          "governedStatus": "local_preview_only_source_refresh_required",
          "acceptanceStatus": "not_accepted",
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "sourceRefs": [],
          "proofRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\status-packets\\compare-board-local-page-catalog-20260714.json"
          ],
          "blockedReason": "Live-верстка доступна для просмотра. Текущая source/live пара и свежая приемка не опубликованы; старые архивные exports не используются.",
          "jobs": []
        },
        {
          "id": "free-psychic-reading",
          "label": "Free Psychic Reading",
          "pageSrc": "_unzipped/free-psychic-reading-new.html",
          "manifestTitle": "Free Psychic Reading · local implementation fixture",
          "lane": "local.preview.money-readings",
          "stateId": "local.preview.free-psychic-reading",
          "reviewClassification": "source_present_exact_candidate_route_unresolved",
          "governedStatus": "source_present_exact_candidate_route_semantics_open",
          "acceptanceStatus": "not_accepted",
          "sourceComparable": false,
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [],
          "sourceRefs": [
            "F:\\Figma Nebula\\c76-official-copy-pending-candidate-delta-20260728\\PENDING-OFFICIAL-COPY-CANDIDATE-DELTA.json"
          ],
          "proofRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\status-packets\\compare-board-local-page-catalog-20260714.json"
          ],
          "blockedReason": "Пять exact-width кандидатов Psychic Reading найдены в Figma, но Free Psychic Reading и route/state semantics ещё не связаны.",
          "sourceDiscoveryStatus": "candidate_exact_source_route_open",
          "jobs": []
        },
        {
          "id": "lost-objects-reading",
          "label": "Lost Objects Reading",
          "pageSrc": "_unzipped/lost-objects-reading-new.html",
          "manifestTitle": "Lost Objects Reading · local implementation fixture",
          "lane": "local.preview.money-readings",
          "stateId": "local.preview.lost-objects-reading",
          "reviewClassification": "current_live_preview_source_unverified",
          "governedStatus": "local_preview_only_source_refresh_required",
          "acceptanceStatus": "not_accepted",
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "sourceRefs": [],
          "proofRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\status-packets\\compare-board-local-page-catalog-20260714.json"
          ],
          "blockedReason": "Live-верстка доступна для просмотра. Текущая source/live пара и свежая приемка не опубликованы; старые архивные exports не используются.",
          "jobs": []
        },
        {
          "id": "love-reading",
          "label": "Love Reading",
          "pageSrc": "nebula-easy-love-reading.html",
          "manifestTitle": "Love Reading · full-page C76 source/live · strict visual audit required",
          "lane": "source.live.money-readings",
          "stateId": "love-reading.state.default",
          "reviewClassification": "current_source_live_pair_strict_visual_audit_required",
          "governedStatus": "source_live_pair_current_strict_visual_audit_required",
          "acceptanceStatus": "not_accepted",
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [],
          "sourceRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\c76-normalized-export-20260727\\love-reading.json",
            "C76M54fY7z926wIQoWFh8Y / ,,,,",
            "3ziR8bbnI8oGO4CtzMG0Y8 / exact-node-readback / PM-FIVE-FAMILY-ADJUDICATION.json",
            "F:\\Figma Nebula\\c76-source-index-20260727\\C76-PAGE-CROSSWALK-20260727.json"
          ],
          "proofRefs": [
            "H:\\GPT-Codex\\.ops\\chief-of-staff\\proofs\\oracle-nebula\\love-reading-fullpage-c76-catalog-binding-r3-containment-20260720\\source-authority-binding.json"
          ],
          "blockedReason": "Exact current C76 page-level frames are exported and hash-bound for all five widths; visual acceptance remains a separate gate.",
          "jobs": [
            {
              "name": "love-reading-c76-1200",
              "status": "export_exists",
              "variantId": "1200",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/love-reading-1200-917-20802.png"
              ]
            },
            {
              "name": "love-reading-c76-992",
              "status": "export_exists",
              "variantId": "992",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/love-reading-992-917-21037.png"
              ]
            },
            {
              "name": "love-reading-c76-768",
              "status": "export_exists",
              "variantId": "768",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/love-reading-768-917-21277.png"
              ]
            },
            {
              "name": "love-reading-c76-576",
              "status": "export_exists",
              "variantId": "576",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/love-reading-576-917-21517.png"
              ]
            },
            {
              "name": "love-reading-c76-320",
              "status": "export_exists",
              "variantId": "320",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/love-reading-320-917-21752.png"
              ]
            }
          ]
        },
        {
          "id": "love-reading-screen04-source-surface",
          "label": "Love Reading · Screen 04 source/live",
          "pageSrc": "_unzipped/love-reading-new.html",
          "manifestTitle": "Love Reading · Screen 04 · frozen source surface only",
          "lane": "source.scope.love-reading.screen04",
          "stateId": "source.scope.love-reading.screen04",
          "reviewClassification": "page_closed_candidate_with_known_limits",
          "governedStatus": "candidate_checkpoint_page_closed_with_known_limits",
          "acceptanceStatus": "not_accepted",
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [
            "full_page_out_of_scope"
          ],
          "sourceScope": {
            "source_screen_id": "screen-4-04-love-psychic-readings-people-turn-to-more-often",
            "selector": ".lov-best-online",
            "source_file_key": "ayfBFNukkQC05XmCVsJB6f",
            "full_page_source_published": false,
            "known_live_delta_limit": "blocked_by_figma_starter_mcp_quota_2026-07-12"
          },
          "sourceRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\truth-packets\\love-reading-new-screen04-all-breakpoints.truth-packet.json",
            "H:\\Nebula\\GPT\\figma-manifest\\source-identity\\love-reading-screen04.source-identity.json",
            "H:\\GPT-Codex\\.ops\\chief-of-staff\\proofs\\oracle-nebula\\love-reading-screen04-source-artifact-recovery-20260715\\source-artifact-recovery.json",
            "H:\\GPT-Codex\\.ops\\chief-of-staff\\proofs\\oracle-nebula\\love-reading-screen04-source-artifact-recovery-20260715\\artifact-recovery-ledger.json"
          ],
          "proofRefs": [
            "H:\\GPT-Codex\\.ops\\chief-of-staff\\proofs\\oracle-nebula\\love-reading-screen04-compare-source-surface-20260715\\compare-source-surface.json",
            "H:\\GPT-Codex\\.ops\\chief-of-staff\\proofs\\oracle-nebula\\love-reading-screen04-closure-packet-20260715\\page-closure-packet.json"
          ],
          "blockedReason": "Screen 04 / .lov-best-online закрыт как candidate с известными ограничениями: exact transparent STAR vector остаётся source debt. Full-page acceptance и promotion вне scope; frozen source имеет ограничение fresh live-delta.",
          "jobs": [
            {
              "name": "love-reading-screen04-source-1200",
              "status": "export_exists",
              "variantId": "1200",
              "expectedArtifacts": [
                "compare-board-sources/love-reading-screen04-source-1200.png"
              ],
              "screenSpecArtifacts": [
                "figma-manifest/screen-specs/love-reading-new/04-lov-best-online.json"
              ]
            },
            {
              "name": "love-reading-screen04-source-992",
              "status": "export_exists",
              "variantId": "992",
              "expectedArtifacts": [
                "compare-board-sources/love-reading-screen04-source-992.png"
              ],
              "screenSpecArtifacts": [
                "figma-manifest/screen-specs/love-reading-new/04-lov-best-online.json"
              ]
            },
            {
              "name": "love-reading-screen04-source-768",
              "status": "export_exists",
              "variantId": "768",
              "expectedArtifacts": [
                "compare-board-sources/love-reading-screen04-source-768.png"
              ],
              "screenSpecArtifacts": [
                "figma-manifest/screen-specs/love-reading-new/04-lov-best-online.json"
              ]
            },
            {
              "name": "love-reading-screen04-source-576",
              "status": "export_exists",
              "variantId": "576",
              "expectedArtifacts": [
                "compare-board-sources/love-reading-screen04-source-576.png"
              ],
              "screenSpecArtifacts": [
                "figma-manifest/screen-specs/love-reading-new/04-lov-best-online.json"
              ]
            },
            {
              "name": "love-reading-screen04-source-320",
              "status": "export_exists",
              "variantId": "320",
              "expectedArtifacts": [
                "compare-board-sources/love-reading-screen04-source-320.png"
              ],
              "screenSpecArtifacts": [
                "figma-manifest/screen-specs/love-reading-new/04-lov-best-online.json"
              ]
            }
          ]
        },
        {
          "id": "numerology-reading",
          "label": "Numerology Reading",
          "pageSrc": "_unzipped/numerology-reading-new.html",
          "manifestTitle": "Numerology Reading · local implementation fixture",
          "lane": "local.preview.money-readings",
          "stateId": "local.preview.numerology-reading",
          "reviewClassification": "current_live_preview_source_unverified",
          "governedStatus": "local_preview_only_source_refresh_required",
          "acceptanceStatus": "not_accepted",
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "sourceRefs": [],
          "proofRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\status-packets\\compare-board-local-page-catalog-20260714.json"
          ],
          "blockedReason": "Live-верстка доступна для просмотра. Текущая source/live пара и свежая приемка не опубликованы; старые архивные exports не используются.",
          "jobs": []
        },
        {
          "id": "palm-reading",
          "label": "Palm Reading",
          "pageSrc": "nebula-easy-palm-reading.html",
          "manifestTitle": "Palm Reading · C76 source/live · strict visual audit required",
          "lane": "source.live.money-readings",
          "stateId": "palm-reading.state.default",
          "reviewClassification": "current_source_live_pair_strict_visual_audit_required",
          "governedStatus": "source_live_pair_current_strict_visual_audit_required",
          "acceptanceStatus": "not_accepted",
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [],
          "sourceRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\c76-normalized-export-20260727\\palm-reading.json",
            "C76M54fY7z926wIQoWFh8Y / ,,,,",
            "3ziR8bbnI8oGO4CtzMG0Y8 / exact-node-readback / PM-FIVE-FAMILY-ADJUDICATION.json",
            "F:\\Figma Nebula\\c76-source-index-20260727\\C76-PAGE-CROSSWALK-20260727.json"
          ],
          "proofRefs": [
            "H:\\GPT-Codex\\.ops\\chief-of-staff\\proofs\\oracle-nebula\\palm-reading-c76-catalog-binding-r1-20260720\\source-authority-binding.json"
          ],
          "blockedReason": "Exact current C76 page-level frames are exported and hash-bound for all five widths; visual acceptance remains a separate gate.",
          "variantOverrides": {
            "320": {
              "width": 320,
              "sourceWidth": 320,
              "sourceHeight": 5886
            },
            "576": {
              "width": 576,
              "sourceWidth": 576,
              "sourceHeight": 4272
            },
            "768": {
              "width": 768,
              "sourceWidth": 768,
              "sourceHeight": 4345
            },
            "992": {
              "width": 992,
              "sourceWidth": 992,
              "sourceHeight": 4297
            },
            "1200": {
              "width": 1200,
              "sourceWidth": 1200,
              "sourceHeight": 4392
            }
          },
          "jobs": [
            {
              "name": "palm-reading-c76-1200",
              "status": "export_exists",
              "variantId": "1200",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/palm-reading-1200-910-20010.png"
              ]
            },
            {
              "name": "palm-reading-c76-992",
              "status": "export_exists",
              "variantId": "992",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/palm-reading-992-910-20217.png"
              ]
            },
            {
              "name": "palm-reading-c76-768",
              "status": "export_exists",
              "variantId": "768",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/palm-reading-768-910-19799.png"
              ]
            },
            {
              "name": "palm-reading-c76-576",
              "status": "export_exists",
              "variantId": "576",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/palm-reading-576-910-20428.png"
              ]
            },
            {
              "name": "palm-reading-c76-320",
              "status": "export_exists",
              "variantId": "320",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/palm-reading-320-910-20635.png"
              ]
            }
          ]
        },
        {
          "id": "palm-reading-scanner",
          "label": "Palm Reading Scanner",
          "pageSrc": "_unzipped/palm-reading-scanner-new.html",
          "manifestTitle": "Palm Reading Scanner · local implementation fixture",
          "lane": "local.preview.money-readings",
          "stateId": "local.preview.palm-reading-scanner",
          "reviewClassification": "source_present_exact_candidate_route_unresolved",
          "governedStatus": "source_present_exact_candidate_route_semantics_open",
          "acceptanceStatus": "not_accepted",
          "sourceComparable": false,
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [],
          "sourceRefs": [
            "F:\\Figma Nebula\\c76-official-copy-pending-candidate-delta-20260728\\PENDING-OFFICIAL-COPY-CANDIDATE-DELTA.json"
          ],
          "proofRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\status-packets\\compare-board-local-page-catalog-20260714.json"
          ],
          "blockedReason": "Пять exact-width кандидатов Palm Reading найдены в Figma, но scanner route и state semantics ещё не связаны.",
          "sourceDiscoveryStatus": "candidate_exact_source_route_open",
          "jobs": []
        },
        {
          "id": "past-life-reading",
          "label": "Past Life Reading",
          "pageSrc": "_unzipped/past-life-reading-new.html",
          "manifestTitle": "Past Life Reading · local implementation fixture",
          "lane": "local.preview.money-readings",
          "stateId": "local.preview.past-life-reading",
          "reviewClassification": "current_live_preview_source_unverified",
          "governedStatus": "local_preview_only_source_refresh_required",
          "acceptanceStatus": "not_accepted",
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "sourceRefs": [],
          "proofRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\status-packets\\compare-board-local-page-catalog-20260714.json"
          ],
          "blockedReason": "Live-верстка доступна для просмотра. Текущая source/live пара и свежая приемка не опубликованы; старые архивные exports не используются.",
          "jobs": []
        },
        {
          "id": "phone-psychic",
          "label": "Phone Psychic",
          "pageSrc": "nebula-easy-phone-psychic.html",
          "implementationAlias": "phone-psychic-new",
          "manifestTitle": "Phone Psychic · C76 source/live · strict visual audit required",
          "lane": "source.live.money-readings",
          "stateId": "phone-psychic.state.default",
          "reviewClassification": "current_source_live_pair_strict_visual_audit_required",
          "governedStatus": "source_live_pair_current_strict_visual_audit_required",
          "acceptanceStatus": "not_accepted",
          "sourceComparable": true,
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [],
          "sourceRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\c76-normalized-export-20260727\\phone-psychic.json",
            "C76M54fY7z926wIQoWFh8Y / ,,,,",
            "F:\\Figma Nebula\\c76-source-index-20260727\\C76-PAGE-CROSSWALK-20260727.json"
          ],
          "proofRefs": [
            "H:\\GPT-Codex\\.ops\\chief-of-staff\\proofs\\oracle-nebula\\phone-psychic-c76-source-publication-20260720\\source-authority-binding.json"
          ],
          "blockedReason": "Exact current C76 page-level frames are exported and hash-bound for all five widths; visual acceptance remains a separate gate.",
          "variantOverrides": {
            "320": {
              "width": 320,
              "sourceWidth": 320,
              "sourceHeight": 10554,
              "reason": "Exact C76 node 912:13030."
            },
            "576": {
              "width": 576,
              "sourceWidth": 576,
              "sourceHeight": 8946,
              "reason": "Exact C76 node 912:12837."
            },
            "768": {
              "width": 768,
              "sourceWidth": 768,
              "sourceHeight": 8649,
              "reason": "Exact C76 node 912:12639."
            },
            "992": {
              "width": 992,
              "sourceWidth": 992,
              "sourceHeight": 8223,
              "reason": "Exact C76 node 912:12444."
            },
            "1200": {
              "width": 1200,
              "sourceWidth": 1200,
              "sourceHeight": 8552,
              "reason": "Exact C76 node 912:12253."
            }
          },
          "jobs": [
            {
              "name": "phone-psychic-c76-1200",
              "status": "export_exists",
              "variantId": "1200",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/phone-psychic-1200-912-12253.png"
              ]
            },
            {
              "name": "phone-psychic-c76-992",
              "status": "export_exists",
              "variantId": "992",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/phone-psychic-992-912-12444.png"
              ]
            },
            {
              "name": "phone-psychic-c76-768",
              "status": "export_exists",
              "variantId": "768",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/phone-psychic-768-912-12639.png"
              ]
            },
            {
              "name": "phone-psychic-c76-576",
              "status": "export_exists",
              "variantId": "576",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/phone-psychic-576-912-12837.png"
              ]
            },
            {
              "name": "phone-psychic-c76-320",
              "status": "export_exists",
              "variantId": "320",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/phone-psychic-320-912-13030.png"
              ]
            }
          ]
        },
        {
          "id": "psychic-near-me",
          "label": "Psychic Near Me",
          "pageSrc": "_unzipped/psychic-near-me-new.html",
          "manifestTitle": "Psychic Near Me · local implementation fixture",
          "lane": "local.preview.money-readings",
          "stateId": "local.preview.psychic-near-me",
          "reviewClassification": "source_present_exact_candidate_route_unresolved",
          "governedStatus": "source_present_exact_candidate_route_semantics_open",
          "acceptanceStatus": "not_accepted",
          "sourceComparable": false,
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [],
          "sourceRefs": [
            "F:\\Figma Nebula\\c76-official-copy-pending-candidate-delta-20260728\\PENDING-OFFICIAL-COPY-CANDIDATE-DELTA.json"
          ],
          "proofRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\status-packets\\compare-board-local-page-catalog-20260714.json"
          ],
          "blockedReason": "Пять exact-width кандидатов All Psychics найдены в Figma, но Psychic Near Me и route/state semantics ещё не связаны.",
          "sourceDiscoveryStatus": "candidate_exact_source_route_open",
          "jobs": []
        },
        {
          "id": "psychic-reading",
          "label": "Psychic Reading",
          "pageSrc": "nebula-easy-psychic-reading.html",
          "implementationAlias": "psychic-reading-new",
          "manifestTitle": "Psychic Reading · C76 source/live · strict visual audit required",
          "lane": "source.live.money-readings",
          "stateId": "psychic-reading.state.default",
          "reviewClassification": "current_source_live_pair_strict_visual_audit_required",
          "governedStatus": "source_live_pair_current_strict_visual_audit_required",
          "acceptanceStatus": "not_accepted",
          "sourceComparable": true,
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [],
          "sourceRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\c76-normalized-export-20260727\\psychic-reading.json",
            "C76M54fY7z926wIQoWFh8Y / ,,,,",
            "3ziR8bbnI8oGO4CtzMG0Y8 / exact-node-readback / PM-FIVE-FAMILY-ADJUDICATION.json",
            "F:\\Figma Nebula\\c76-source-index-20260727\\C76-PAGE-CROSSWALK-20260727.json"
          ],
          "proofRefs": [
            "H:\\GPT-Codex\\.ops\\chief-of-staff\\proofs\\oracle-nebula\\psychic-reading-c76-source-publication-20260720\\source-authority-binding.json"
          ],
          "blockedReason": "Exact current C76 page-level frames are exported and hash-bound for all five widths; visual acceptance remains a separate gate.",
          "variantOverrides": {
            "320": {
              "width": 320,
              "sourceWidth": 320,
              "sourceHeight": 9240,
              "reason": "Exact C76 node 883:13989."
            },
            "576": {
              "width": 576,
              "sourceWidth": 576,
              "sourceHeight": 8028,
              "reason": "Exact C76 node 881:12511."
            },
            "768": {
              "width": 768,
              "sourceWidth": 768,
              "sourceHeight": 8034,
              "reason": "Exact C76 node 874:10483."
            },
            "992": {
              "width": 992,
              "sourceWidth": 992,
              "sourceHeight": 7479,
              "reason": "Exact C76 node 874:8758."
            },
            "1200": {
              "width": 1200,
              "sourceWidth": 1200,
              "sourceHeight": 7456,
              "reason": "Exact C76 node 413:3566."
            }
          },
          "jobs": [
            {
              "name": "psychic-reading-c76-1200",
              "status": "export_exists",
              "variantId": "1200",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/psychic-reading-1200-413-3566.png"
              ]
            },
            {
              "name": "psychic-reading-c76-992",
              "status": "export_exists",
              "variantId": "992",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/psychic-reading-992-874-8758.png"
              ]
            },
            {
              "name": "psychic-reading-c76-768",
              "status": "export_exists",
              "variantId": "768",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/psychic-reading-768-874-10483.png"
              ]
            },
            {
              "name": "psychic-reading-c76-576",
              "status": "export_exists",
              "variantId": "576",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/psychic-reading-576-881-12511.png"
              ]
            },
            {
              "name": "psychic-reading-c76-320",
              "status": "export_exists",
              "variantId": "320",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/psychic-reading-320-883-13989.png"
              ]
            }
          ]
        },
        {
          "id": "soulmate-reading",
          "label": "Soulmate Reading",
          "pageSrc": "_unzipped/soulmate-reading-new.html",
          "manifestTitle": "Soulmate Reading · local implementation fixture",
          "lane": "local.preview.money-readings",
          "stateId": "local.preview.soulmate-reading",
          "reviewClassification": "current_live_preview_source_unverified",
          "governedStatus": "local_preview_only_source_refresh_required",
          "acceptanceStatus": "not_accepted",
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "sourceRefs": [],
          "proofRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\status-packets\\compare-board-local-page-catalog-20260714.json"
          ],
          "blockedReason": "Live-верстка доступна для просмотра. Текущая source/live пара и свежая приемка не опубликованы; старые архивные exports не используются.",
          "jobs": []
        },
        {
          "id": "tarot-reading",
          "label": "Tarot Reading",
          "pageSrc": "nebula-easy-tarot-reading.html",
          "manifestTitle": "Tarot Reading · C76 source/live · strict visual audit required",
          "lane": "source.live.money-readings",
          "stateId": "tarot-reading.state.default",
          "reviewClassification": "current_source_live_pair_strict_visual_audit_required",
          "governedStatus": "source_live_pair_current_strict_visual_audit_required",
          "acceptanceStatus": "not_accepted",
          "sourceComparable": true,
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [],
          "sourceRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\c76-normalized-export-20260727\\tarot-reading.json",
            "C76M54fY7z926wIQoWFh8Y / ,,,,",
            "3ziR8bbnI8oGO4CtzMG0Y8 / exact-node-readback / PM-FIVE-FAMILY-ADJUDICATION.json",
            "F:\\Figma Nebula\\c76-source-index-20260727\\C76-PAGE-CROSSWALK-20260727.json"
          ],
          "proofRefs": [
            "H:\\GPT-Codex\\.ops\\chief-of-staff\\proofs\\oracle-nebula\\tarot-reading-source-publication-20260716\\registered-source-authority.json"
          ],
          "blockedReason": "Exact current C76 page-level frames are exported and hash-bound for all five widths; visual acceptance remains a separate gate.",
          "variantOverrides": {
            "320": {
              "width": 320,
              "sourceWidth": 320,
              "sourceHeight": 9995,
              "reason": "Exact C76 node 893:13096."
            },
            "576": {
              "width": 576,
              "sourceWidth": 576,
              "sourceHeight": 8740,
              "reason": "Exact C76 node 893:12903."
            },
            "768": {
              "width": 768,
              "sourceWidth": 768,
              "sourceHeight": 8831,
              "reason": "Exact C76 node 894:10617."
            },
            "992": {
              "width": 992,
              "sourceWidth": 992,
              "sourceHeight": 8400,
              "reason": "Exact C76 node 893:12510."
            },
            "1200": {
              "width": 1200,
              "sourceWidth": 1200,
              "sourceHeight": 8542,
              "reason": "Exact C76 node 893:12319."
            }
          },
          "jobs": [
            {
              "name": "tarot-reading-c76-1200",
              "status": "export_exists",
              "variantId": "1200",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/tarot-reading-1200-893-12319.png"
              ]
            },
            {
              "name": "tarot-reading-c76-992",
              "status": "export_exists",
              "variantId": "992",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/tarot-reading-992-893-12510.png"
              ]
            },
            {
              "name": "tarot-reading-c76-768",
              "status": "export_exists",
              "variantId": "768",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/tarot-reading-768-894-10617.png"
              ]
            },
            {
              "name": "tarot-reading-c76-576",
              "status": "export_exists",
              "variantId": "576",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/tarot-reading-576-893-12903.png"
              ]
            },
            {
              "name": "tarot-reading-c76-320",
              "status": "export_exists",
              "variantId": "320",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/tarot-reading-320-893-13096.png"
              ]
            }
          ]
        }
      ]
    },
    {
      "id": "psychics",
      "label": "Эксперты",
      "text": "Каталог и карточка эксперта.",
      "pages": [
        {
          "id": "all-psychic",
          "label": "All Psychics",
          "pageSrc": "nebula-easy-all-psychic.html",
          "manifestTitle": "All Psychics · page closure candidate with known limits · not accepted",
          "lane": "current.review.psychics",
          "stateId": "current.review.all-psychic.page-closed-candidate",
          "reviewClassification": "current_source_live_pair_strict_visual_audit_required",
          "governedStatus": "source_live_pair_current_strict_visual_audit_required",
          "acceptanceStatus": "not_accepted",
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [],
          "sourceRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\c76-normalized-export-20260727\\all-psychic.json",
            "C76M54fY7z926wIQoWFh8Y / ,,,,",
            "3ziR8bbnI8oGO4CtzMG0Y8 / exact-node-readback / PM-FIVE-FAMILY-ADJUDICATION.json",
            "F:\\Figma Nebula\\c76-source-index-20260727\\C76-PAGE-CROSSWALK-20260727.json"
          ],
          "proofRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\truth-packets\\all-psychic-new-source-refresh-20260714\\source-refresh-manifest.json",
            "H:\\GPT-Codex\\.ops\\chief-of-staff\\proofs\\oracle-nebula\\all-psychic-source-refresh-20260714\\live-capture-runtime.json",
            "H:\\GPT-Codex\\.ops\\chief-of-staff\\proofs\\oracle-nebula\\all-psychic-strict-visual-audit-20260714\\breakpoint-verdicts.json",
            "H:\\GPT-Codex\\.ops\\chief-of-staff\\proofs\\oracle-nebula\\all-psychic-strict-visual-audit-20260714\\residual-registry.json",
            "H:\\GPT-Codex\\.ops\\chief-of-staff\\proofs\\oracle-nebula\\all-psychic-strict-visual-audit-20260714\\closeout.md",
            "H:\\GPT-Codex\\.ops\\chief-of-staff\\proofs\\oracle-nebula\\all-psychic-cta-paint-owner-20260714\\source-paint-map.json",
            "H:\\GPT-Codex\\.ops\\chief-of-staff\\proofs\\oracle-nebula\\all-psychic-cta-paint-owner-20260714\\runtime-after.json",
            "H:\\GPT-Codex\\.ops\\chief-of-staff\\proofs\\oracle-nebula\\all-psychic-cta-paint-owner-20260714\\owner-visual-metrics-after.json",
            "H:\\GPT-Codex\\.ops\\chief-of-staff\\proofs\\oracle-nebula\\all-psychic-cta-paint-owner-20260714\\five-width-regression.json",
            "H:\\GPT-Codex\\.ops\\chief-of-staff\\proofs\\oracle-nebula\\all-psychic-cta-paint-owner-20260714\\closeout.md",
            "H:\\GPT-Codex\\.ops\\chief-of-staff\\proofs\\oracle-nebula\\all-psychic-featured-cta-paint-20260715\\closeout.md",
            "H:\\GPT-Codex\\.ops\\chief-of-staff\\proofs\\oracle-nebula\\all-psychic-featured-cta-paint-20260715\\page-closure-split-proof.json",
            "H:\\GPT-Codex\\.ops\\chief-of-staff\\proofs\\oracle-nebula\\all-psychic-page-closure-20260715\\page-closure-packet.json"
          ],
          "blockedReason": "Exact current C76 page-level frames are exported and hash-bound for all five widths; visual acceptance remains a separate gate.",
          "jobs": [
            {
              "name": "all-psychic-c76-1200",
              "status": "export_exists",
              "variantId": "1200",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/all-psychic-1200-924-16998.png"
              ]
            },
            {
              "name": "all-psychic-c76-992",
              "status": "export_exists",
              "variantId": "992",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/all-psychic-992-924-17233.png"
              ]
            },
            {
              "name": "all-psychic-c76-768",
              "status": "export_exists",
              "variantId": "768",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/all-psychic-768-924-17473.png"
              ]
            },
            {
              "name": "all-psychic-c76-576",
              "status": "export_exists",
              "variantId": "576",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/all-psychic-576-924-17713.png"
              ]
            },
            {
              "name": "all-psychic-c76-320",
              "status": "export_exists",
              "variantId": "320",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/all-psychic-320-924-17948.png"
              ]
            }
          ]
        },
        {
          "id": "expert-page",
          "label": "Mia Jacomo · Psychic Card",
          "pageSrc": "experiments/nebula-account-chat-live-20260809/preview/mia-jacomo.html",
          "manifestTitle": "Psychic Card C76 · Mia Jacomo live data · visual verification pending",
          "lane": "current.review.psychics",
          "stateId": "nebula.mia-profile.source-candidate",
          "reviewClassification": "current_source_live_pair_strict_visual_audit_required",
          "governedStatus": "source_candidate_ready_visual_pending",
          "acceptanceStatus": "not_accepted",
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [],
          "sourceRefs": [
            "C76M54fY7z926wIQoWFh8Y/1095:28955",
            "C76M54fY7z926wIQoWFh8Y/1415:44362",
            "C76M54fY7z926wIQoWFh8Y/1415:45424",
            "C76M54fY7z926wIQoWFh8Y/1415:45976",
            "C76M54fY7z926wIQoWFh8Y/1415:46525"
          ],
          "proofRefs": [
            "H:/GPT-Codex/.ops/codex-head/reports/head-command-chat-20260907/NEBULA-PROFILE-UNIT-RESULT.json"
          ],
          "blockedReason": "Exact current C76 sources are bound. Mia identity/status differ from Margo source content; rendered layout/overlay acceptance remains pending.",
          "jobs": [
            {
              "name": "psychic-card-c76-1200",
              "status": "export_exists",
              "variantId": "1200",
              "expectedArtifacts": [
                "experiments/nebula-account-chat-live-20260809/source/psychic-card-c76-20260907/psychic-card-1200.png"
              ]
            },
            {
              "name": "psychic-card-c76-992",
              "status": "export_exists",
              "variantId": "992",
              "expectedArtifacts": [
                "experiments/nebula-account-chat-live-20260809/source/psychic-card-c76-20260907/psychic-card-992.png"
              ]
            },
            {
              "name": "psychic-card-c76-768",
              "status": "export_exists",
              "variantId": "768",
              "expectedArtifacts": [
                "experiments/nebula-account-chat-live-20260809/source/psychic-card-c76-20260907/psychic-card-768.png"
              ]
            },
            {
              "name": "psychic-card-c76-576",
              "status": "export_exists",
              "variantId": "576",
              "expectedArtifacts": [
                "experiments/nebula-account-chat-live-20260809/source/psychic-card-c76-20260907/psychic-card-576.png"
              ]
            },
            {
              "name": "psychic-card-c76-320",
              "status": "export_exists",
              "variantId": "320",
              "expectedArtifacts": [
                "experiments/nebula-account-chat-live-20260809/source/psychic-card-c76-20260907/psychic-card-320.png"
              ]
            }
          ],
          "sourceComparable": true,
          "variantOverrides": {
            "320": {
              "width": 320,
              "sourceWidth": 320,
              "sourceHeight": 9454,
              "reason": "Exact C76 1415:46525; current live Mia route."
            },
            "576": {
              "width": 576,
              "sourceWidth": 576,
              "sourceHeight": 7127,
              "reason": "Exact C76 1415:45976; current live Mia route."
            },
            "768": {
              "width": 768,
              "sourceWidth": 768,
              "sourceHeight": 7127,
              "reason": "Exact C76 1415:45424; current live Mia route."
            },
            "992": {
              "width": 992,
              "sourceWidth": 992,
              "sourceHeight": 7127,
              "reason": "Exact C76 1415:44362; current live Mia route."
            },
            "1200": {
              "width": 1200,
              "sourceWidth": 1200,
              "sourceHeight": 7127,
              "reason": "Exact C76 1095:28955; current live Mia route."
            }
          }
        }
      ]
    },
    {
      "id": "zodiac-topic",
      "label": "Zodiac / Topics",
      "text": "Гороскопы, совместимость, meanings и calculators.",
      "pages": [
        {
          "id": "angel-numbers",
          "label": "Angel Numbers",
          "pageSrc": "_unzipped/angel-numbers-meaning-new.html",
          "manifestTitle": "Angel Numbers · local implementation fixture",
          "lane": "local.preview.zodiac-topic",
          "stateId": "local.preview.angel-numbers",
          "reviewClassification": "current_live_preview_source_unverified",
          "governedStatus": "local_preview_only_source_refresh_required",
          "acceptanceStatus": "not_accepted",
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "sourceRefs": [],
          "proofRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\status-packets\\compare-board-local-page-catalog-20260714.json"
          ],
          "blockedReason": "Live-верстка доступна для просмотра. Текущая source/live пара и свежая приемка не опубликованы; старые архивные exports не используются.",
          "jobs": []
        },
        {
          "id": "aura-colors",
          "label": "Aura Colors",
          "pageSrc": "_unzipped/aura-colors-meaning-new.html",
          "manifestTitle": "Aura Colors · local implementation fixture",
          "lane": "local.preview.zodiac-topic",
          "stateId": "local.preview.aura-colors",
          "reviewClassification": "source_present_exact_candidate_route_unresolved",
          "governedStatus": "source_present_exact_candidate_route_semantics_open",
          "acceptanceStatus": "not_accepted",
          "sourceComparable": false,
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [],
          "sourceRefs": [
            "F:\\Figma Nebula\\c76-manual-crosswalk-adjudication-20260728\\MANUAL-CANDIDATE-ADJUDICATION.json",
            "H:\\GPT-Codex\\artifacts\\oracle-nebula-figma-normalization-readback-recheck-20260728\\SEMANTIC-CANDIDATE-EXACT-NODE-READBACK.json"
          ],
          "proofRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\status-packets\\compare-board-local-page-catalog-20260714.json"
          ],
          "blockedReason": "Пять exact Figma frames подтверждают AURA reading source. Alias Aura Colors и route semantics требуют отдельного решения.",
          "sourceDiscoveryStatus": "candidate_exact_source_route_open",
          "jobs": []
        },
        {
          "id": "birth-chart",
          "label": "Birth Chart",
          "pageSrc": "_unzipped/birth-chart-new.html",
          "manifestTitle": "Birth Chart · local implementation fixture",
          "lane": "local.preview.zodiac-topic",
          "stateId": "local.preview.birth-chart",
          "reviewClassification": "current_live_preview_source_unverified",
          "governedStatus": "local_preview_only_source_refresh_required",
          "acceptanceStatus": "not_accepted",
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "sourceRefs": [],
          "proofRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\status-packets\\compare-board-local-page-catalog-20260714.json"
          ],
          "blockedReason": "Live-верстка доступна для просмотра. Текущая source/live пара и свежая приемка не опубликованы; старые архивные exports не используются.",
          "jobs": []
        },
        {
          "id": "crystal-stone",
          "label": "Crystal and Stone",
          "pageSrc": "_unzipped/crystal-and-stone-meanings-new.html",
          "manifestTitle": "Crystal and Stone · local implementation fixture",
          "lane": "local.preview.zodiac-topic",
          "stateId": "local.preview.crystal-stone",
          "reviewClassification": "current_live_preview_source_unverified",
          "governedStatus": "local_preview_only_source_refresh_required",
          "acceptanceStatus": "not_accepted",
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "sourceRefs": [],
          "proofRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\status-packets\\compare-board-local-page-catalog-20260714.json"
          ],
          "blockedReason": "Live-верстка доступна для просмотра. Текущая source/live пара и свежая приемка не опубликованы; старые архивные exports не используются.",
          "jobs": []
        },
        {
          "id": "daily-horoscope",
          "label": "Daily Horoscope",
          "pageSrc": "_unzipped/daily-horoscope-new.html",
          "manifestTitle": "Daily Horoscope · local implementation fixture",
          "lane": "local.preview.zodiac-topic",
          "stateId": "local.preview.daily-horoscope",
          "reviewClassification": "source_present_candidate_context_mismatch",
          "governedStatus": "source_present_candidate_context_mismatch_review",
          "acceptanceStatus": "not_accepted",
          "sourceComparable": false,
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [],
          "sourceRefs": [
            "F:\\Figma Nebula\\c76-official-copy-pending-candidate-delta-20260728\\PENDING-OFFICIAL-COPY-CANDIDATE-DELTA.json"
          ],
          "proofRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\status-packets\\compare-board-local-page-catalog-20260714.json"
          ],
          "blockedReason": "Пять Figma-кандидатов найдены, но они относятся к Settings/Notification Daily Horoscope, а не доказанно к публичному Daily Horoscope route.",
          "sourceDiscoveryStatus": "candidate_source_context_mismatch",
          "jobs": []
        },
        {
          "id": "woman-zodiac-sign-traits",
          "label": "Female Sign Traits",
          "pageSrc": "_unzipped/woman-zodiac-sign-traits-new.html",
          "manifestTitle": "Female Sign Traits · local implementation fixture",
          "lane": "local.preview.zodiac-topic",
          "stateId": "local.preview.woman-zodiac-sign-traits",
          "reviewClassification": "current_live_preview_source_unverified",
          "governedStatus": "local_preview_only_source_refresh_required",
          "acceptanceStatus": "not_accepted",
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "sourceRefs": [],
          "proofRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\status-packets\\compare-board-local-page-catalog-20260714.json"
          ],
          "blockedReason": "Live-верстка доступна для просмотра. Текущая source/live пара и свежая приемка не опубликованы; старые архивные exports не используются.",
          "jobs": []
        },
        {
          "id": "horoscope-detail",
          "label": "Horoscope Detail",
          "pageSrc": "_unzipped/horoscope-detail-new.html",
          "manifestTitle": "Horoscope Detail · local implementation fixture",
          "lane": "local.preview.zodiac-topic",
          "stateId": "local.preview.horoscope-detail",
          "reviewClassification": "source_present_exact_candidate_route_unresolved",
          "governedStatus": "source_present_exact_candidate_route_semantics_open",
          "acceptanceStatus": "not_accepted",
          "sourceComparable": false,
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [],
          "sourceRefs": [
            "F:\\Figma Nebula\\c76-manual-crosswalk-adjudication-20260728\\MANUAL-CANDIDATE-ADJUDICATION.json",
            "H:\\GPT-Codex\\artifacts\\oracle-nebula-figma-normalization-readback-recheck-20260728\\SEMANTIC-CANDIDATE-EXACT-NODE-READBACK.json"
          ],
          "proofRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\status-packets\\compare-board-local-page-catalog-20260714.json"
          ],
          "blockedReason": "Пять exact Figma frames подтверждают источник Horoscope. Route Horoscope Detail и state semantics ещё не связаны доказательством.",
          "sourceDiscoveryStatus": "candidate_exact_source_route_open",
          "jobs": []
        },
        {
          "id": "life-path",
          "label": "Life Path Calculator",
          "pageSrc": "_unzipped/life-path-calculator-new.html",
          "manifestTitle": "Life Path Calculator · local implementation fixture",
          "lane": "local.preview.zodiac-topic",
          "stateId": "local.preview.life-path",
          "reviewClassification": "current_live_preview_source_unverified",
          "governedStatus": "local_preview_only_source_refresh_required",
          "acceptanceStatus": "not_accepted",
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "sourceRefs": [],
          "proofRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\status-packets\\compare-board-local-page-catalog-20260714.json"
          ],
          "blockedReason": "Live-верстка доступна для просмотра. Текущая source/live пара и свежая приемка не опубликованы; старые архивные exports не используются.",
          "jobs": []
        },
        {
          "id": "man-zodiac-sign-traits",
          "label": "Male Sign Traits",
          "pageSrc": "_unzipped/man-zodiac-sign-traits-new.html",
          "manifestTitle": "Male Sign Traits · local implementation fixture",
          "lane": "local.preview.zodiac-topic",
          "stateId": "local.preview.man-zodiac-sign-traits",
          "reviewClassification": "current_live_preview_source_unverified",
          "governedStatus": "local_preview_only_source_refresh_required",
          "acceptanceStatus": "not_accepted",
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "sourceRefs": [],
          "proofRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\status-packets\\compare-board-local-page-catalog-20260714.json"
          ],
          "blockedReason": "Live-верстка доступна для просмотра. Текущая source/live пара и свежая приемка не опубликованы; старые архивные exports не используются.",
          "jobs": []
        },
        {
          "id": "spiritual-meanings",
          "label": "Spiritual Meanings",
          "pageSrc": "_unzipped/spiritual-meanings-new.html",
          "manifestTitle": "Spiritual Meanings · local implementation fixture",
          "lane": "local.preview.zodiac-topic",
          "stateId": "local.preview.spiritual-meanings",
          "reviewClassification": "current_live_preview_source_unverified",
          "governedStatus": "local_preview_only_source_refresh_required",
          "acceptanceStatus": "not_accepted",
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "sourceRefs": [],
          "proofRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\status-packets\\compare-board-local-page-catalog-20260714.json"
          ],
          "blockedReason": "Live-верстка доступна для просмотра. Текущая source/live пара и свежая приемка не опубликованы; старые архивные exports не используются.",
          "jobs": []
        },
        {
          "id": "tarot-cards-meaning",
          "label": "Tarot Cards Meaning",
          "pageSrc": "_unzipped/tarot-cards-meaning-new.html",
          "manifestTitle": "Tarot Cards Meaning · local implementation fixture",
          "lane": "local.preview.zodiac-topic",
          "stateId": "local.preview.tarot-cards-meaning",
          "reviewClassification": "source_present_exact_candidate_route_unresolved",
          "governedStatus": "source_present_exact_candidate_route_semantics_open",
          "acceptanceStatus": "not_accepted",
          "sourceComparable": false,
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [],
          "sourceRefs": [
            "F:\\Figma Nebula\\c76-official-copy-pending-candidate-delta-20260728\\PENDING-OFFICIAL-COPY-CANDIDATE-DELTA.json"
          ],
          "proofRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\status-packets\\compare-board-local-page-catalog-20260714.json"
          ],
          "blockedReason": "Пять exact-width кандидатов Tarot Reading найдены в Figma, но Tarot Cards Meaning и route/state semantics ещё не связаны.",
          "sourceDiscoveryStatus": "candidate_exact_source_route_open",
          "jobs": []
        },
        {
          "id": "taurus-compatibility",
          "label": "Taurus Compatibility",
          "pageSrc": "nebula-easy-taurus-compatibility.html",
          "manifestTitle": "Taurus Compatibility · C76 source/live · strict visual audit required",
          "lane": "source.live.zodiac-topic",
          "stateId": "taurus-compatibility.state.default",
          "reviewClassification": "current_source_live_pair_strict_visual_audit_required",
          "governedStatus": "source_live_pair_current_strict_visual_audit_required",
          "acceptanceStatus": "not_accepted",
          "sourceComparable": true,
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [],
          "sourceRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\c76-normalized-export-20260727\\taurus-compatibility.json",
            "C76M54fY7z926wIQoWFh8Y / ,,,,",
            "F:\\Figma Nebula\\c76-source-index-20260727\\C76-PAGE-CROSSWALK-20260727.json"
          ],
          "proofRefs": [
            "H:\\GPT-Codex\\.ops\\chief-of-staff\\proofs\\oracle-nebula\\taurus-compatibility-c76-source-publication-20260720\\source-authority-binding.json"
          ],
          "blockedReason": "Exact current C76 page-level frames are exported and hash-bound for all five widths; visual acceptance remains a separate gate.",
          "variantOverrides": {
            "320": {
              "width": 320,
              "sourceWidth": 320,
              "sourceHeight": 22731,
              "reason": "Exact C76 node 999:22307."
            },
            "576": {
              "width": 576,
              "sourceWidth": 576,
              "sourceHeight": 16095,
              "reason": "Exact C76 node 998:21319."
            },
            "768": {
              "width": 768,
              "sourceWidth": 768,
              "sourceHeight": 16687,
              "reason": "Exact C76 node 992:27315."
            },
            "992": {
              "width": 992,
              "sourceWidth": 992,
              "sourceHeight": 17767,
              "reason": "Exact C76 node 992:25786."
            },
            "1200": {
              "width": 1200,
              "sourceWidth": 1200,
              "sourceHeight": 17402,
              "reason": "Exact C76 node 631:5673."
            }
          },
          "jobs": [
            {
              "name": "taurus-compatibility-c76-1200",
              "status": "export_exists",
              "variantId": "1200",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/taurus-compatibility-1200-631-5673.png"
              ]
            },
            {
              "name": "taurus-compatibility-c76-992",
              "status": "export_exists",
              "variantId": "992",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/taurus-compatibility-992-992-25786.png"
              ]
            },
            {
              "name": "taurus-compatibility-c76-768",
              "status": "export_exists",
              "variantId": "768",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/taurus-compatibility-768-992-27315.png"
              ]
            },
            {
              "name": "taurus-compatibility-c76-576",
              "status": "export_exists",
              "variantId": "576",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/taurus-compatibility-576-998-21319.png"
              ]
            },
            {
              "name": "taurus-compatibility-c76-320",
              "status": "export_exists",
              "variantId": "320",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/taurus-compatibility-320-999-22307.png"
              ]
            }
          ]
        },
        {
          "id": "topic-hub",
          "label": "Topic Hub",
          "pageSrc": "_unzipped/topic-new.html",
          "manifestTitle": "Topic Hub · local implementation fixture",
          "lane": "local.preview.zodiac-topic",
          "stateId": "local.preview.topic-hub",
          "reviewClassification": "current_live_preview_source_unverified",
          "governedStatus": "local_preview_only_source_refresh_required",
          "acceptanceStatus": "not_accepted",
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "sourceRefs": [],
          "proofRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\status-packets\\compare-board-local-page-catalog-20260714.json"
          ],
          "blockedReason": "Live-верстка доступна для просмотра. Текущая source/live пара и свежая приемка не опубликованы; старые архивные exports не используются.",
          "jobs": []
        },
        {
          "id": "zodiac-compatibility",
          "label": "Zodiac Compatibility",
          "pageSrc": "nebula-easy-zodiac-compatibility.html",
          "implementationAlias": "zodiac-compatibility-new",
          "manifestTitle": "Zodiac Compatibility · C76 source/live · strict visual audit required",
          "lane": "source.live.zodiac-topic",
          "stateId": "zodiac-compatibility.state.default",
          "reviewClassification": "current_source_live_pair_strict_visual_audit_required",
          "governedStatus": "source_live_pair_current_strict_visual_audit_required",
          "acceptanceStatus": "not_accepted",
          "sourceComparable": true,
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [],
          "sourceRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\c76-normalized-export-20260727\\zodiac-compatibility.json",
            "C76M54fY7z926wIQoWFh8Y / ,,,,",
            "F:\\Figma Nebula\\c76-source-index-20260727\\C76-PAGE-CROSSWALK-20260727.json"
          ],
          "proofRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\truth-packets\\zodiac-compatibility-c76-five-breakpoint-source-20260716.json",
            "H:\\GPT-Codex\\.ops\\chief-of-staff\\proofs\\oracle-nebula\\zodiac-compatibility-c76-source-publication-20260716\\registered-source-authority.json"
          ],
          "blockedReason": "Exact current C76 page-level frames are exported and hash-bound for all five widths; visual acceptance remains a separate gate.",
          "variantOverrides": {
            "320": {
              "width": 320,
              "sourceWidth": 320,
              "sourceHeight": 12849,
              "reason": "Exact C76 node 990:23220."
            },
            "576": {
              "width": 576,
              "sourceWidth": 576,
              "sourceHeight": 9557,
              "reason": "Exact C76 node 988:24213."
            },
            "768": {
              "width": 768,
              "sourceWidth": 768,
              "sourceHeight": 9892,
              "reason": "Exact C76 node 986:33306."
            },
            "992": {
              "width": 992,
              "sourceWidth": 992,
              "sourceHeight": 10953,
              "reason": "Exact C76 node 983:26865."
            },
            "1200": {
              "width": 1200,
              "sourceWidth": 1200,
              "sourceHeight": 10953,
              "reason": "Exact C76 node 621:7613."
            }
          },
          "jobs": [
            {
              "name": "zodiac-compatibility-c76-1200",
              "status": "export_exists",
              "variantId": "1200",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/zodiac-compatibility-1200-621-7613.png"
              ]
            },
            {
              "name": "zodiac-compatibility-c76-992",
              "status": "export_exists",
              "variantId": "992",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/zodiac-compatibility-992-983-26865.png"
              ]
            },
            {
              "name": "zodiac-compatibility-c76-768",
              "status": "export_exists",
              "variantId": "768",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/zodiac-compatibility-768-986-33306.png"
              ]
            },
            {
              "name": "zodiac-compatibility-c76-576",
              "status": "export_exists",
              "variantId": "576",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/zodiac-compatibility-576-988-24213.png"
              ]
            },
            {
              "name": "zodiac-compatibility-c76-320",
              "status": "export_exists",
              "variantId": "320",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/zodiac-compatibility-320-990-23220.png"
              ]
            }
          ]
        },
        {
          "id": "zodiac-sign-traits",
          "label": "Zodiac Sign Traits",
          "pageSrc": "_unzipped/zodiac-sign-traits-new.html",
          "manifestTitle": "Zodiac Sign Traits · local implementation fixture",
          "lane": "local.preview.zodiac-topic",
          "stateId": "local.preview.zodiac-sign-traits",
          "reviewClassification": "current_live_preview_source_unverified",
          "governedStatus": "local_preview_only_source_refresh_required",
          "acceptanceStatus": "not_accepted",
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "sourceRefs": [],
          "proofRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\status-packets\\compare-board-local-page-catalog-20260714.json"
          ],
          "blockedReason": "Live-верстка доступна для просмотра. Текущая source/live пара и свежая приемка не опубликованы; старые архивные exports не используются.",
          "jobs": []
        }
      ]
    },
    {
      "id": "auth",
      "label": "Auth",
      "text": "Вход, регистрация и восстановление доступа.",
      "pages": [
        {
          "id": "auth-create",
          "label": "Auth Create",
          "pageSrc": "_unzipped/auth-create-new.html",
          "manifestTitle": "Auth Create · local implementation fixture",
          "lane": "local.preview.auth",
          "stateId": "local.preview.auth-create",
          "reviewClassification": "legacy_alias_noncanonical",
          "governedStatus": "noncanonical_alias_source_bound_to_signup_step_1",
          "acceptanceStatus": "not_accepted",
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [],
          "sourceRefs": [
            "H:\\Nebula\\GPT\\_unzipped\\signup-step-1.html",
            "H:\\GPT-Codex\\.ops\\docs\\projects\\oracle-nebula\\FIGMA-COMPANION-REGISTRY.json"
          ],
          "proofRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\status-packets\\compare-board-local-page-catalog-20260714.json"
          ],
          "blockedReason": "Legacy alias only; canonical source and route are signup-step-1.html. Do not use this alias as a separate Figma page.",
          "jobs": []
        },
        {
          "id": "auth-login-state",
          "label": "Auth Login State",
          "pageSrc": "_unzipped/auth-login-state-new.html",
          "manifestTitle": "Auth Login State · local implementation fixture",
          "lane": "local.preview.auth",
          "stateId": "local.preview.auth-login-state",
          "reviewClassification": "legacy_alias_noncanonical",
          "governedStatus": "noncanonical_alias_source_bound_to_login",
          "acceptanceStatus": "not_accepted",
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [],
          "sourceRefs": [
            "H:\\Nebula\\GPT\\_unzipped\\login.html",
            "H:\\GPT-Codex\\.ops\\docs\\projects\\oracle-nebula\\FIGMA-COMPANION-REGISTRY.json"
          ],
          "proofRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\status-packets\\compare-board-local-page-catalog-20260714.json"
          ],
          "blockedReason": "Legacy alias only; canonical source and route are login.html. Do not use this alias as a separate Figma page.",
          "jobs": []
        },
        {
          "id": "auth-step2",
          "label": "Auth Step2",
          "pageSrc": "_unzipped/auth-step2-new.html",
          "manifestTitle": "Auth Step2 · local implementation fixture",
          "lane": "local.preview.auth",
          "stateId": "local.preview.auth-step2",
          "reviewClassification": "legacy_alias_noncanonical",
          "governedStatus": "noncanonical_alias_source_bound_to_signup_step_2",
          "acceptanceStatus": "not_accepted",
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [],
          "sourceRefs": [
            "H:\\Nebula\\GPT\\_unzipped\\signup-step-2.html",
            "H:\\GPT-Codex\\.ops\\docs\\projects\\oracle-nebula\\FIGMA-COMPANION-REGISTRY.json"
          ],
          "proofRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\status-packets\\compare-board-local-page-catalog-20260714.json"
          ],
          "blockedReason": "Legacy alias only; canonical source and route are signup-step-2.html. Do not use this alias as a separate Figma page.",
          "jobs": []
        },
        {
          "id": "forgot-password",
          "label": "Forgot Password",
          "pageSrc": "_unzipped/auth-forgot-new.html",
          "manifestTitle": "Forgot Password · local implementation fixture",
          "lane": "local.preview.auth",
          "stateId": "local.preview.forgot-password",
          "reviewClassification": "source_present_partial_candidate_route_unresolved",
          "governedStatus": "source_present_partial_candidate_route_review",
          "acceptanceStatus": "not_accepted",
          "sourceComparable": false,
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "sourceRefs": [
            "F:\\Figma Nebula\\c76-official-copy-pending-candidate-delta-20260728\\PENDING-OFFICIAL-COPY-CANDIDATE-DELTA.json"
          ],
          "proofRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\status-packets\\compare-board-local-page-catalog-20260714.json"
          ],
          "blockedReason": "В Figma найден exact phrase partial 480-кандидат Forgot Password; полная five-width page-level binding не подтверждена.",
          "sourceDiscoveryStatus": "candidate_source_partial_route_open",
          "jobs": []
        },
        {
          "id": "login",
          "label": "LOG in",
          "pageSrc": "_unzipped/login.html",
          "manifestTitle": "LOG in · local implementation fixture",
          "lane": "local.preview.auth",
          "stateId": "local.preview.login",
          "reviewClassification": "source_current_crosswalked",
          "governedStatus": "local_preview_source_bound_pm_frontend_placeholder",
          "acceptanceStatus": "not_accepted",
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [],
          "sourceRefs": [
            "H:\\GPT-Codex\\.ops\\docs\\projects\\oracle-nebula\\FIGMA-COMPANION-REGISTRY.json",
            "H:\\Nebula\\GPT\\_unzipped\\login.html"
          ],
          "proofRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\status-packets\\compare-board-local-page-catalog-20260714.json"
          ],
          "blockedReason": "Source crosswalk подтвержден. PM/frontend handoff открыт; backend semantics и runtime acceptance не утверждены.",
          "jobs": []
        },
        {
          "id": "signup-step-2",
          "label": "Sign in 2 STEP",
          "pageSrc": "_unzipped/signup-step-2.html",
          "manifestTitle": "Sign in 2 STEP · local implementation fixture",
          "lane": "local.preview.auth",
          "stateId": "local.preview.signup-step-2",
          "reviewClassification": "source_current_crosswalked",
          "governedStatus": "local_preview_source_bound_pm_frontend_placeholder",
          "acceptanceStatus": "not_accepted",
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [],
          "sourceRefs": [
            "H:\\GPT-Codex\\.ops\\docs\\projects\\oracle-nebula\\FIGMA-COMPANION-REGISTRY.json",
            "H:\\Nebula\\GPT\\_unzipped\\signup-step-2.html"
          ],
          "proofRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\status-packets\\compare-board-local-page-catalog-20260714.json"
          ],
          "blockedReason": "Source crosswalk подтвержден. PM/frontend handoff открыт; backend semantics и runtime acceptance не утверждены.",
          "jobs": []
        },
        {
          "id": "signup-create",
          "label": "Sign in CREATE",
          "pageSrc": "_unzipped/signup-step-1.html",
          "manifestTitle": "Sign in CREATE · local implementation fixture",
          "lane": "local.preview.auth",
          "stateId": "local.preview.signup-create",
          "reviewClassification": "source_current_crosswalked",
          "governedStatus": "local_preview_source_bound_pm_frontend_placeholder",
          "acceptanceStatus": "not_accepted",
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [],
          "sourceRefs": [
            "H:\\GPT-Codex\\.ops\\docs\\projects\\oracle-nebula\\FIGMA-COMPANION-REGISTRY.json",
            "H:\\Nebula\\GPT\\_unzipped\\signup-step-1.html"
          ],
          "proofRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\status-packets\\compare-board-local-page-catalog-20260714.json"
          ],
          "blockedReason": "Source crosswalk подтвержден. PM/frontend handoff открыт; backend semantics и runtime acceptance не утверждены.",
          "jobs": []
        }
      ]
    },
    {
      "id": "account-commerce",
      "label": "ЛК / Оплата",
      "text": "Профиль, настройки, подтверждения, платежи и связанные состояния.",
      "pages": [
        {
          "id": "email-confirmation",
          "label": "Email Confirmation",
          "pageSrc": "_unzipped/email-confirmation-new.html",
          "manifestTitle": "Email Confirmation · local implementation fixture",
          "lane": "local.preview.account-commerce",
          "stateId": "local.preview.email-confirmation",
          "reviewClassification": "current_live_preview_source_unverified",
          "governedStatus": "local_preview_only_source_refresh_required",
          "acceptanceStatus": "not_accepted",
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "sourceRefs": [],
          "proofRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\status-packets\\compare-board-local-page-catalog-20260714.json"
          ],
          "blockedReason": "Live-верстка доступна для просмотра. Текущая source/live пара и свежая приемка не опубликованы; старые архивные exports не используются.",
          "jobs": []
        },
        {
          "id": "live-chat-rules",
          "label": "Live Chat Rules",
          "pageSrc": "_unzipped/live-chat-rules-new.html",
          "manifestTitle": "Live Chat Rules · local implementation fixture",
          "lane": "local.preview.account-commerce",
          "stateId": "local.preview.live-chat-rules",
          "reviewClassification": "current_live_preview_source_unverified",
          "governedStatus": "local_preview_only_source_refresh_required",
          "acceptanceStatus": "not_accepted",
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "sourceRefs": [],
          "proofRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\status-packets\\compare-board-local-page-catalog-20260714.json"
          ],
          "blockedReason": "Live-верстка доступна для просмотра. Текущая source/live пара и свежая приемка не опубликованы; старые архивные exports не используются.",
          "jobs": []
        },
        {
          "id": "payment-modal",
          "label": "Payment Modal",
          "pageSrc": "_unzipped/payment-modal-new.html",
          "manifestTitle": "Payment Modal · local implementation fixture",
          "lane": "local.preview.account-commerce",
          "stateId": "local.preview.payment-modal",
          "reviewClassification": "current_live_preview_source_unverified",
          "governedStatus": "local_preview_only_source_refresh_required",
          "acceptanceStatus": "not_accepted",
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "sourceRefs": [],
          "proofRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\status-packets\\compare-board-local-page-catalog-20260714.json"
          ],
          "blockedReason": "Live-верстка доступна для просмотра. Текущая source/live пара и свежая приемка не опубликованы; старые архивные exports не используются.",
          "jobs": []
        },
        {
          "id": "phone-confirmation",
          "label": "Phone Confirmation",
          "pageSrc": "_unzipped/phone-confirmation-new.html",
          "manifestTitle": "Phone Confirmation · local implementation fixture",
          "lane": "local.preview.account-commerce",
          "stateId": "local.preview.phone-confirmation",
          "reviewClassification": "current_live_preview_source_unverified",
          "governedStatus": "local_preview_only_source_refresh_required",
          "acceptanceStatus": "not_accepted",
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "sourceRefs": [],
          "proofRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\status-packets\\compare-board-local-page-catalog-20260714.json"
          ],
          "blockedReason": "Live-верстка доступна для просмотра. Текущая source/live пара и свежая приемка не опубликованы; старые архивные exports не используются.",
          "jobs": []
        },
        {
          "id": "profile-user",
          "label": "Profile User",
          "pageSrc": "_unzipped/profile-user-new.html",
          "manifestTitle": "Profile User · local implementation fixture",
          "lane": "local.preview.account-commerce",
          "stateId": "local.preview.profile-user",
          "reviewClassification": "source_current_authenticated_surface_exact",
          "governedStatus": "local_preview_authenticated_source_exact_route_semantics_open",
          "acceptanceStatus": "not_accepted",
          "sourceComparable": false,
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [],
          "sourceRefs": [
            "F:\\Figma Nebula\\c76-source-index-20260727\\C76-PAGE-CROSSWALK-20260727.json",
            "H:\\GPT-Codex\\.ops\\docs\\projects\\oracle-nebula\\FIGMA-COMPANION-REGISTRY.json"
          ],
          "proofRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\status-packets\\compare-board-local-page-catalog-20260714.json"
          ],
          "blockedReason": "Пять точных C76 authenticated Profile frames подтверждают источник. Route/state semantics не закрыты; не связывать с public route.",
          "sourceDiscoveryStatus": "exact_authenticated_nodes_raster_pending",
          "jobs": [
            {
              "name": "profile-c76-1200",
              "status": "source_node_exists_raster_pending",
              "variantId": "1200",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/profile-1200-1134-32217.png"
              ]
            },
            {
              "name": "profile-c76-992",
              "status": "source_node_exists_raster_pending",
              "variantId": "992",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/profile-992-1415-47126.png"
              ]
            },
            {
              "name": "profile-c76-768",
              "status": "source_node_exists_raster_pending",
              "variantId": "768",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/profile-768-1415-48176.png"
              ]
            },
            {
              "name": "profile-c76-576",
              "status": "source_node_exists_raster_pending",
              "variantId": "576",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/profile-576-1415-48802.png"
              ]
            },
            {
              "name": "profile-c76-320",
              "status": "source_node_exists_raster_pending",
              "variantId": "320",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/profile-320-1415-49419.png"
              ]
            }
          ]
        },
        {
          "id": "psychic-chat",
          "label": "Psychic Chat",
          "pageSrc": "_unzipped/psychic-chat-new.html",
          "manifestTitle": "Psychic Chat · local implementation fixture",
          "lane": "local.preview.account-commerce",
          "stateId": "local.preview.psychic-chat",
          "reviewClassification": "current_live_preview_source_unverified",
          "governedStatus": "local_preview_only_source_refresh_required",
          "acceptanceStatus": "not_accepted",
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "sourceRefs": [],
          "proofRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\status-packets\\compare-board-local-page-catalog-20260714.json"
          ],
          "blockedReason": "Live-верстка доступна для просмотра. Текущая source/live пара и свежая приемка не опубликованы; старые архивные exports не используются.",
          "jobs": []
        },
        {
          "id": "referral-program",
          "label": "Referral Program",
          "pageSrc": "_unzipped/referral-program-new.html",
          "manifestTitle": "Referral Program · local implementation fixture",
          "lane": "local.preview.account-commerce",
          "stateId": "local.preview.referral-program",
          "reviewClassification": "current_live_preview_source_unverified",
          "governedStatus": "local_preview_only_source_refresh_required",
          "acceptanceStatus": "not_accepted",
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "sourceRefs": [],
          "proofRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\status-packets\\compare-board-local-page-catalog-20260714.json"
          ],
          "blockedReason": "Live-верстка доступна для просмотра. Текущая source/live пара и свежая приемка не опубликованы; старые архивные exports не используются.",
          "jobs": []
        },
        {
          "id": "settings-personal",
          "label": "Settings Personal",
          "pageSrc": "_unzipped/settings-personal-new.html",
          "manifestTitle": "Settings Personal · local implementation fixture",
          "lane": "local.preview.account-commerce",
          "stateId": "local.preview.settings-personal",
          "reviewClassification": "source_present_exact_candidate_route_unresolved",
          "governedStatus": "source_present_exact_candidate_route_semantics_open",
          "acceptanceStatus": "not_accepted",
          "sourceComparable": false,
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [],
          "sourceRefs": [
            "F:\\Figma Nebula\\c76-official-copy-pending-candidate-delta-20260728\\PENDING-OFFICIAL-COPY-CANDIDATE-DELTA.json"
          ],
          "proofRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\status-packets\\compare-board-local-page-catalog-20260714.json"
          ],
          "blockedReason": "Пять exact-width кандидатов Settings Account Information найдены в Figma, но Settings Personal и authenticated state semantics ещё не связаны.",
          "sourceDiscoveryStatus": "candidate_exact_source_route_open",
          "jobs": []
        }
      ]
    },
    {
      "id": "legal",
      "label": "Legal",
      "text": "Юридические и платежные правила.",
      "pages": [
        {
          "id": "cookie-policy",
          "label": "Cookie Policy",
          "pageSrc": "_unzipped/cookie-policy-new.html",
          "manifestTitle": "Cookie Policy · local implementation fixture",
          "lane": "local.preview.legal",
          "stateId": "local.preview.cookie-policy",
          "reviewClassification": "source_present_partial_candidate_context_mismatch",
          "governedStatus": "source_present_partial_candidate_context_mismatch_review",
          "acceptanceStatus": "not_accepted",
          "sourceComparable": false,
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "sourceRefs": [
            "F:\\Figma Nebula\\c76-official-copy-pending-candidate-delta-20260728\\PENDING-OFFICIAL-COPY-CANDIDATE-DELTA.json"
          ],
          "proofRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\status-packets\\compare-board-local-page-catalog-20260714.json"
          ],
          "blockedReason": "В Figma найден только partial 480-кандидат с контекстным конфликтом; exact 1200/992/768/576/320 page-level source не подтверждён.",
          "sourceDiscoveryStatus": "candidate_source_partial_context_mismatch",
          "jobs": []
        },
        {
          "id": "payment-terms",
          "label": "Payment Terms",
          "pageSrc": "_unzipped/payment-terms-new.html",
          "manifestTitle": "Payment Terms · local implementation fixture",
          "lane": "local.preview.legal",
          "stateId": "local.preview.payment-terms",
          "reviewClassification": "current_live_preview_source_unverified",
          "governedStatus": "local_preview_only_source_refresh_required",
          "acceptanceStatus": "not_accepted",
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "sourceRefs": [],
          "proofRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\status-packets\\compare-board-local-page-catalog-20260714.json"
          ],
          "blockedReason": "Live-верстка доступна для просмотра. Текущая source/live пара и свежая приемка не опубликованы; старые архивные exports не используются.",
          "jobs": []
        },
        {
          "id": "privacy-policy",
          "label": "Privacy Policy",
          "pageSrc": "nebula-easy-privacy-policy.html",
          "manifestTitle": "Privacy Policy · C76 source/live · strict visual audit required",
          "lane": "source.live.legal",
          "stateId": "privacy-policy.state.default",
          "reviewClassification": "current_source_live_pair_strict_visual_audit_required",
          "governedStatus": "source_live_pair_current_strict_visual_audit_required",
          "acceptanceStatus": "not_accepted",
          "sourceComparable": true,
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [],
          "sourceRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\c76-normalized-export-20260727\\privacy-policy.json",
            "C76M54fY7z926wIQoWFh8Y / ,,,,",
            "F:\\Figma Nebula\\c76-source-index-20260727\\C76-PAGE-CROSSWALK-20260727.json"
          ],
          "proofRefs": [
            "H:\\GPT-Codex\\.ops\\chief-of-staff\\proofs\\oracle-nebula\\privacy-policy-c76-source-publication-20260720\\source-authority-binding.json"
          ],
          "blockedReason": "Exact current C76 page-level frames are exported and hash-bound for all five widths; visual acceptance remains a separate gate.",
          "variantOverrides": {
            "320": {
              "width": 320,
              "sourceWidth": 320,
              "sourceHeight": 18199,
              "reason": "Exact C76 node 872:7588."
            },
            "576": {
              "width": 576,
              "sourceWidth": 576,
              "sourceHeight": 11165,
              "reason": "Exact C76 node 872:7387."
            },
            "768": {
              "width": 768,
              "sourceWidth": 768,
              "sourceHeight": 9747,
              "reason": "Exact C76 node 871:9202."
            },
            "992": {
              "width": 992,
              "sourceWidth": 992,
              "sourceHeight": 10121,
              "reason": "Exact C76 node 871:9004."
            },
            "1200": {
              "width": 1200,
              "sourceWidth": 1200,
              "sourceHeight": 9236,
              "reason": "Exact C76 node 869:8706."
            }
          },
          "jobs": [
            {
              "name": "privacy-policy-c76-1200",
              "status": "export_exists",
              "variantId": "1200",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/privacy-policy-1200-869-8706.png"
              ]
            },
            {
              "name": "privacy-policy-c76-992",
              "status": "export_exists",
              "variantId": "992",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/privacy-policy-992-871-9004.png"
              ]
            },
            {
              "name": "privacy-policy-c76-768",
              "status": "export_exists",
              "variantId": "768",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/privacy-policy-768-871-9202.png"
              ]
            },
            {
              "name": "privacy-policy-c76-576",
              "status": "export_exists",
              "variantId": "576",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/privacy-policy-576-872-7387.png"
              ]
            },
            {
              "name": "privacy-policy-c76-320",
              "status": "export_exists",
              "variantId": "320",
              "expectedArtifacts": [
                "compare-board-sources/c76-normalized-export-20260727/privacy-policy-320-872-7588.png"
              ]
            }
          ]
        },
        {
          "id": "refund-policy",
          "label": "Refund Policy",
          "pageSrc": "_unzipped/refund-policy-new.html",
          "manifestTitle": "Refund Policy · local implementation fixture",
          "lane": "local.preview.legal",
          "stateId": "local.preview.refund-policy",
          "reviewClassification": "current_live_preview_source_unverified",
          "governedStatus": "local_preview_only_source_refresh_required",
          "acceptanceStatus": "not_accepted",
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "sourceRefs": [],
          "proofRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\status-packets\\compare-board-local-page-catalog-20260714.json"
          ],
          "blockedReason": "Live-верстка доступна для просмотра. Текущая source/live пара и свежая приемка не опубликованы; старые архивные exports не используются.",
          "jobs": []
        },
        {
          "id": "terms-conditions",
          "label": "Terms Conditions",
          "pageSrc": "_unzipped/terms-conditions-new.html",
          "manifestTitle": "Terms Conditions · local implementation fixture",
          "lane": "local.preview.legal",
          "stateId": "local.preview.terms-conditions",
          "reviewClassification": "current_live_preview_source_unverified",
          "governedStatus": "local_preview_only_source_refresh_required",
          "acceptanceStatus": "not_accepted",
          "availableVariants": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "missingSourceBreakpoints": [
            "1200",
            "992",
            "768",
            "576",
            "320"
          ],
          "sourceRefs": [],
          "proofRefs": [
            "H:\\Nebula\\GPT\\figma-manifest\\status-packets\\compare-board-local-page-catalog-20260714.json"
          ],
          "blockedReason": "Live-верстка доступна для просмотра. Текущая source/live пара и свежая приемка не опубликованы; старые архивные exports не используются.",
          "jobs": []
        }
      ]
    }
  ]
};
