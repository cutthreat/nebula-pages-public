# topic-new local goal and source audit

Status: active
Page: topic-new.html
Local URL: http://127.0.0.1:4180/_unzipped/topic-new.html
Workspace: H:\GPT-Codex
Target contour: H:\Nebula\GPT\_unzipped
Created: 2026-06-15

## Local Goal

Bring topic-new.html to a quality source-backed Oracle/Nebula content-page layout while preserving the shared site architecture, using Home-derived public/content shell and accepted block reuse before page-local implementation.

## Governance

Preflight: pass
Mode: artifact_only
Handoff: H:\GPT-Codex\Codex-Contour-Next\reports\governance-handoffs\oracle-nebula-topic-new-source-backed-layout.handoff.json

## Intake

Real outcome: source-backed, visually accepted topic page with proof screenshots and no speculative redraws.
Smallest scope: topic-new.html and only the CSS/assets required to bind it to existing accepted shell/content patterns.
Non-goals: Figma MCP, live activation, scheduler/direct OpenClaw/global fan-out, browser profile or route mutation, rebuilding accepted blocks from scratch.
Done criteria: source/reuse audit exists, implementation uses accepted patterns or local Figma exports, visual proof exists for required breakpoints, no blank/pending proof, no known blocker.
Stop conditions: missing local Figma source, source_lineage_missing, page-local rebuild of accepted block, blank proof, CSS tuning by eye, composite screenshot as semantic layer.

## Page Family

page_family: public content/topic page
base_shell: Home-derived shell

## figma_screen_reuse_audit

- Home `topics-section`: approved source-backed reuse. Local spec: `H:\Nebula\GPT\figma-manifest\screen-specs\home\06-topics-section.json`; resolved reference: `H:\Nebula\GPT\_unzipped\img\breakpoints\home-1200-reference.png`; assets: `img/topic-1.png` through `img/topic-6.png`, `img/topics-offer-1.png` through `img/topics-offer-3.png`.
- Home shell: approved public/content shell source. Reuse header, Bootstrap container, `home.css`, `home.js`, footer, and shared button/link classes.
- all-psychic-new / psychic-reading-new: reuse candidates only for public-page shell behavior and responsive defect class checks; not used as source for topic content because Home already owns the topics block.
- `topic-new`: local Figma spec directory exists but has no page-specific JSON; `_index.csv` has no `topic-new.html` entry. Treat page-specific custom hero/card design as non-source-backed.

## page_planning_reuse_inventory

- `reuse_approved_block`: Home header shell, Home footer shell, Home `topics-section` promos/grid/typography/assets/responsive behavior.
- `reuse_candidate_block`: all-psychic-new / psychic-reading-new public-page topnav and footer behavior for cross-breakpoint sanity checks only.
- `source_backed_variant`: `topic-new` active topnav state uses existing `.site-header__link.is-active` class from `home.css`; `topic-shell` mobile override lifts Home's own `topics-section__promos` stacking pattern from the smaller Home breakpoint to `575.98px` for this standalone topic page after screenshot proof showed horizontal overflow at 390/320.
- `current_figma_unique`: none found for `topic-new`.
- `remove_base_region`: inline `.topic-page`, `.topic-head`, `.topic-grid`, `.topic-card`, `.topic-support` custom regions.
- `add_figma_region`: none; do not create page-unique semantic regions without local source.
- `source_gap`: missing page-specific `topic-new` Figma screen JSON/reference export. Covered by accepted Home topics-section reuse for this content hub; any future page-specific design requires targeted manual-export packet.
- `acceptance_source_gap_verdict`: non-blocking. Current accepted scope has no page-unique Figma region; the implemented semantic layer is the source-backed Home `topics-section` reuse.

## source-layer-map

- Header: Home-derived shell (`home.html` header markup/classes, `home.css` topnav rules).
- Main section: Home `topics-section` screen spec `06-topics-section.json`, Home markup block, existing local bundle assets.
- Cards/promos: exact Home `topics-section__promo-*` and `topics-section__card*` class language; no composite screenshots and no redrawn cards.
- Footer: Home-derived footer shell (`home.html` footer markup/classes, `home.css` footer rules).
- Page-local additions: metadata/title, active topnav state, and `topic-shell` mobile promo stacking guard for the accepted Home topics block. No new page-unique design layer.

## Proof

- Runtime verifier: `H:\Nebula\GPT\_unzipped\visual-review\topic-new\cdp-proof\summary.json`
- Contact sheet: `H:\Nebula\GPT\_unzipped\visual-review\topic-new\cdp-proof\topic-new-contact-sheet.png`
- Live screenshots: `H:\Nebula\GPT\_unzipped\visual-review\topic-new\cdp-proof\topic-new-1200.png`, `topic-new-992.png`, `topic-new-768.png`, `topic-new-576.png`, `topic-new-390.png`, `topic-new-320.png`
- Compare-board proof: `H:\Nebula\GPT\_unzipped\visual-review\topic-new\cdp-proof\nebula-topnav-compare-board-1200.png`
- Breakpoints: 1200, 992, 768, 576, 390, 320
- Verifier result: pass. All breakpoints report complete images 15/15, six source-backed topic cards, no horizontal overflow, footer gap 0, sticky header pass, and expected Bootstrap container widths/client widths.
