
    const VARIANTS = [
      { id: "1200", label: "1200", width: 1200 },
      { id: "992", label: "992", width: 992 },
      { id: "768", label: "768", width: 768 },
      { id: "576", label: "576", width: 576 },
      { id: "320", label: "320", width: 320 }
    ];

    const VIEW_MODES = [
      { id: "page", label: "Вся страница" },
      { id: "screen", label: "По экранам" }
    ];

    const COMPARE_LENSES = [
      { id: "split", label: "Сплит" },
      { id: "overlay", label: "Наложение" },
      { id: "wipe", label: "Шторка" }
    ];

    const OVERLAY_TOP_LAYERS = [
      { id: "implementation", label: "Live сверху" },
      { id: "source", label: "Эталон сверху" }
    ];

    const BLOCKED_REASON_EXPORT_PENDING = "Есть manifest-backed source-contract, но локальный export-job или source PNG для этой страницы пока не зафиксирован.";

    const REVIEW_ROUTE_FAMILIES = [
      {
        id: "auth",
        label: "Приоритет Auth",
        text: "Auth slice: Login/Forgot source-ready; Signup source-blocked до импорта full-screen Figma reference.",
        pages: [
          { pageId: "login", variants: ["1200"] },
          { pageId: "forgot-password", variants: ["1200"] },
          { pageId: "signup-create", variants: ["1200", "992", "768", "576", "320"] },
          { pageId: "signup-step-2", variants: ["1200", "992", "768", "576", "320"] }
        ]
      },
      {
        id: "zodiac",
        label: "Приоритет Zodiac",
        text: "Основной контур review с самым сильным source foothold.",
        pages: [
          { pageId: "zodiac-compatibility", variants: ["1200", "768", "320"] },
          { pageId: "taurus-compatibility", variants: ["1200", "768"] },
          { pageId: "horoscope-detail", variants: ["768", "320"] }
        ]
      },
      {
        id: "articles",
        label: "Приоритет Articles",
        text: "Короткое family, удобное для быстрого full-pass.",
        pages: [
          { pageId: "blog", variants: ["1200", "768", "320"] },
          { pageId: "blog-input", variants: ["1200", "768"] }
        ]
      },
      {
        id: "psychics",
        label: "Приоритет Psychics",
        text: "Hub и expert flow для верхнего навигационного контура.",
        pages: [
          { pageId: "all-psychic", variants: ["1200", "992", "768", "576", "320"] },
          { pageId: "expert-page", variants: ["768", "320"] }
        ]
      },
      {
        id: "ethalon-page",
        label: "Приоритет Ethalon",
        text: "Новые full-page цели с локальным Figma source-backed экспортом.",
        pages: [
          { pageId: "404", variants: ["1200", "992", "768", "576"] },
          { pageId: "aura-reading", variants: ["1200", "992", "768", "576", "320"] }
        ]
      }
    ];

    const FAMILIES = [
      {
        id: "auth",
        label: "Auth",
        pages: [
          {
            id: "login",
            label: "LOG in",
            pageSrc: "_unzipped/login.html",
            manifestTitle: "Login - Neuro",
            jobs: [
              {
                name: "auth-login-1200-source-ready",
                status: "export_exists",
                variantId: "1200",
                expectedArtifacts: [
                  "_unzipped/img/login-figma-reference.png"
                ]
              }
            ]
          },
          {
            id: "forgot-password",
            label: "Forgot Password",
            pageSrc: "_unzipped/auth-forgot-new.html",
            manifestTitle: "Forgot Password - Neuro",
            jobs: [
              {
                name: "auth-forgot-1200-source-ready",
                status: "export_exists",
                variantId: "1200",
                expectedArtifacts: [
                  "_unzipped/img/forgot-export-raster.png"
                ]
              }
            ]
          },
          {
            id: "signup-create",
            label: "Sign in CREATE",
            pageSrc: "_unzipped/signup-step-1.html",
            manifestTitle: "Signup Create - Neuro",
            blockedReason: "Source-blocked: найдены только weak specs; full-screen 1200+ Figma reference пока не импортирован.",
            jobs: []
          },
          {
            id: "signup-step-2",
            label: "Sign in 2 STEP",
            pageSrc: "_unzipped/signup-step-2.html",
            manifestTitle: "Signup Step 2 - Neuro",
            blockedReason: "Source-blocked: найдены только weak specs; full-screen 1200+ Figma reference пока не импортирован.",
            jobs: []
          }
        ]
      },
      {
        id: "psychics",
        label: "Psychics",
        pages: [
          {
            id: "all-psychic",
            label: "All Psychics",
            pageSrc: "_unzipped/all-psychic-new.html",
            manifestTitle: "Psychics - Neuro",
            jobs: [
              {
                name: "20260414-all-psychic-1200",
                status: "export_exists",
                variantId: "1200",
                expectedArtifacts: [
                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/924-16998-all-psychic-new-1200/screenshot.png"
                ]
              },
              {
                name: "20260414-all-psychic-992",
                status: "export_exists",
                variantId: "992",
                expectedArtifacts: [
                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/924-17233-all-psychic-new-992/screenshot.png"
                ]
              },
              {
                name: "20260414-all-psychic-768",
                status: "export_exists",
                variantId: "768",
                expectedArtifacts: [
                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/924-17473-all-psychic-new-768/screenshot.png"
                ]
              },
              {
                name: "20260414-all-psychic-576",
                status: "export_exists",
                variantId: "576",
                expectedArtifacts: [
                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/924-17713-all-psychic-new-576/screenshot.png"
                ]
              },
              {
                name: "20260414-all-psychic-320",
                status: "export_exists",
                variantId: "320",
                expectedArtifacts: [
                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/924-17948-all-psychic-new-320/screenshot.png"
                ]
              }
            ]
          },
          {
            id: "expert-page",
            label: "Expert Page",
            pageSrc: "_unzipped/expert-page-new.html",
            manifestTitle: "Expert Page - Neuro",
            blockedReason: BLOCKED_REASON_EXPORT_PENDING,
            jobs: []
          }
        ]
      },
      {
        id: "ethalon-page",
        label: "Ethalon Pages",
        pages: [
          {
            id: "404",
            label: "404",
            pageSrc: "_unzipped/404-new.html",
            manifestTitle: "404 - Neuro",
            jobs: [
              {
                name: "20260414-404-1200",
                status: "export_exists",
                variantId: "1200",
                expectedArtifacts: [
                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/1064-23227-404-page-1200/screenshot.png"
                ]
              },
              {
                name: "20260414-404-992",
                status: "export_exists",
                variantId: "992",
                expectedArtifacts: [
                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/1064-23394-404-page-992/screenshot.png"
                ]
              },
              {
                name: "20260414-404-768",
                status: "export_exists",
                variantId: "768",
                expectedArtifacts: [
                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/1064-23542-404-page-768/screenshot.png"
                ]
              },
              {
                name: "20260414-404-576",
                status: "export_exists",
                variantId: "576",
                expectedArtifacts: [
                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/1064-23692-404-page-576/screenshot.png"
                ]
              }
            ]
          },
          {
            id: "aura-reading",
            label: "Aura Reading",
            pageSrc: "_unzipped/aura-reading-new.html",
            manifestTitle: "Aura Reading - Neuro",
            jobs: [
              {
                name: "20260414-aura-reading-1200",
                status: "export_exists",
                variantId: "1200",
                expectedArtifacts: [
                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/902-13736-aura-reading-new-1200/screenshot.png"
                ]
              },
              {
                name: "20260414-aura-reading-992",
                status: "export_exists",
                variantId: "992",
                expectedArtifacts: [
                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/902-13967-aura-reading-new-992/screenshot.png"
                ]
              },
              {
                name: "20260414-aura-reading-768",
                status: "export_exists",
                variantId: "768",
                expectedArtifacts: [
                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/902-13500-aura-reading-new-768/screenshot.png"
                ]
              },
              {
                name: "20260414-aura-reading-576",
                status: "export_exists",
                variantId: "576",
                expectedArtifacts: [
                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/906-17772-aura-reading-new-576/screenshot.png"
                ]
              },
              {
                name: "20260414-aura-reading-320",
                status: "export_exists",
                variantId: "320",
                expectedArtifacts: [
                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/906-17985-aura-reading-new-320/screenshot.png"
                ]
              }
            ]
          }
        ]
      },
      {
        id: "topic",
        label: "Topic",
        pages: [
          { id: "topic-hub", label: "Topic Hub", pageSrc: "_unzipped/topic-new.html", manifestTitle: "Topics - Neuro", blockedReason: BLOCKED_REASON_EXPORT_PENDING, jobs: [] },
          { id: "angel-numbers", label: "Angel Numbers", pageSrc: "_unzipped/angel-numbers-meaning-new.html", manifestTitle: "Angel Numbers Meaning - Neuro", blockedReason: BLOCKED_REASON_EXPORT_PENDING, jobs: [] },
          { id: "aura-colors", label: "Aura Colors", pageSrc: "_unzipped/aura-colors-meaning-new.html", manifestTitle: "Aura Colors Meaning - Neuro", blockedReason: BLOCKED_REASON_EXPORT_PENDING, jobs: [] },
          { id: "crystal-stone", label: "Crystal and Stone", pageSrc: "_unzipped/crystal-and-stone-meanings-new.html", manifestTitle: "Crystal and Stone Meanings - Neuro", blockedReason: BLOCKED_REASON_EXPORT_PENDING, jobs: [] },
          { id: "spiritual-meanings", label: "Spiritual Meanings", pageSrc: "_unzipped/spiritual-meanings-new.html", manifestTitle: "Spiritual Meanings - Neuro", blockedReason: BLOCKED_REASON_EXPORT_PENDING, jobs: [] },
          { id: "tarot-cards-meaning", label: "Tarot Cards Meaning", pageSrc: "_unzipped/tarot-cards-meaning-new.html", manifestTitle: "Tarot Cards Meaning - Neuro", blockedReason: BLOCKED_REASON_EXPORT_PENDING, jobs: [] }
        ]
      },
      {
        id: "zodiac",
        label: "Zodiac",
        pages: [
          {
            id: "zodiac-compatibility",
            label: "Zodiac Compatibility",
            pageSrc: "_unzipped/zodiac-compatibility-new.html",
            manifestTitle: "Zodiac Signs - Neuro",
            jobs: [
              {
                name: "002-zodiac-compatibility-new-1200",
                status: "export_exists",
                variantId: "1200",
                expectedArtifacts: [
                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/621-7613-zodiac-compatibility-new-1200/screenshot.png",
                  "figma-export/batch-20260323-121757/exports/002-zodiac-compatibility-new-1200.png",
                  "figma-export/batch-20260323-122743/exports/002-zodiac-compatibility-new-1200.png"
                ]
              },
              {
                name: "005-zodiac-compatibility-new-992",
                status: "pending",
                variantId: "992",
                expectedArtifacts: [
                  "figma-export/batch-20260323-121757/exports/005-zodiac-compatibility-new-992.png",
                  "figma-export/batch-20260323-122743/exports/005-zodiac-compatibility-new-992.png"
                ]
              },
              {
                name: "024-zodiac-compatibility-new-768",
                status: "pending",
                variantId: "768",
                expectedArtifacts: [
                  "figma-export/batch-20260323-121757/exports/024-zodiac-compatibility-new-768.png",
                  "figma-export/batch-20260323-122743/exports/024-zodiac-compatibility-new-768.png"
                ]
              },
              {
                name: "023-zodiac-compatibility-new-576",
                status: "pending",
                variantId: "576",
                expectedArtifacts: [
                  "figma-export/batch-20260323-121757/exports/023-zodiac-compatibility-new-576.png",
                  "figma-export/batch-20260323-122743/exports/023-zodiac-compatibility-new-576.png"
                ]
              },
              {
                name: "022-zodiac-compatibility-new-320",
                status: "pending",
                variantId: "320",
                expectedArtifacts: [
                  "figma-export/batch-20260323-121757/exports/022-zodiac-compatibility-new-320.png",
                  "figma-export/batch-20260323-122743/exports/022-zodiac-compatibility-new-320.png"
                ]
              }
            ]
          },
          {
            id: "taurus-compatibility",
            label: "Taurus Compatibility",
            pageSrc: "_unzipped/taurus-compatibility-new.html",
            manifestTitle: "Taurus Compatibility - Neuro",
            jobs: [
              {
                name: "018-taurus-compatibility-1200",
                status: "export_exists",
                variantId: "1200",
                expectedArtifacts: [
                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/631-5673-taurus-compatibility-1200/screenshot.png",
                  "figma-export/batch-20260323-121757/exports/018-taurus-compatibility-1200.png",
                  "figma-export/batch-20260323-122743/exports/018-taurus-compatibility-1200.png"
                ]
              },
              {
                name: "017-taurus-compatibility-992",
                status: "pending",
                variantId: "992",
                expectedArtifacts: [
                  "figma-export/batch-20260323-121757/exports/017-taurus-compatibility-992.png",
                  "figma-export/batch-20260323-122743/exports/017-taurus-compatibility-992.png"
                ]
              },
              {
                name: "016-taurus-compatibility-768",
                status: "pending",
                variantId: "768",
                expectedArtifacts: [
                  "figma-export/batch-20260323-121757/exports/016-taurus-compatibility-768.png",
                  "figma-export/batch-20260323-122743/exports/016-taurus-compatibility-768.png"
                ]
              }
            ]
          },
          { id: "zodiac-sign-traits", label: "Zodiac Sign Traits", pageSrc: "_unzipped/zodiac-sign-traits-new.html", manifestTitle: "Zodiac Sign Traits - Neuro", blockedReason: BLOCKED_REASON_EXPORT_PENDING, jobs: [] },
          { id: "man-zodiac-sign-traits", label: "Male Sign Traits", pageSrc: "_unzipped/man-zodiac-sign-traits-new.html", manifestTitle: "Man Zodiac Sign Traits - Neuro", blockedReason: BLOCKED_REASON_EXPORT_PENDING, jobs: [] },
          { id: "woman-zodiac-sign-traits", label: "Female Sign Traits", pageSrc: "_unzipped/woman-zodiac-sign-traits-new.html", manifestTitle: "Woman Zodiac Sign Traits - Neuro", blockedReason: BLOCKED_REASON_EXPORT_PENDING, jobs: [] },
          { id: "horoscope-detail", label: "Horoscope Detail", pageSrc: "_unzipped/horoscope-detail-new.html", manifestTitle: "Horoscope Detail - Neuro", blockedReason: BLOCKED_REASON_EXPORT_PENDING, jobs: [] }
        ]
      },
      {
        id: "charts",
        label: "Charts",
        pages: [
          { id: "birth-chart", label: "Birth Chart", pageSrc: "_unzipped/birth-chart-new.html", manifestTitle: "Birth Chart - Neuro", blockedReason: BLOCKED_REASON_EXPORT_PENDING, jobs: [] },
          { id: "daily-horoscope", label: "Daily Horoscope", pageSrc: "_unzipped/daily-horoscope-new.html", manifestTitle: "Daily Horoscope - Neuro", blockedReason: BLOCKED_REASON_EXPORT_PENDING, jobs: [] },
          { id: "life-path", label: "Life Path Calculator", pageSrc: "_unzipped/life-path-calculator-new.html", manifestTitle: "Life Path Calculator - Neuro", blockedReason: BLOCKED_REASON_EXPORT_PENDING, jobs: [] }
        ]
      },
      {
        id: "articles",
        label: "Articles",
        pages: [
          {
            id: "blog",
            label: "Blog",
            pageSrc: "_unzipped/blog-new.html",
            manifestTitle: "Articles - Neuro",
            jobs: [
              {
                name: "020-blog-1200",
                status: "export_exists",
                variantId: "1200",
                expectedArtifacts: [
                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/642-5788-blog-1200/screenshot.png",
                  "figma-export/batch-20260323-121757/exports/020-blog-1200.png",
                  "figma-export/batch-20260323-122743/exports/020-blog-1200.png"
                ]
              }
            ]
          },
          {
            id: "blog-input",
            label: "Blog Input",
            pageSrc: "_unzipped/blog-input-new.html",
            manifestTitle: "Article Draft - Neuro",
            jobs: [
              {
                name: "019-blog-input-1200",
                status: "export_exists",
                variantId: "1200",
                expectedArtifacts: [
                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/643-7448-blog-input-1200/screenshot.png",
                  "figma-export/batch-20260323-121757/exports/019-blog-input-1200.png",
                  "figma-export/batch-20260323-122743/exports/019-blog-input-1200.png"
                ]
              }
            ]
          }
        ]
      }
    ];

    // ORACLE_ONBOARDED_ETHALON_PAGES_START
    const NEBULA_ONBOARDED_ETHALON_PAGES = [
          {
                "id": "all-psychic",
                "label": "All Psychics",
                "pageSrc": "_unzipped/all-psychic-new.html",
                "manifestTitle": "Psychics - Neuro",
                "jobs": [
                      {
                            "name": "20260414-all-psychic-1200",
                            "status": "export_exists",
                            "variantId": "1200",
                            "expectedArtifacts": [
                                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/924-16998-all-psychic-new-1200/screenshot.png"
                            ]
                      },
                      {
                            "name": "20260414-all-psychic-992",
                            "status": "export_exists",
                            "variantId": "992",
                            "expectedArtifacts": [
                                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/924-17233-all-psychic-new-992/screenshot.png"
                            ]
                      },
                      {
                            "name": "20260414-all-psychic-768",
                            "status": "export_exists",
                            "variantId": "768",
                            "expectedArtifacts": [
                                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/924-17473-all-psychic-new-768/screenshot.png"
                            ]
                      },
                      {
                            "name": "20260414-all-psychic-576",
                            "status": "export_exists",
                            "variantId": "576",
                            "expectedArtifacts": [
                                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/924-17713-all-psychic-new-576/screenshot.png"
                            ]
                      },
                      {
                            "name": "20260414-all-psychic-320",
                            "status": "export_exists",
                            "variantId": "320",
                            "expectedArtifacts": [
                                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/924-17948-all-psychic-new-320/screenshot.png"
                            ]
                      }
                ]
          },
          {
                "id": "404",
                "label": "404",
                "pageSrc": "_unzipped/404-new.html",
                "manifestTitle": "404 - Neuro",
                "jobs": [
                      {
                            "name": "20260414-404-1200",
                            "status": "export_exists",
                            "variantId": "1200",
                            "expectedArtifacts": [
                                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/1064-23227-404-page-1200/screenshot.png"
                            ]
                      },
                      {
                            "name": "20260414-404-992",
                            "status": "export_exists",
                            "variantId": "992",
                            "expectedArtifacts": [
                                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/1064-23394-404-page-992/screenshot.png"
                            ]
                      },
                      {
                            "name": "20260414-404-768",
                            "status": "export_exists",
                            "variantId": "768",
                            "expectedArtifacts": [
                                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/1064-23542-404-page-768/screenshot.png"
                            ]
                      },
                      {
                            "name": "20260414-404-576",
                            "status": "export_exists",
                            "variantId": "576",
                            "expectedArtifacts": [
                                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/1064-23692-404-page-576/screenshot.png"
                            ]
                      }
                ]
          },
          {
                "id": "cheap-psychic",
                "label": "Cheap Psychic",
                "pageSrc": "_unzipped/cheap-psychic-new.html",
                "manifestTitle": "Cheap Psychic - Neuro",
                "jobs": [
                      {
                            "name": "20260414-cheap-psychic-1200",
                            "status": "export_exists",
                            "variantId": "1200",
                            "expectedArtifacts": [
                                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/917-17364-cheap-psychic-new-1200/screenshot.png"
                            ]
                      },
                      {
                            "name": "20260414-cheap-psychic-992",
                            "status": "export_exists",
                            "variantId": "992",
                            "expectedArtifacts": [
                                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/917-17603-cheap-psychic-new-992/screenshot.png"
                            ]
                      },
                      {
                            "name": "20260414-cheap-psychic-768",
                            "status": "export_exists",
                            "variantId": "768",
                            "expectedArtifacts": [
                                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/917-17846-cheap-psychic-new-768/screenshot.png"
                            ]
                      },
                      {
                            "name": "20260414-cheap-psychic-576",
                            "status": "export_exists",
                            "variantId": "576",
                            "expectedArtifacts": [
                                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/917-18089-cheap-psychic-new-576/screenshot.png"
                            ]
                      },
                      {
                            "name": "20260414-cheap-psychic-320",
                            "status": "export_exists",
                            "variantId": "320",
                            "expectedArtifacts": [
                                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/917-18327-cheap-psychic-new-320/screenshot.png"
                            ]
                      }
                ]
          },
          {
                "id": "faq",
                "label": "FAQ",
                "pageSrc": "_unzipped/faq-new.html",
                "manifestTitle": "FAQ - Neuro",
                "jobs": [
                      {
                            "name": "20260414-faq-1200",
                            "status": "export_exists",
                            "variantId": "1200",
                            "expectedArtifacts": [
                                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/866-7108-faq-new-1200/screenshot.png"
                            ]
                      },
                      {
                            "name": "20260414-faq-992",
                            "status": "export_exists",
                            "variantId": "992",
                            "expectedArtifacts": [
                                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/866-7511-faq-new-992/screenshot.png"
                            ]
                      },
                      {
                            "name": "20260414-faq-768",
                            "status": "export_exists",
                            "variantId": "768",
                            "expectedArtifacts": [
                                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/868-7221-faq-new-768/screenshot.png"
                            ]
                      },
                      {
                            "name": "20260414-faq-576",
                            "status": "export_exists",
                            "variantId": "576",
                            "expectedArtifacts": [
                                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/868-7775-faq-new-576/screenshot.png"
                            ]
                      },
                      {
                            "name": "20260414-faq-320",
                            "status": "export_exists",
                            "variantId": "320",
                            "expectedArtifacts": [
                                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/868-8218-faq-new-320/screenshot.png"
                            ]
                      }
                ]
          },
          {
                "id": "home",
                "label": "Home",
                "pageSrc": "_unzipped/home.html",
                "manifestTitle": "Home - Neuro",
                "jobs": [],
                "blockedReason": "Current 20260414 API Figma source export is missing for Home. Do not repair by guessing from legacy screenshots; run Figma intake/export first."
          },
          {
                "id": "love-reading",
                "label": "Love Reading",
                "pageSrc": "_unzipped/love-reading-new.html",
                "manifestTitle": "Love Reading - Neuro",
                "jobs": [
                      {
                            "name": "20260414-love-reading-1200",
                            "status": "export_exists",
                            "variantId": "1200",
                            "expectedArtifacts": [
                                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/917-20802-love-readingc-new-1200/screenshot.png"
                            ]
                      },
                      {
                            "name": "20260414-love-reading-992",
                            "status": "export_exists",
                            "variantId": "992",
                            "expectedArtifacts": [
                                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/917-21037-love-reading-new-992/screenshot.png"
                            ]
                      },
                      {
                            "name": "20260414-love-reading-768",
                            "status": "export_exists",
                            "variantId": "768",
                            "expectedArtifacts": [
                                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/917-21277-love-reading-new-768/screenshot.png"
                            ]
                      },
                      {
                            "name": "20260414-love-reading-576",
                            "status": "export_exists",
                            "variantId": "576",
                            "expectedArtifacts": [
                                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/917-21517-love-reading-new-576/screenshot.png"
                            ]
                      },
                      {
                            "name": "20260414-love-reading-320",
                            "status": "export_exists",
                            "variantId": "320",
                            "expectedArtifacts": [
                                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/917-21752-love-reading-new-320/screenshot.png"
                            ]
                      }
                ]
          },
          {
                "id": "palm-reading",
                "label": "Palm Reading",
                "pageSrc": "_unzipped/palm-reading-new.html",
                "manifestTitle": "Palm Reading - Neuro",
                "jobs": [
                      {
                            "name": "20260414-palm-reading-1200",
                            "status": "export_exists",
                            "variantId": "1200",
                            "expectedArtifacts": [
                                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/910-20010-palm-reading-new-1200/screenshot.png"
                            ]
                      },
                      {
                            "name": "20260414-palm-reading-992",
                            "status": "export_exists",
                            "variantId": "992",
                            "expectedArtifacts": [
                                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/910-20217-palm-reading-new-992/screenshot.png"
                            ]
                      },
                      {
                            "name": "20260414-palm-reading-768",
                            "status": "export_exists",
                            "variantId": "768",
                            "expectedArtifacts": [
                                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/910-19799-palm-reading-new-768/screenshot.png"
                            ]
                      },
                      {
                            "name": "20260414-palm-reading-576",
                            "status": "export_exists",
                            "variantId": "576",
                            "expectedArtifacts": [
                                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/910-20428-palm-reading-new-576/screenshot.png"
                            ]
                      },
                      {
                            "name": "20260414-palm-reading-320",
                            "status": "export_exists",
                            "variantId": "320",
                            "expectedArtifacts": [
                                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/910-20635-palm-reading-new-320/screenshot.png"
                            ]
                      }
                ]
          },
          {
                "id": "phone-psychic",
                "label": "Phone Psychic",
                "pageSrc": "_unzipped/phone-psychic-new.html",
                "manifestTitle": "Phone Psychic - Neuro",
                "jobs": [
                      {
                            "name": "20260414-phone-psychic-1200",
                            "status": "export_exists",
                            "variantId": "1200",
                            "expectedArtifacts": [
                                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/912-12253-phone-psychic-new-1200/screenshot.png"
                            ]
                      },
                      {
                            "name": "20260414-phone-psychic-992",
                            "status": "export_exists",
                            "variantId": "992",
                            "expectedArtifacts": [
                                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/912-12444-phone-psychic-new-992/screenshot.png"
                            ]
                      },
                      {
                            "name": "20260414-phone-psychic-768",
                            "status": "export_exists",
                            "variantId": "768",
                            "expectedArtifacts": [
                                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/912-12639-phone-psychic-new-768/screenshot.png"
                            ]
                      },
                      {
                            "name": "20260414-phone-psychic-576",
                            "status": "export_exists",
                            "variantId": "576",
                            "expectedArtifacts": [
                                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/912-12837-phone-psychic-new-576/screenshot.png"
                            ]
                      },
                      {
                            "name": "20260414-phone-psychic-320",
                            "status": "export_exists",
                            "variantId": "320",
                            "expectedArtifacts": [
                                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/912-13030-phone-psychic-new-320/screenshot.png"
                            ]
                      }
                ]
          },
          {
                "id": "psychic-reading",
                "label": "Psychic Reading",
                "pageSrc": "_unzipped/psychic-reading-new.html",
                "manifestTitle": "Psychic Reading - Neuro",
                "jobs": [
                      {
                            "name": "20260414-psychic-reading-1200",
                            "status": "export_exists",
                            "variantId": "1200",
                            "expectedArtifacts": [
                                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/413-3566-psychic-reading-new-1200/screenshot.png"
                            ]
                      },
                      {
                            "name": "20260414-psychic-reading-992",
                            "status": "export_exists",
                            "variantId": "992",
                            "expectedArtifacts": [
                                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/874-8758-psychic-reading-new-992/screenshot.png"
                            ]
                      },
                      {
                            "name": "20260414-psychic-reading-768",
                            "status": "export_exists",
                            "variantId": "768",
                            "expectedArtifacts": [
                                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/874-10483-psychic-reading-new-768/screenshot.png"
                            ]
                      },
                      {
                            "name": "20260414-psychic-reading-576",
                            "status": "export_exists",
                            "variantId": "576",
                            "expectedArtifacts": [
                                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/881-12511-psychic-reading-new-576/screenshot.png"
                            ]
                      },
                      {
                            "name": "20260414-psychic-reading-320",
                            "status": "export_exists",
                            "variantId": "320",
                            "expectedArtifacts": [
                                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/883-13989-psychic-reading-new-320/screenshot.png"
                            ]
                      }
                ]
          },
          {
                "id": "blog",
                "label": "Blog",
                "pageSrc": "_unzipped/blog-new.html",
                "manifestTitle": "Blog - Neuro",
                "jobs": [
                      {
                            "name": "20260414-blog-1200",
                            "status": "export_exists",
                            "variantId": "1200",
                            "expectedArtifacts": [
                                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/642-5788-blog-1200/screenshot.png"
                            ]
                      },
                      {
                            "name": "20260414-blog-992",
                            "status": "export_exists",
                            "variantId": "992",
                            "expectedArtifacts": [
                                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/1001-20800-blog-992/screenshot.png"
                            ]
                      },
                      {
                            "name": "20260414-blog-768",
                            "status": "export_exists",
                            "variantId": "768",
                            "expectedArtifacts": [
                                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/1002-21942-blog-768/screenshot.png"
                            ]
                      },
                      {
                            "name": "20260414-blog-576",
                            "status": "export_exists",
                            "variantId": "576",
                            "expectedArtifacts": [
                                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/1002-23955-blog-576/screenshot.png"
                            ]
                      },
                      {
                            "name": "20260414-blog-320",
                            "status": "export_exists",
                            "variantId": "320",
                            "expectedArtifacts": [
                                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/1005-22168-blog-320/screenshot.png"
                            ]
                      }
                ]
          },
          {
                "id": "blog-input",
                "label": "Blog Input",
                "pageSrc": "_unzipped/blog-input-new.html",
                "manifestTitle": "Blog Input - Neuro",
                "jobs": [
                      {
                            "name": "20260414-blog-input-1200",
                            "status": "export_exists",
                            "variantId": "1200",
                            "expectedArtifacts": [
                                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/643-7448-blog-input-1200/screenshot.png"
                            ]
                      },
                      {
                            "name": "20260414-blog-input-992",
                            "status": "export_exists",
                            "variantId": "992",
                            "expectedArtifacts": [
                                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/1006-23266-blog-input-992/screenshot.png"
                            ]
                      },
                      {
                            "name": "20260414-blog-input-768",
                            "status": "export_exists",
                            "variantId": "768",
                            "expectedArtifacts": [
                                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/1006-25391-blog-input-768/screenshot.png"
                            ]
                      },
                      {
                            "name": "20260414-blog-input-576",
                            "status": "export_exists",
                            "variantId": "576",
                            "expectedArtifacts": [
                                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/1008-22880-blog-input-576/screenshot.png"
                            ]
                      },
                      {
                            "name": "20260414-blog-input-320",
                            "status": "export_exists",
                            "variantId": "320",
                            "expectedArtifacts": [
                                  "figma-export/api/20260414-232048-ayfBFNukkQC05XmCVsJB6f/figma-screens/1008-23368-blog-input-320/screenshot.png"
                            ]
                      }
                ]
          }
    ];
    const NEBULA_ONBOARDED_ETHALON_ROUTE_PAGES = [
          {
                "pageId": "all-psychic",
                "variants": [
                      "1200",
                      "992",
                      "768",
                      "576",
                      "320"
                ]
          },
          {
                "pageId": "404",
                "variants": [
                      "1200",
                      "992",
                      "768",
                      "576"
                ]
          },
          {
                "pageId": "cheap-psychic",
                "variants": [
                      "1200",
                      "992",
                      "768",
                      "576",
                      "320"
                ]
          },
          {
                "pageId": "faq",
                "variants": [
                      "1200",
                      "992",
                      "768",
                      "576",
                      "320"
                ]
          },
          {
                "pageId": "love-reading",
                "variants": [
                      "1200",
                      "992",
                      "768",
                      "576",
                      "320"
                ]
          },
          {
                "pageId": "palm-reading",
                "variants": [
                      "1200",
                      "992",
                      "768",
                      "576",
                      "320"
                ]
          },
          {
                "pageId": "phone-psychic",
                "variants": [
                      "1200",
                      "992",
                      "768",
                      "576",
                      "320"
                ]
          },
          {
                "pageId": "psychic-reading",
                "variants": [
                      "1200",
                      "992",
                      "768",
                      "576",
                      "320"
                ]
          },
          {
                "pageId": "blog",
                "variants": [
                      "1200",
                      "992",
                      "768",
                      "576",
                      "320"
                ]
          },
          {
                "pageId": "blog-input",
                "variants": [
                      "1200",
                      "992",
                      "768",
                      "576",
                      "320"
                ]
          }
    ];
    (() => {
      const onboardedPageIds = new Set([
          "all-psychic",
          "404",
          "cheap-psychic",
          "faq",
          "home",
          "love-reading",
          "palm-reading",
          "phone-psychic",
          "psychic-reading",
          "blog",
          "blog-input"
    ]);
      const routeFamily = REVIEW_ROUTE_FAMILIES.find((family) => family.id === "ethalon-page");
      if (routeFamily) {
        routeFamily.pages = [
          ...routeFamily.pages.filter((page) => !onboardedPageIds.has(page.pageId)),
          ...NEBULA_ONBOARDED_ETHALON_ROUTE_PAGES
        ];
      }
      const boardFamily = FAMILIES.find((family) => family.id === "ethalon-page");
      if (boardFamily) {
        boardFamily.pages = [
          ...boardFamily.pages.filter((page) => !onboardedPageIds.has(page.id)),
          ...NEBULA_ONBOARDED_ETHALON_PAGES
        ];
      }
    })();
    // ORACLE_ONBOARDED_ETHALON_PAGES_END

    const state = {
      familyId: FAMILIES[0].id,
      pageId: FAMILIES[0].pages[0].id,
      variantId: "1200",
      modeId: "page",
      screenId: "full-page",
      lensId: "split",
      overlayTopLayerId: "implementation",
      overlayOpacity: 55,
      overlaySplit: 50,
      pixelAuditMode: false,
      guideGrid: true,
      guideIndex: false,
      guideSafeArea: true,
      guideAnchors: true,
      guideColumns: 12,
      guideBaseline: 8,
      issueMode: false,
      issueRegion: null,
      issueRegions: [],
      issueActiveIndex: -1,
      macroGateMode: false,
      macroBrush: "attention",
      auditMode: false,
      auditBrush: "attention",
      auditScope: "cells",
      auditLayerId: "surface",
      auditFamilyId: "",
      auditRowId: ""
    };

    let sourceContractPromise = null;
    let sourceLocatorPromise = null;
    let sourceLocatorData = null;
    let screenSpecIndexPromise = null;
    let familyRegistryPromise = null;
    let familyRegistryData = null;
    let ethalonPackPromise = null;
    let ethalonPack = null;
    const screenCatalog = new Map();
    let boardRenderCache = null;
    let currentScanDocument = null;
    let currentLensMetrics = null;
    let issueDraft = null;
    let lastIssueCheckResult = null;
    let currentLensCursor = null;
    const AUDIT_STORAGE_KEY = "nebula-compare-board-audit-v1";
    const AUDIT_LOCK_STORAGE_KEY = "nebula-compare-board-audit-locks-v1";
    const AUDIT_METRICS_STORAGE_KEY = "nebula-compare-board-audit-metrics-v1";
    const MACRO_GATE_STORAGE_KEY = "nebula-compare-board-macro-gate-v1";
    const AUDIT_LAYER_ORDER = ["surface", "shell", "identity", "asset", "type", "micro"];
    const AUDIT_LAYER_META = {
      surface: { id: "surface", label: "Surface", help: "Фон, подложка, общая плоскость и крупные визуальные заливки." },
      shell: { id: "shell", label: "Shell", help: "Габариты секции, сетка, отступы, высота и стыки соседних экранов." },
      identity: { id: "identity", label: "Identity", help: "Смысловой состав: нужная секция, нужные элементы, правильная иерархия." },
      asset: { id: "asset", label: "Asset", help: "Иконки, фото, BG, экспортированные Figma-ассеты и их размеры." },
      type: { id: "type", label: "Type", help: "Шрифт, размер, line-height, weight, цвет, переносы и выделяемость текста." },
      micro: { id: "micro", label: "Micro", help: "Точечные пиксельные хвосты после закрытия крупных слоёв." }
    };
    const MACRO_GATE_CHECKS = [
      { id: "screen_shell", label: "Screen shell", help: "Проверь общую высоту, контейнер, стыки экранов и крупную сетку." },
      { id: "screen_surface", label: "Surface", help: "Проверь BG/подложку, градиенты и общую плоскость секции." },
      { id: "header_line", label: "Header line", help: "Проверь линию шапки: логотип, меню, sign up и высоту." },
      { id: "hero_title_pack", label: "Hero title pack", help: "Проверь заголовок, подзаголовок, поиск/чипы и их базовые линии." },
      { id: "hero_media_top", label: "Hero media top", help: "Проверь группу фото/медиа, верхнюю привязку и масштаб." },
      { id: "accent_baseline", label: "Accent baseline", help: "Проверь ключевые акцентные линии: CTA, цифры, стрелки, иконки." },
      { id: "next_seam", label: "Next seam", help: "Проверь нижний стык секции и расстояние до следующего экрана." }
    ];
    let auditStore = loadAuditStore();
    let auditLockStore = loadAuditLockStore();
    let auditMetricsStore = loadAuditMetricsStore();
    let macroGateStore = loadMacroGateStore();
    let auditDraft = null;

    const nodes = {
      familyChips: document.getElementById("familyChips"),
      pageChips: document.getElementById("pageChips"),
      variantChips: document.getElementById("variantChips"),
      modeChips: document.getElementById("modeChips"),
      lensChips: document.getElementById("lensChips"),
      screenChips: document.getElementById("screenChips"),
      prevScreenBtn: document.getElementById("prevScreenBtn"),
      nextScreenBtn: document.getElementById("nextScreenBtn"),
      copyLinkBtn: document.getElementById("copyLinkBtn"),
      screenSummary: document.getElementById("screenSummary"),
      overlayLayerChips: document.getElementById("overlayLayerChips"),
      overlayOpacity: document.getElementById("overlayOpacity"),
      overlaySplit: document.getElementById("overlaySplit"),
      overlaySummary: document.getElementById("overlaySummary"),
      guideGrid: document.getElementById("guideGrid"),
      guideIndex: document.getElementById("guideIndex"),
      guideSafeArea: document.getElementById("guideSafeArea"),
      guideAnchors: document.getElementById("guideAnchors"),
      guideColumns: document.getElementById("guideColumns"),
      guideBaseline: document.getElementById("guideBaseline"),
      guideSummary: document.getElementById("guideSummary"),
      pixelAuditMode: document.getElementById("pixelAuditMode"),
      pixelAuditSummary: document.getElementById("pixelAuditSummary"),
      issueMode: document.getElementById("issueMode"),
      runIssueCheckBtn: document.getElementById("runIssueCheckBtn"),
      copyIssueBtn: document.getElementById("copyIssueBtn"),
      downloadIssueBtn: document.getElementById("downloadIssueBtn"),
      removeIssueBtn: document.getElementById("removeIssueBtn"),
      clearIssueBtn: document.getElementById("clearIssueBtn"),
      issueSummary: document.getElementById("issueSummary"),
      issueResultPanel: document.getElementById("issueResultPanel"),
      macroGateMode: document.getElementById("macroGateMode"),
      macroBrushes: document.getElementById("macroBrushes"),
      macroGateChecks: document.getElementById("macroGateChecks"),
      copyMacroGateBtn: document.getElementById("copyMacroGateBtn"),
      clearMacroGateBtn: document.getElementById("clearMacroGateBtn"),
      macroGateSummary: document.getElementById("macroGateSummary"),
      auditMode: document.getElementById("auditMode"),
      auditScopeChips: document.getElementById("auditScopeChips"),
      auditLayerChips: document.getElementById("auditLayerChips"),
      auditBrushes: document.getElementById("auditBrushes"),
      auditFamilyChips: document.getElementById("auditFamilyChips"),
      copyAuditBtn: document.getElementById("copyAuditBtn"),
      copyAuditRouteBtn: document.getElementById("copyAuditRouteBtn"),
      copyAuditHandoffBtn: document.getElementById("copyAuditHandoffBtn"),
      lockAuditTargetBtn: document.getElementById("lockAuditTargetBtn"),
      copyLockGateBtn: document.getElementById("copyLockGateBtn"),
      copyLockFileBtn: document.getElementById("copyLockFileBtn"),
      clearAuditLockBtn: document.getElementById("clearAuditLockBtn"),
      copyMetricsBtn: document.getElementById("copyMetricsBtn"),
      clearAuditBtn: document.getElementById("clearAuditBtn"),
      auditSummary: document.getElementById("auditSummary"),
      auditRoutingSummary: document.getElementById("auditRoutingSummary"),
      auditMetricsSummary: document.getElementById("auditMetricsSummary"),
      screenRow: document.getElementById("screenRow"),
      lensControlsRow: document.getElementById("lensControlsRow"),
      focusTitle: document.getElementById("focusTitle"),
      focusText: document.getElementById("focusText"),
      focusPills: document.getElementById("focusPills"),
      deepLinkField: document.getElementById("deepLinkField"),
      linkMatrix: document.getElementById("linkMatrix"),
      reviewRouteGroups: document.getElementById("reviewRouteGroups"),
      reviewStage: document.getElementById("reviewStage"),
      referenceViewport: document.getElementById("referenceViewport"),
      implementationViewport: document.getElementById("implementationViewport"),
      compareLensViewport: document.getElementById("compareLensViewport"),
      referenceMeta: document.getElementById("referenceMeta"),
      implementationMeta: document.getElementById("implementationMeta"),
      compareLensMeta: document.getElementById("compareLensMeta"),
      referenceFoot: document.getElementById("referenceFoot"),
      implementationFoot: document.getElementById("implementationFoot"),
      compareLensFoot: document.getElementById("compareLensFoot"),
      referenceTag: document.getElementById("referenceTag"),
      implementationTag: document.getElementById("implementationTag"),
      compareLensTag: document.getElementById("compareLensTag"),
      referenceInventorySummary: document.getElementById("referenceInventorySummary"),
      referenceInventoryGrid: document.getElementById("referenceInventoryGrid"),
      ethalonPackSummary: document.getElementById("ethalonPackSummary"),
      ethalonPackGrid: document.getElementById("ethalonPackGrid"),
      scanDocSummary: document.getElementById("scanDocSummary"),
      scanDocGrid: document.getElementById("scanDocGrid"),
      scanDocContractText: document.getElementById("scanDocContractText"),
      copyScanDocBtn: document.getElementById("copyScanDocBtn"),
      downloadScanDocBtn: document.getElementById("downloadScanDocBtn")
    };

    function escapeHtml(value) {
      return String(value)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll("\"", "&quot;");
    }

    function loadAuditStore() {
      try {
        const raw = window.localStorage.getItem(AUDIT_STORAGE_KEY);
        if (!raw) {
          return {};
        }
        const parsed = JSON.parse(raw);
        return parsed && typeof parsed === "object" ? parsed : {};
      } catch {
        return {};
      }
    }

    function saveAuditStore() {
      try {
        window.localStorage.setItem(AUDIT_STORAGE_KEY, JSON.stringify(auditStore));
      } catch (error) {
        console.warn("audit store save failed", error);
      }
    }

    function loadAuditLockStore() {
      try {
        const raw = window.localStorage.getItem(AUDIT_LOCK_STORAGE_KEY);
        if (!raw) {
          return {};
        }
        const parsed = JSON.parse(raw);
        return parsed && typeof parsed === "object" ? parsed : {};
      } catch {
        return {};
      }
    }

    function saveAuditLockStore() {
      try {
        window.localStorage.setItem(AUDIT_LOCK_STORAGE_KEY, JSON.stringify(auditLockStore));
      } catch (error) {
        console.warn("audit lock store save failed", error);
      }
    }

    function loadAuditMetricsStore() {
      try {
        const raw = window.localStorage.getItem(AUDIT_METRICS_STORAGE_KEY);
        if (!raw) {
          return {};
        }
        const parsed = JSON.parse(raw);
        return parsed && typeof parsed === "object" ? parsed : {};
      } catch {
        return {};
      }
    }

    function saveAuditMetricsStore() {
      try {
        window.localStorage.setItem(AUDIT_METRICS_STORAGE_KEY, JSON.stringify(auditMetricsStore));
      } catch (error) {
        console.warn("audit metrics store save failed", error);
      }
    }

    function loadMacroGateStore() {
      try {
        const raw = window.localStorage.getItem(MACRO_GATE_STORAGE_KEY);
        if (!raw) {
          return {};
        }
        const parsed = JSON.parse(raw);
        return parsed && typeof parsed === "object" ? parsed : {};
      } catch {
        return {};
      }
    }

    function saveMacroGateStore() {
      try {
        window.localStorage.setItem(MACRO_GATE_STORAGE_KEY, JSON.stringify(macroGateStore));
      } catch (error) {
        console.warn("macro gate store save failed", error);
      }
    }

    function isAuditStatusValue(value) {
      return value === "pass" || value === "in_progress" || value === "attention";
    }

    function currentAuditLayerMeta(layerId = state.auditLayerId) {
      return AUDIT_LAYER_META[layerId] || AUDIT_LAYER_META.surface;
    }

    function normalizeAuditLayerRecord(record) {
      if (isAuditStatusValue(record)) {
        return { legacy: record };
      }
      return record && typeof record === "object" ? { ...record } : null;
    }

    function getStoredAuditLayerStatus(record, layerId = state.auditLayerId) {
      if (isAuditStatusValue(record)) {
        return record;
      }
      const normalized = normalizeAuditLayerRecord(record);
      if (!normalized) {
        return null;
      }
      if (isAuditStatusValue(normalized[layerId])) {
        return normalized[layerId];
      }
      if (isAuditStatusValue(normalized.legacy)) {
        return normalized.legacy;
      }
      return null;
    }

    function getAuditLayerStatus(record, layerId = state.auditLayerId, fallback = "attention") {
      return getStoredAuditLayerStatus(record, layerId) || fallback;
    }

    function setAuditLayerStatus(container, key, status, layerId = state.auditLayerId) {
      if (!container || !key) {
        return;
      }
      const existing = container[key];
      if (!status || status === "clear") {
        if (isAuditStatusValue(existing)) {
          delete container[key];
          return;
        }
        const normalized = normalizeAuditLayerRecord(existing);
        if (!normalized) {
          return;
        }
        delete normalized[layerId];
        const remainingKeys = Object.keys(normalized).filter((item) => isAuditStatusValue(normalized[item]));
        if (!remainingKeys.length) {
          delete container[key];
        } else {
          container[key] = normalized;
        }
        return;
      }
      const normalized = normalizeAuditLayerRecord(existing) || {};
      normalized[layerId] = status;
      container[key] = normalized;
    }

    function currentAuditKey() {
      return [
        state.familyId,
        state.pageId,
        state.variantId,
        state.modeId,
        state.screenId,
        `c${state.guideColumns}`,
        `b${state.guideBaseline}`
      ].join("|");
    }

    function currentAuditLockScopeKey() {
      return [
        state.familyId,
        state.pageId,
        state.variantId,
        state.modeId,
        state.screenId
      ].join("|");
    }

    function currentAuditMetricsScopeKey() {
      return currentAuditLockScopeKey();
    }

    function currentMacroGateKey() {
      return [
        state.familyId,
        state.pageId,
        state.variantId,
        state.modeId,
        state.screenId
      ].join("|");
    }

    function ensureMacroGateEntry() {
      const key = currentMacroGateKey();
      if (!macroGateStore[key] || typeof macroGateStore[key] !== "object") {
        macroGateStore[key] = {
          family: state.familyId,
          page: state.pageId,
          variant: state.variantId,
          mode: state.modeId,
          screen: state.screenId,
          checks: {}
        };
      }
      return macroGateStore[key];
    }

    function currentMacroGateEntry() {
      return macroGateStore[currentMacroGateKey()] || null;
    }

    function currentMacroGateStatus(checkId) {
      const status = currentMacroGateEntry()?.checks?.[checkId];
      return isAuditStatusValue(status) ? status : null;
    }

    function setMacroGateStatus(checkId, status) {
      if (!checkId) {
        return;
      }
      const entry = ensureMacroGateEntry();
      if (!status || status === "clear") {
        delete entry.checks[checkId];
      } else {
        entry.checks[checkId] = status;
      }
      if (!Object.keys(entry.checks).length) {
        delete macroGateStore[currentMacroGateKey()];
      }
      saveMacroGateStore();
    }

    function clearCurrentMacroGate() {
      delete macroGateStore[currentMacroGateKey()];
      saveMacroGateStore();
    }

    function summarizeMacroGate(entry = currentMacroGateEntry()) {
      const summary = {
        total: MACRO_GATE_CHECKS.length,
        pass: 0,
        in_progress: 0,
        attention: 0,
        missing: 0,
        blocked: true,
        verdict: "blocked",
        blockers: []
      };
      MACRO_GATE_CHECKS.forEach((check) => {
        const status = entry?.checks?.[check.id];
        if (isAuditStatusValue(status)) {
          summary[status] += 1;
          if (status !== "pass") {
            summary.blockers.push(check.label);
          }
        } else {
          summary.missing += 1;
          summary.blockers.push(check.label);
        }
      });
      if (!summary.missing && !summary.in_progress && !summary.attention && summary.pass === summary.total) {
        summary.blocked = false;
        summary.verdict = "ready";
      }
      return summary;
    }

    function macroGateAllowsDeepAudit() {
      return !summarizeMacroGate().blocked;
    }

    function serializeMacroGate(entry = currentMacroGateEntry()) {
      if (!entry) {
        return null;
      }
      return {
        family: entry.family,
        page: entry.page,
        variant: entry.variant,
        mode: entry.mode,
        screen: entry.screen,
        checks: entry.checks,
        summary: summarizeMacroGate(entry),
        link: currentDeepLink()
      };
    }

    function ensureAuditMetricsScopeEntry() {
      const key = currentAuditMetricsScopeKey();
      if (!auditMetricsStore[key] || typeof auditMetricsStore[key] !== "object") {
        auditMetricsStore[key] = {
          family: state.familyId,
          page: state.pageId,
          variant: state.variantId,
          mode: state.modeId,
          screen: state.screenId,
          passesByFamily: {},
          wrongLayerEntries: {
            attempts: 0,
            blocked: 0
          },
          regressionsByLock: {},
          contourTrials: {}
        };
      }
      return auditMetricsStore[key];
    }

    function currentAuditMetricsScopeEntry() {
      return auditMetricsStore[currentAuditMetricsScopeKey()] || null;
    }

    function ensureCountMapValue(container, key) {
      if (!container[key] || typeof container[key] !== "object") {
        container[key] = { pass: 0, fail: 0, regressions: 0 };
      }
      return container[key];
    }

    function ensureAuditLockScopeEntry() {
      const key = currentAuditLockScopeKey();
      if (!auditLockStore[key] || typeof auditLockStore[key] !== "object") {
        auditLockStore[key] = {
          family: state.familyId,
          page: state.pageId,
          variant: state.variantId,
          mode: state.modeId,
          screen: state.screenId,
          targets: {}
        };
      }
      return auditLockStore[key];
    }

    function currentAuditLockScopeEntry() {
      return auditLockStore[currentAuditLockScopeKey()] || null;
    }

    function ensureAuditEntry() {
      const key = currentAuditKey();
      if (!auditStore[key] || typeof auditStore[key] !== "object") {
        auditStore[key] = {
          family: state.familyId,
          page: state.pageId,
          variant: state.variantId,
          mode: state.modeId,
          screen: state.screenId,
          columns: state.guideColumns,
          baseline: state.guideBaseline,
          rowStride: Math.max(state.guideBaseline * 4, 16),
          cells: {},
          families: {},
          rows: {}
        };
      }
      return auditStore[key];
    }

    function currentAuditEntry() {
      return auditStore[currentAuditKey()] || null;
    }

    function currentAuditCells(layerId = state.auditLayerId) {
      const cells = currentAuditEntry()?.cells || {};
      return Object.fromEntries(
        Object.entries(cells)
          .map(([key, value]) => [key, getStoredAuditLayerStatus(value, layerId)])
          .filter(([, value]) => isAuditStatusValue(value))
      );
    }

    function auditRowStride() {
      return Math.max(state.guideBaseline * 4, 16);
    }

    function formatAuditCellId(colIndex, rowIndex) {
      return `${formatGuideColumnId(colIndex)}-${formatGuideRowId(rowIndex)}`;
    }

    function getAuditCounts(entry = currentAuditEntry(), layerId = state.auditLayerId) {
      const counts = {
        pass: 0,
        in_progress: 0,
        attention: 0
      };
      Object.values(entry?.cells || {}).forEach((value) => {
        const status = getStoredAuditLayerStatus(value, layerId);
        if (isAuditStatusValue(status)) {
          counts[status] += 1;
        }
      });
      return counts;
    }

    function serializeAudit(entry = currentAuditEntry()) {
      if (!entry) {
        return null;
      }
      return {
        family: entry.family,
        page: entry.page,
        variant: entry.variant,
        mode: entry.mode,
        screen: entry.screen,
        columns: entry.columns,
        baseline: entry.baseline,
        rowStride: entry.rowStride,
        selectedLayerId: state.auditLayerId,
        selectedLayerLabel: currentAuditLayerMeta().label,
        counts: getAuditCounts(entry, state.auditLayerId),
        familyCounts: getAuditFamilyCounts(entry, state.auditLayerId),
        rowCounts: getAuditRowCounts(entry, state.auditLayerId),
        cells: entry.cells,
        families: entry.families || {},
        rows: entry.rows || {},
        scope: state.auditScope,
        layer: state.auditLayerId,
        selectedFamilyId: state.auditFamilyId,
        selectedRowId: state.auditRowId,
        link: currentDeepLink()
      };
    }

    function syncAuditCell(colIndex, rowIndex, status) {
      const entry = ensureAuditEntry();
      entry.columns = state.guideColumns;
      entry.baseline = state.guideBaseline;
      entry.rowStride = auditRowStride();
      const key = `${colIndex}:${rowIndex}`;
      setAuditLayerStatus(entry.cells, key, status);
      saveAuditStore();
      recordAuditTargetStatus("cells", state.auditFamilyId || "", state.auditRowId || "", state.auditLayerId, status);
    }

    function getAuditFamilyCounts(entry = currentAuditEntry(), layerId = state.auditLayerId) {
      const counts = {
        pass: 0,
        in_progress: 0,
        attention: 0
      };
      Object.values(entry?.families || {}).forEach((value) => {
        const status = getStoredAuditLayerStatus(value, layerId);
        if (isAuditStatusValue(status)) {
          counts[status] += 1;
        }
      });
      return counts;
    }

    function getAuditRowCounts(entry = currentAuditEntry(), layerId = state.auditLayerId) {
      const counts = {
        pass: 0,
        in_progress: 0,
        attention: 0
      };
      Object.values(entry?.rows || {}).forEach((familyRows) => {
        Object.values(familyRows || {}).forEach((value) => {
          const status = getStoredAuditLayerStatus(value, layerId);
          if (isAuditStatusValue(status)) {
            counts[status] += 1;
          }
        });
      });
      return counts;
    }

    function syncAuditFamilyStatus(familyId, status) {
      if (!familyId) {
        return;
      }
      const entry = ensureAuditEntry();
      entry.families = entry.families || {};
      setAuditLayerStatus(entry.families, familyId, status);
      saveAuditStore();
      recordAuditTargetStatus("families", familyId, "", state.auditLayerId, status);
    }

    function syncAuditRowStatus(familyId, rowId, status) {
      if (!familyId || !rowId) {
        return;
      }
      const entry = ensureAuditEntry();
      entry.rows = entry.rows || {};
      entry.rows[familyId] = entry.rows[familyId] || {};
      setAuditLayerStatus(entry.rows[familyId], rowId, status);
      if (!Object.keys(entry.rows[familyId]).length) {
        delete entry.rows[familyId];
      }
      saveAuditStore();
      recordAuditTargetStatus("rows", familyId, rowId, state.auditLayerId, status);
    }

    function currentAuditFamilyStatus(familyId) {
      return getAuditLayerStatus(currentAuditEntry()?.families?.[familyId], state.auditLayerId, "attention");
    }

    function currentAuditRowStatus(familyId, rowId) {
      return getAuditLayerStatus(currentAuditEntry()?.rows?.[familyId]?.[rowId], state.auditLayerId, "attention");
    }

    function setPaneTag(node, text, state = "neutral") {
      if (!node) {
        return;
      }
      node.textContent = text;
      node.classList.remove("pane__tag--good", "pane__tag--warn", "pane__tag--danger");
      if (state === "good") {
        node.classList.add("pane__tag--good");
      } else if (state === "warn") {
        node.classList.add("pane__tag--warn");
      } else if (state === "danger") {
        node.classList.add("pane__tag--danger");
      }
    }

    const LIVE_CACHE_BUST = Date.now().toString();

    function resolveUrl(path) {
      return new URL(path, window.location.href).href;
    }

    function resolveLiveUrl(path) {
      const url = new URL(path, window.location.href);
      url.searchParams.set("v", LIVE_CACHE_BUST);
      return url.href;
    }

    function formatBytes(value) {
      const bytes = Number(value || 0);
      if (!Number.isFinite(bytes) || bytes <= 0) return "0 B";
      const units = ["B", "KB", "MB", "GB"];
      let size = bytes;
      let unitIndex = 0;
      while (size >= 1024 && unitIndex < units.length - 1) {
        size /= 1024;
        unitIndex += 1;
      }
      return `${size.toFixed(unitIndex === 0 ? 0 : 1)} ${units[unitIndex]}`;
    }

    function mergeEthalonFamilies(pack) {
      const families = Array.isArray(pack?.board_families) ? pack.board_families : [];
      families.forEach((family) => {
        if (!family || !family.id || !Array.isArray(family.pages)) return;
        const normalized = {
          id: family.id,
          label: family.label || family.id,
          text: family.text || "New Figma ethalon package lane.",
          pages: family.pages.map((page) => ({
            id: page.id,
            label: page.label || page.id,
            pageSrc: page.pageSrc,
            manifestTitle: page.manifestTitle || "",
            lane: page.lane || "",
            ethalonPack: pack.source || "",
            jobs: Array.isArray(page.jobs) ? page.jobs : []
          }))
        };
        const existingIndex = FAMILIES.findIndex((item) => item.id === normalized.id);
        if (existingIndex >= 0) {
          FAMILIES[existingIndex] = normalized;
        } else {
          FAMILIES.unshift(normalized);
        }
      });
    }

    function loadEthalonPack() {
      if (!ethalonPackPromise) {
        ethalonPackPromise = fetch(resolveUrl("figma-manifest/oracle-ethalon-pack-ayfbfnukkqc05xmcvsjb6f.json"))
          .then((response) => {
            if (!response.ok) {
              throw new Error(`ethalon pack unavailable: ${response.status}`);
            }
            return response.json();
          })
          .then((pack) => {
            ethalonPack = pack;
            mergeEthalonFamilies(pack);
            return pack;
          })
          .catch((error) => {
            console.warn(error);
            ethalonPack = null;
            return null;
          });
      }
      return ethalonPackPromise;
    }

    function findEthalonPage(pack, pageId) {
      const families = Array.isArray(pack?.board_families) ? pack.board_families : [];
      for (const family of families) {
        const page = (family.pages || []).find((item) => item.id === pageId);
        if (page) return { family, page };
      }
      return null;
    }

    function pageSourcePriority(page) {
      const status = summarizePageSourceStatus(page);
      const map = {
        "route-status is-export": 0,
        "route-status is-partial": 1,
        "route-status is-pending": 2,
        "route-status is-danger": 3,
        "route-status is-manifest": 4
      };
      return map[status.className] ?? 9;
    }

    function locatorSignalPriority(signalLevel) {
      const map = {
        current_node_export: 0,
        semantic_neighbor: 1,
        historical_cluster: 2,
        contract_only: 3
      };
      return map[String(signalLevel || "")] ?? 9;
    }

    function locatorSignalLabel(signalLevel) {
      const map = {
        current_node_export: "сигнал: текущий узел",
        semantic_neighbor: "сигнал: семантический сосед",
        historical_cluster: "сигнал: исторический кластер",
        contract_only: "сигнал: только контракт"
      };
      return map[String(signalLevel || "")] || "сигнал: неизвестно";
    }

    function buildRecoveryRouteGroup() {
      const pages = FAMILIES.flatMap((family) => (family.pages || []).map((page) => ({ family, page })));
      const items = pages
        .map(({ family, page }) => ({ family, page, locatorEntry: getLocatorEntry(sourceLocatorData || { pages: [] }, page) }))
        .filter(({ page, locatorEntry }) => !pageHasAnyRealSource(page) && locatorEntry)
        .sort((a, b) => {
          const signalDiff = locatorSignalPriority(a.locatorEntry.signal_level) - locatorSignalPriority(b.locatorEntry.signal_level);
          if (signalDiff !== 0) return signalDiff;
          const sourceDiff = pageSourcePriority(a.page) - pageSourcePriority(b.page);
          if (sourceDiff !== 0) return sourceDiff;
          return String(a.page.label || a.page.id).localeCompare(String(b.page.label || b.page.id));
        })
        .slice(0, 6)
        .map(({ family, page }) => ({
          pageId: page.id,
          variants: ["1200"],
          familyId: family.id
        }));

      if (!items.length) {
        return null;
      }

      return {
        id: "__recovery_priority__",
        label: "Приоритет восстановления",
        text: "Автоподбор следующей source-truth работы по locator signal и practical recovery value.",
        pages: items
      };
    }

    function renderEthalonPackPanel() {
      if (!nodes.ethalonPackSummary || !nodes.ethalonPackGrid) return;
      const pack = ethalonPack;
      if (!pack) {
        nodes.ethalonPackSummary.innerHTML = `<div class="notice">Каталог нового пакета эталона недоступен по пути <code>figma-manifest/oracle-ethalon-pack-ayfbfnukkqc05xmcvsjb6f.json</code>.</div>`;
        nodes.ethalonPackGrid.innerHTML = "";
        return;
      }

      const active = findEthalonPage(pack, state.pageId);
      const cards = [
        ["Файл", pack.file_name || pack.file_key || "неизвестно"],
        ["Версия", pack.figma_version_ref || "не зафиксирована"],
        ["Страницы", pack.mapped_page_total || 0],
        ["Записи", pack.reference_library_files || 0],
        ["Передача", pack.handoff_readiness?.verdict || "не собрана"],
        ["Ассеты", `${pack.handoff_readiness?.image_assets || 0}/${pack.handoff_readiness?.image_assets || 0}`]
      ];
      nodes.ethalonPackSummary.innerHTML = cards.map(([label, value]) => `
        <div class="ethalon-pack__card">
          <span>${escapeHtml(label)}</span>
          <strong>${escapeHtml(value)}</strong>
        </div>
      `).join("");

      const families = FAMILIES.map((family) => ({
        id: family.id,
        label: family.label,
        pages: Array.isArray(family.pages) ? family.pages : []
      }));
      nodes.ethalonPackGrid.innerHTML = families.flatMap((family) => ((family.pages || []).slice().sort((a, b) => {
        const priorityDiff = pageSourcePriority(a) - pageSourcePriority(b);
        if (priorityDiff !== 0) return priorityDiff;
        return String(a.label || a.id).localeCompare(String(b.label || b.id));
      })).map((page) => {
        const jobs = Array.isArray(page.jobs) ? page.jobs : [];
        const status = summarizePageSourceStatus(page);
        const variantLinks = VARIANTS.map((variant) => {
          const job = jobs.find((item) => item.variantId === variant.id && Array.isArray(item.expectedArtifacts) && item.expectedArtifacts.length);
          if (!job) return `<span>${escapeHtml(variant.label)} нет</span>`;
          const imageUrl = resolveUrl(job.expectedArtifacts[0]);
          const specUrl = resolveUrl((job.screenSpecArtifacts || [])[0] || "");
          const backgroundUrl = resolveUrl((job.backgroundArtifacts || [])[0] || "");
          const handoffUrl = resolveUrl((job.handoffArtifacts || [])[0] || "");
          return `
            <a href="${escapeHtml(imageUrl)}" target="_blank" rel="noreferrer">${escapeHtml(variant.label)} PNG</a>
            ${specUrl ? `<a href="${escapeHtml(specUrl)}" target="_blank" rel="noreferrer">${escapeHtml(variant.label)} JSON</a>` : ""}
            ${backgroundUrl ? `<a href="${escapeHtml(backgroundUrl)}" target="_blank" rel="noreferrer">${escapeHtml(variant.label)} BG</a>` : ""}
            ${handoffUrl ? `<a href="${escapeHtml(handoffUrl)}" target="_blank" rel="noreferrer">${escapeHtml(variant.label)} handoff</a>` : ""}
          `;
        }).join("");
        const deepLink = buildDeepLink({ family: family.id, page: page.id, variant: "1200", mode: "page", screen: "full-page" });
        const roleLabel = Array.isArray(page.surface_roles) && page.surface_roles.length ? page.surface_roles.join(", ") : page.lane || "reference";
        const locatorEntry = getLocatorEntry(sourceLocatorData || { pages: [] }, page);
        const pageClass = status.className === "route-status is-export"
          ? "is-ready"
          : status.className === "route-status is-danger"
            ? "is-danger"
            : "";
        const routeAction = pageHasAnyRealSource(page)
          ? `<a href="${escapeHtml(deepLink)}">открыть панель</a>`
          : `<span>контур восстановления</span>`;
        const recoveryBlock = !pageHasAnyRealSource(page) && locatorEntry
          ? `
            <div class="ethalon-pack__recovery">
              <strong>Причина блокировки</strong>
              <span>${escapeHtml((locatorEntry.blocked_by || []).join(" ") || page.blockedReason || "Экспорт из Figma пока не зафиксирован.")}</span>
              ${locatorEntry.next_recovery_action ? `<div><strong>Следующий шаг</strong> <code>${escapeHtml(locatorEntry.next_recovery_action)}</code></div>` : ""}
            </div>
          `
          : "";
        return `
          <article class="ethalon-pack__page ${active?.page?.id === page.id ? "is-active" : ""} ${pageClass}">
            <div class="ethalon-pack__title">
              <div>
                <strong>${escapeHtml(page.label || page.id)}</strong><br>
                <code>${escapeHtml(page.pageSrc || "")}</code><br>
                <code>${escapeHtml(roleLabel)}</code>
              </div>
              <div style="display:grid;gap:6px;justify-items:end;">
                <code>${escapeHtml(family.id)}</code>
                <span class="ethalon-pack__badge ${escapeHtml(status.className.replace("route-status ", ""))}">${escapeHtml(status.label)}</span>
              </div>
            </div>
            <div class="ethalon-pack__links">
              ${routeAction}
              ${variantLinks}
            </div>
            ${recoveryBlock}
          </article>
        `;
      })).join("");
    }

    function currentFamily() {
      return FAMILIES.find((family) => family.id === state.familyId);
    }

    function currentPage() {
      return currentFamily().pages.find((page) => page.id === state.pageId);
    }

    function currentVariant() {
      return VARIANTS.find((variant) => variant.id === state.variantId);
    }

    function jobsForVariant(page, variant) {
      return (page.jobs || []).filter((job) => !job.variantId || job.variantId === variant.id);
    }

    function exportJobsForVariant(page, variant) {
      return jobsForVariant(page, variant).filter((job) => job.status === "export_exists");
    }

    function hasRealSourceForVariant(page, variant) {
      return exportJobsForVariant(page, variant).length > 0;
    }

    function pageHasAnyRealSource(page) {
      return VARIANTS.some((variant) => hasRealSourceForVariant(page, variant));
    }

    function hasVisualScreenCompare(page, variant) {
      return hasRealSourceForVariant(page, variant);
    }

    function canOpenScreenFlow(page, variantId) {
      const variant = VARIANTS.find((item) => item.id === variantId) || currentVariant();
      return !!variant && hasVisualScreenCompare(page, variant);
    }

    function screenCatalogKey(page, variant) {
      return `${page.id}::${variant.id}`;
    }

    function defaultScreenOption() {
      return {
        id: "full-page",
        label: "Вся страница",
        kind: "page"
      };
    }

    function currentScreenOptions() {
      const page = currentPage();
      const variant = currentVariant();
      if (!hasVisualScreenCompare(page, variant)) {
        return [defaultScreenOption()];
      }
      return screenCatalog.get(screenCatalogKey(page, variant)) || [defaultScreenOption()];
    }

    function currentScreenOption() {
      return currentScreenOptions().find((item) => item.id === state.screenId) || currentScreenOptions()[0] || defaultScreenOption();
    }

    function formatRatio(value) {
      if (!Number.isFinite(value)) {
        return "n/a";
      }
      return `${(value * 100).toFixed(1)}%`;
    }

    function sliceRoleLabel(role) {
      const map = {
        "header-entry": "Header / entry band",
        "upper-content": "Upper content",
        "content-band": "Content band",
        "lower-content": "Lower content",
        "footer-exit": "Footer / exit band"
      };
      return map[role] || "Scan band";
    }

    function sliceFocusText(role) {
      const map = {
        "header-entry": "Проверь верхнюю навигацию, safe area, стартовый ритм и первый fold.",
        "upper-content": "Проверь первый смысловой блок, вертикальный вход, leading и колонку якорей.",
        "content-band": "Проверь плотность контента, внутренние интервалы, переносы и локальный drift.",
        "lower-content": "Проверь завершающий ритм контента, CTA/summary зоны и переход к низу страницы.",
        "footer-exit": "Проверь нижнюю границу, финальный отступ и выход страницы без обрезки или съезда."
      };
      return map[role] || "Проверь локальную геометрию, ритм, типографику и control drift внутри этой зоны.";
    }

    function deriveSliceRole(index, total) {
      if (index === 0) return "header-entry";
      if (index === total - 1) return "footer-exit";
      if (index === 1) return "upper-content";
      if (index === total - 2) return "lower-content";
      return "content-band";
    }

    function partitionHeight(totalHeight, sliceCount) {
      const total = Math.max(1, Math.round(totalHeight));
      const count = Math.max(1, Math.round(sliceCount));
      const base = Math.floor(total / count);
      const remainder = total - base * count;
      const slices = [];
      let top = 0;
      for (let index = 0; index < count; index += 1) {
        const height = base + (index < remainder ? 1 : 0);
        slices.push({ index, top, height });
        top += height;
      }
      return slices;
    }

    function resolveScanContractHeight(totalHeight, variant, sliceCount) {
      if (Number.isFinite(totalHeight) && totalHeight > 0) {
        return Math.round(totalHeight);
      }
      return Math.max(variant.width * Math.max(sliceCount, 3), 1080);
    }

    function formatScanBand(top, height, unit) {
      if (!Number.isFinite(top) || !Number.isFinite(height)) {
        return "Маппинг полос заблокирован.";
      }
      const suffix = unit === "contract-unit" ? "cu" : "px";
      return `Полоса: ${top}${suffix} -> ${top + height}${suffix} (${height}${suffix})`;
    }

    function buildScanSlices(sourceSpec, totalHeight, variant) {
      const sections = Array.isArray(sourceSpec?.sections) ? sourceSpec.sections : [];
      const sectionLabels = sections
        .slice(0, 10)
        .map((section, index) => chooseScreenLabel(section, index))
        .filter(Boolean);

      const measuredHeight = Number.isFinite(totalHeight) && totalHeight > 0 ? Math.round(totalHeight) : null;
      const syntheticCount = measuredHeight
        ? clamp(
          Math.ceil(measuredHeight / Math.max(variant.width * 1.1, 720)),
          3,
          10
        )
        : clamp(sectionLabels.length || Math.ceil(variant.width / 160), 3, 10);
      const sliceCount = sectionLabels.length
        ? clamp(sectionLabels.length, 3, 10)
        : syntheticCount;
      const contractHeight = resolveScanContractHeight(measuredHeight, variant, sliceCount);
      const partitions = partitionHeight(contractHeight, sliceCount);
      const basis = sectionLabels.length
        ? "source_contract_section_stack"
        : "synthetic_scan_stack";
      const certainty = sectionLabels.length
        ? "approximate_contract_band"
        : "synthetic_band";
      const measurementUnit = measuredHeight ? "px" : "contract-unit";

      return partitions.map(({ index, top, height }) => {
        const role = deriveSliceRole(index, partitions.length);
        const label = sectionLabels[index] || `${String(index + 1).padStart(2, "0")} ${sliceRoleLabel(role)}`;
        return {
          id: `slice-${String(index + 1).padStart(2, "0")}`,
          order: index + 1,
          label,
          role,
          top,
          height,
          topRatio: top / contractHeight,
          heightRatio: height / contractHeight,
          basis,
          certainty,
          measurementUnit,
          measuredHeight,
          contractHeight
        };
      });
    }

    function buildManifestScanSlices(familyRegistryEntry, totalHeight, variant) {
      const families = Array.isArray(familyRegistryEntry?.families) ? familyRegistryEntry.families : [];
      if (!families.length) {
        return [];
      }
      const measuredHeight = Number.isFinite(totalHeight) && totalHeight > 0 ? Math.round(totalHeight) : null;
      const contractHeight = resolveScanContractHeight(measuredHeight, variant, families.length);
      const measurementUnit = measuredHeight ? "px" : "contract-unit";
      return families.map((family, index) => {
        const topRatio = clamp(Number(family?.source_corridor?.top_ratio) || 0, 0, 1);
        const heightRatio = clamp(Number(family?.source_corridor?.height_ratio) || (1 / Math.max(families.length, 1)), 0.02, 1);
        const top = Math.round(topRatio * contractHeight);
        const height = Math.max(80, Math.round(heightRatio * contractHeight));
        return {
          id: family.id || `family-${index + 1}`,
          order: Number(family.order) || index + 1,
          label: family.label || family.key || `Family ${index + 1}`,
          role: "manifest-family",
          top,
          height,
          topRatio,
          heightRatio,
          basis: familyRegistryEntry.source_basis || "family_manifest",
          certainty: "manifest_family_corridor",
          measurementUnit,
          measuredHeight,
          contractHeight,
          selector: family.selector || "",
          key: family.key || family.id || "",
          screenName: family.screen_name || "",
          specPath: family.spec_path || "",
          primaryVerifier: family.primary_verifier || "",
          forbiddenReopenLayers: Array.isArray(family.forbidden_reopen_layers) ? family.forbidden_reopen_layers : [],
          rowBands: Array.isArray(family.row_bands) ? family.row_bands : []
        };
      });
    }

    function projectSlicesToImplementation(sourceSlices, implementationHeight, implementationFamilies = []) {
      if (!Number.isFinite(implementationHeight) || implementationHeight <= 0) {
        return [];
      }

      const total = Math.round(implementationHeight);
      return sourceSlices.map((slice, index) => {
        const liveFamily = Array.isArray(implementationFamilies)
          ? implementationFamilies.find((item) => item.id === slice.id)
          : null;
        if (liveFamily) {
          return {
            sourceSliceId: slice.id,
            order: slice.order,
            label: slice.label,
            role: slice.role,
            top: liveFamily.top,
            height: liveFamily.height,
            topRatio: liveFamily.topRatio,
            heightRatio: liveFamily.heightRatio,
            compareFocus: sliceFocusText(slice.role),
            selector: liveFamily.selector || slice.selector || ""
          };
        }
        const top = Math.round(slice.topRatio * total);
        const nextTop = index === sourceSlices.length - 1
          ? total
          : Math.round(sourceSlices[index + 1].topRatio * total);
        const height = Math.max(80, nextTop - top);
        return {
          sourceSliceId: slice.id,
          order: slice.order,
          label: slice.label,
          role: slice.role,
          top,
          height,
          topRatio: top / total,
          heightRatio: height / total,
          compareFocus: sliceFocusText(slice.role),
          selector: slice.selector || ""
        };
      });
    }

    function buildScanDocument(payload) {
      const { family, page, variant, screen, sourceSpec, imageInfo, implementation, familyRegistryEntry } = payload;
      const sourceReady = !!imageInfo;
      const sourceContractReady = !!(imageInfo || sourceSpec);
      const implementationReady = !!implementation;
      const sourceSlices = familyRegistryEntry
        ? buildManifestScanSlices(familyRegistryEntry, imageInfo?.height, variant)
        : (sourceContractReady ? buildScanSlices(sourceSpec, imageInfo?.height, variant) : []);
      const liveSlices = implementationReady
        ? projectSlicesToImplementation(sourceSlices, implementation.pageHeight, implementation.auditFamilies)
        : [];
      const compareUnitId = `${page.id}::${variant.id}::${state.modeId}::${screen?.id || "full-page"}`;
      const sliceRows = sourceSlices.map((sourceSlice, index) => {
        const liveSlice = liveSlices[index] || null;
        return {
          id: sourceSlice.id,
          order: sourceSlice.order,
          label: sourceSlice.label,
          role: sourceSlice.role,
          selector: sourceSlice.selector || "",
          key: sourceSlice.key || "",
          screenName: sourceSlice.screenName || "",
          specPath: sourceSlice.specPath || "",
          primaryVerifier: sourceSlice.primaryVerifier || "",
          forbiddenReopenLayers: sourceSlice.forbiddenReopenLayers || [],
          rowBands: sourceSlice.rowBands || [],
          focus: sliceFocusText(sourceSlice.role),
          source: {
            responsibility: "Эталон",
            status: sourceReady ? "ready" : (sourceSpec ? "contract_only" : "blocked_by_ethalon"),
            basis: sourceSlice.basis,
            certainty: sourceSlice.certainty,
            evidence: imageInfo ? imageInfo.url : (sourceSpec?.page || page.manifestTitle || null),
            top: sourceSlice.top,
            height: sourceSlice.height,
            topRatio: sourceSlice.topRatio,
            heightRatio: sourceSlice.heightRatio,
            measurementUnit: sourceSlice.measurementUnit,
            measuredHeight: sourceSlice.measuredHeight,
            contractHeight: sourceSlice.contractHeight
          },
          implementation: liveSlice ? {
            responsibility: "Верстальщик",
            status: "mapped",
            evidence: implementation.frameSrc,
            top: liveSlice.top,
            height: liveSlice.height,
            topRatio: liveSlice.topRatio,
            heightRatio: liveSlice.heightRatio
          } : {
            responsibility: "Верстальщик",
            status: implementationReady ? "missing_mapping" : "blocked_by_runtime",
            evidence: implementation?.frameSrc || null,
            top: null,
            height: null,
            topRatio: null,
            heightRatio: null
          }
        };
      });

      return {
        artifact_type: "oracle_scan_document",
        contract_version: 1,
        generated_utc: new Date().toISOString(),
        compare_unit_id: compareUnitId,
        family: { id: family.id, label: family.label },
        page: { id: page.id, label: page.label, pageSrc: page.pageSrc },
        variant: { id: variant.id, width: variant.width },
        mode: state.modeId,
        screen: { id: screen?.id || "full-page", label: screen?.label || "Вся страница" },
        family_manifest: familyRegistryEntry ? {
          status: "manifest_ready",
          source_basis: familyRegistryEntry.source_basis || "family_manifest",
          family_count: sourceSlices.length
        } : {
          status: "manifest_missing",
          source_basis: null,
          family_count: 0
        },
        ethalon: {
          owner: "Эталон",
          status: sourceReady ? "ready" : (sourceSpec ? "contract_only" : "blocked_by_ethalon"),
          basis: sourceReady
            ? (sourceSlices[0]?.basis || "synthetic_scan_stack")
            : (sourceSpec ? "source_spec_only" : "missing_source_truth"),
          total_height: imageInfo?.height || null,
          contract_height: sourceSlices[0]?.contractHeight || null,
          slice_count: sourceSlices.length,
          evidence_url: imageInfo?.url || (sourceSpec?.page || page.manifestTitle || null)
        },
        verstalschik: {
          owner: "Верстальщик",
          status: implementationReady ? "mapped" : "blocked_by_runtime",
          total_height: implementation?.pageHeight || null,
          slice_count: liveSlices.length,
          evidence_url: implementation?.frameSrc || null
        },
        handoff_rule: "Эталон freezes the slice stack and labels each band. Верстальщик maps the same band ratios onto live implementation. Acceptance uses the stack for bounded compare before any visual verdict.",
        slices: sliceRows
      };
    }

    function renderScanDocument(scanDocument) {
      currentScanDocument = scanDocument;
      if (!nodes.scanDocSummary || !nodes.scanDocGrid || !nodes.scanDocContractText) {
        return;
      }

      if (!scanDocument) {
        nodes.scanDocSummary.innerHTML = `<div class="notice">Документ срезов недоступен для текущего состояния.</div>`;
        nodes.scanDocGrid.innerHTML = "";
        nodes.scanDocContractText.textContent = "Документ срезов ждёт контекст эталона и live-верстки.";
        return;
      }

      const summaryCards = [
        ["Юнит сравнения", scanDocument.compare_unit_id],
        ["Эталон", `${scanDocument.ethalon.status} / ${scanDocument.ethalon.slice_count} срезов`],
        ["Верстальщик", `${scanDocument.verstalschik.status} / ${scanDocument.verstalschik.slice_count} срезов`],
        ["Family manifest", `${scanDocument.family_manifest.status} / ${scanDocument.family_manifest.family_count}`],
        ["Основа", scanDocument.ethalon.basis || "n/a"],
        ["Высота эталона", scanDocument.ethalon.total_height ? `${scanDocument.ethalon.total_height}px` : (scanDocument.ethalon.contract_height ? `${scanDocument.ethalon.contract_height}cu` : "нет")],
        ["Высота live", scanDocument.verstalschik.total_height ? `${scanDocument.verstalschik.total_height}px` : "нет"]
      ];

      nodes.scanDocSummary.innerHTML = summaryCards.map(([label, value]) => `
        <div class="scan-doc__card">
          <span>${escapeHtml(label)}</span>
          <strong>${escapeHtml(value)}</strong>
        </div>
      `).join("");

      nodes.scanDocContractText.innerHTML = `
        <strong>Правило handoff:</strong> ${escapeHtml(scanDocument.handoff_rule)}
        <br><strong>Разделение ответственности:</strong> <code>Эталон</code> фиксирует стек полос и evidence. <code>Верстальщик</code> мапит те же ratios на live HTML и сравнивает по полосам, а не угадывает по памяти всей страницы.
        <br><strong>Примечание к контракту:</strong> если PNG-эталон отсутствует, но section-contract существует, <code>Эталон</code> всё равно может опубликовать стек в <code>cu</code> (contract units). Canonical остаются именно ratios; измеренных пикселей эталона пока нет.
      `;

      if (!scanDocument.slices.length) {
        nodes.scanDocGrid.innerHTML = `<div class="scan-doc__row is-blocked"><div class="scan-doc__cell is-focus" style="grid-column:1/-1"><strong>Документ срезов заблокирован</strong><span>Экспорт эталона или live-верстка отсутствуют, поэтому панель не может честно собрать стек срезов.</span></div></div>`;
        return;
      }

      nodes.scanDocGrid.innerHTML = scanDocument.slices.map((slice) => `
        <div class="scan-doc__row ${slice.implementation.status !== "mapped" ? "is-blocked" : ""}">
          <div class="scan-doc__cell">
            <strong>${escapeHtml(slice.label)}</strong>
            <span>${escapeHtml(sliceRoleLabel(slice.role))}</span>
            <code>${escapeHtml(slice.id)}</code>
          </div>
          <div class="scan-doc__cell is-ethalon">
            <strong>${escapeHtml(slice.source.responsibility)}</strong>
            <span>Статус: ${escapeHtml(slice.source.status)}</span>
            <span>${escapeHtml(formatScanBand(slice.source.top, slice.source.height, slice.source.measurementUnit))}</span>
            <span>Соотношения: top ${escapeHtml(formatRatio(slice.source.topRatio))} / height ${escapeHtml(formatRatio(slice.source.heightRatio))}</span>
            <code>${escapeHtml(slice.source.basis)} / ${escapeHtml(slice.source.certainty)}</code>
          </div>
          <div class="scan-doc__cell is-live">
            <strong>${escapeHtml(slice.implementation.responsibility)}</strong>
            <span>Статус: ${escapeHtml(slice.implementation.status)}</span>
            <span>${Number.isFinite(slice.implementation.top) ? `Полоса: ${slice.implementation.top}px -> ${slice.implementation.top + slice.implementation.height}px (${slice.implementation.height}px)` : "Маппинг полос заблокирован, пока live-верстка не стала измеримой."}</span>
            <span>${Number.isFinite(slice.implementation.topRatio) ? `Соотношения: top ${formatRatio(slice.implementation.topRatio)} / height ${formatRatio(slice.implementation.heightRatio)}` : "Live ratios ещё не построены."}</span>
            <code>${escapeHtml(slice.implementation.evidence || "live runtime отсутствует")}</code>
          </div>
          <div class="scan-doc__cell is-focus">
            <strong>Фокус сравнения</strong>
            <span>${escapeHtml(slice.focus)}</span>
            <code>Используй эту полосу как bounded proof до приёмки whole-page similarity.</code>
          </div>
        </div>
      `).join("");
    }

    function findFamily(familyId) {
      return FAMILIES.find((family) => family.id === familyId);
    }

    function findPage(familyId, pageId) {
      const family = findFamily(familyId);
      return family ? family.pages.find((page) => page.id === pageId) : null;
    }

    function syncUrl() {
      const params = new URLSearchParams(window.location.search);
      params.set("family", state.familyId);
      params.set("page", state.pageId);
      params.set("variant", state.variantId);
      params.set("mode", state.modeId);
      params.set("screen", state.screenId);
      params.set("lens", state.lensId);
      params.set("top", state.overlayTopLayerId);
      params.set("opacity", String(state.overlayOpacity));
      params.set("split", String(state.overlaySplit));
      params.set("pixel", state.pixelAuditMode ? "1" : "0");
      params.set("grid", state.guideGrid ? "1" : "0");
      params.set("index", state.guideIndex ? "1" : "0");
      params.set("safe", state.guideSafeArea ? "1" : "0");
      params.set("anchors", state.guideAnchors ? "1" : "0");
      params.set("columns", String(state.guideColumns));
      params.set("baseline", String(state.guideBaseline));
      params.set("audit", state.auditMode ? "1" : "0");
      params.set("brush", state.auditBrush);
      params.set("auditScope", state.auditScope);
      params.set("auditLayer", state.auditLayerId);
      if (state.auditFamilyId) {
        params.set("auditFamily", state.auditFamilyId);
      } else {
        params.delete("auditFamily");
      }
      if (state.auditRowId) {
        params.set("auditRow", state.auditRowId);
      } else {
        params.delete("auditRow");
      }
      const issue = serializeIssueRegion();
      const issues = serializeIssueRegions();
      if (issue) {
        params.set("issue", issue);
      } else {
        params.delete("issue");
      }
      if (issues) {
        params.set("issues", issues);
      } else {
        params.delete("issues");
      }
      if (state.issueActiveIndex >= 0) {
        params.set("issueIdx", String(state.issueActiveIndex));
      } else {
        params.delete("issueIdx");
      }
      history.replaceState({}, "", `${window.location.pathname}?${params.toString()}`);
    }

    function currentDeepLink() {
      const query = {
        family: state.familyId,
        page: state.pageId,
        variant: state.variantId,
        mode: state.modeId,
        screen: state.screenId,
        lens: state.lensId,
        top: state.overlayTopLayerId,
        opacity: String(state.overlayOpacity),
        split: String(state.overlaySplit),
        pixel: state.pixelAuditMode ? "1" : "0",
        grid: state.guideGrid ? "1" : "0",
        index: state.guideIndex ? "1" : "0",
        safe: state.guideSafeArea ? "1" : "0",
        anchors: state.guideAnchors ? "1" : "0",
        columns: String(state.guideColumns),
        baseline: String(state.guideBaseline),
        audit: state.auditMode ? "1" : "0",
        brush: state.auditBrush,
        auditScope: state.auditScope,
        auditLayer: state.auditLayerId,
        auditFamily: state.auditFamilyId,
        auditRow: state.auditRowId,
        issue: serializeIssueRegion(),
        issues: serializeIssueRegions(),
        issueIdx: state.issueActiveIndex >= 0 ? String(state.issueActiveIndex) : ""
      };
      Object.keys(query).forEach((key) => {
        if (query[key] === "" || query[key] == null) {
          delete query[key];
        }
      });
      return `${window.location.origin}${window.location.pathname}?${new URLSearchParams(query).toString()}`;
    }

    function buildDeepLink(overrides = {}) {
      const query = {
        family: state.familyId,
        page: state.pageId,
        variant: state.variantId,
        mode: state.modeId,
        screen: state.screenId,
        lens: state.lensId,
        top: state.overlayTopLayerId,
        opacity: String(state.overlayOpacity),
        split: String(state.overlaySplit),
        pixel: state.pixelAuditMode ? "1" : "0",
        grid: state.guideGrid ? "1" : "0",
        index: state.guideIndex ? "1" : "0",
        safe: state.guideSafeArea ? "1" : "0",
        anchors: state.guideAnchors ? "1" : "0",
        columns: String(state.guideColumns),
        baseline: String(state.guideBaseline),
        audit: state.auditMode ? "1" : "0",
        brush: state.auditBrush,
        auditScope: state.auditScope,
        auditFamily: state.auditFamilyId,
        auditRow: state.auditRowId,
        issue: serializeIssueRegion(),
        issues: serializeIssueRegions(),
        issueIdx: state.issueActiveIndex >= 0 ? String(state.issueActiveIndex) : "",
        ...overrides
      };
      Object.keys(query).forEach((key) => {
        if (query[key] === "" || query[key] == null) {
          delete query[key];
        }
      });
      return `${window.location.origin}${window.location.pathname}?${new URLSearchParams(query).toString()}`;
    }

    function applyStateFromUrl() {
      const params = new URLSearchParams(window.location.search);
      const familyId = params.get("family");
      const pageId = params.get("page");
      const variantId = params.get("variant");
      const modeId = params.get("mode");
      const screenId = params.get("screen");
      const lensId = params.get("lens");
      const topLayerId = params.get("top");
      const opacity = Number.parseInt(params.get("opacity") || "", 10);
      const split = Number.parseInt(params.get("split") || "", 10);
      const pixel = params.get("pixel");
      const grid = params.get("grid");
      const index = params.get("index");
      const safe = params.get("safe");
      const anchors = params.get("anchors");
      const columns = Number.parseInt(params.get("columns") || "", 10);
      const baseline = Number.parseInt(params.get("baseline") || "", 10);
      const audit = params.get("audit");
      const brush = params.get("brush");
      const auditScope = params.get("auditScope");
      const auditLayer = params.get("auditLayer");
      const auditFamily = params.get("auditFamily");
      const auditRow = params.get("auditRow");
      const issue = params.get("issue");
      const issues = params.get("issues");
      const issueIdx = Number.parseInt(params.get("issueIdx") || "", 10);

      if (familyId && FAMILIES.some((family) => family.id === familyId)) {
        state.familyId = familyId;
      }
      if (pageId) {
        const requestedFamily = findFamily(state.familyId);
        const pageExistsInRequestedFamily = (requestedFamily?.pages || []).some((page) => page.id === pageId);
        const owningFamily = FAMILIES.find((family) => (family.pages || []).some((page) => page.id === pageId));
        if (!pageExistsInRequestedFamily && owningFamily) {
          state.familyId = owningFamily.id;
        }
      }
      if (variantId && VARIANTS.some((variant) => variant.id === variantId)) {
        state.variantId = variantId;
      }
      if (modeId && VIEW_MODES.some((mode) => mode.id === modeId)) {
        state.modeId = modeId;
      }
      if (lensId && COMPARE_LENSES.some((lens) => lens.id === lensId)) {
        state.lensId = lensId;
      }
      if (topLayerId && OVERLAY_TOP_LAYERS.some((item) => item.id === topLayerId)) {
        state.overlayTopLayerId = topLayerId;
      }
      if (Number.isFinite(opacity)) {
        state.overlayOpacity = clamp(opacity, 10, 100);
      }
      if (Number.isFinite(split)) {
        state.overlaySplit = clamp(split, 0, 100);
      }
      if (pixel === "0" || pixel === "1") {
        state.pixelAuditMode = pixel === "1";
      }
      if (grid === "0" || grid === "1") {
        state.guideGrid = grid === "1";
      }
      if (index === "0" || index === "1") {
        state.guideIndex = index === "1";
      }
      if (safe === "0" || safe === "1") {
        state.guideSafeArea = safe === "1";
      }
      if (anchors === "0" || anchors === "1") {
        state.guideAnchors = anchors === "1";
      }
      if (Number.isFinite(columns)) {
        state.guideColumns = clamp(columns, 4, 24);
      }
      if (Number.isFinite(baseline)) {
        state.guideBaseline = clamp(baseline, 4, 16);
      }
      if (audit === "0" || audit === "1") {
        state.auditMode = audit === "1";
      }
      if (brush && ["pass", "in_progress", "attention"].includes(brush)) {
        state.auditBrush = brush;
      }
      if (auditScope && ["families", "rows", "cells"].includes(auditScope)) {
        state.auditScope = auditScope;
      }
      if (auditLayer && AUDIT_LAYER_ORDER.includes(auditLayer)) {
        state.auditLayerId = auditLayer;
      }
      if (auditFamily) {
        state.auditFamilyId = auditFamily;
      }
      if (auditRow) {
        state.auditRowId = auditRow;
      }
      state.issueRegions = parseIssueRegions(issues);
      if (!state.issueRegions.length) {
        const parsedSingle = parseIssueRegion(issue);
        state.issueRegions = parsedSingle ? [{ ...parsedSingle, id: "issue-1" }] : [];
      }
      syncIssueState(Number.isFinite(issueIdx) ? issueIdx : (state.issueRegions.length ? state.issueRegions.length - 1 : -1));

      const family = currentFamily();
      if (pageId && family.pages.some((page) => page.id === pageId)) {
        state.pageId = pageId;
      } else {
        state.pageId = family.pages[0].id;
      }

      if (screenId) {
        state.screenId = screenId;
      }
    }

    function renderChipGroup(container, items, activeId, onClick) {
      container.innerHTML = items.map((item) => {
        const activeClass = item.id === activeId ? "chip is-active" : "chip";
        const disabledAttr = item.disabled ? " disabled" : "";
        const disabledClass = item.disabled ? " is-disabled" : "";
        const helpAttr = item.help ? ` title="${escapeHtml(item.help)}" aria-label="${escapeHtml(`${item.label}: ${item.help}`)}"` : "";
        return `<button type="button" class="${activeClass}${disabledClass}" data-id="${escapeHtml(item.id)}"${disabledAttr}${helpAttr}>${escapeHtml(item.label)}</button>`;
      }).join("");
      container.querySelectorAll("button").forEach((button) => {
        if (button.disabled) {
          return;
        }
        button.addEventListener("click", () => onClick(button.dataset.id));
      });
    }

    function scaleToFit(viewport, naturalWidth, naturalHeight, options = {}) {
      const container = viewport.parentElement;
      const stage = container?.parentElement;
      const fit = options.fit === "width" ? "width" : "both";
      const styles = window.getComputedStyle(container);
      const padX = (parseFloat(styles.paddingLeft) || 0) + (parseFloat(styles.paddingRight) || 0);
      const padY = (parseFloat(styles.paddingTop) || 0) + (parseFloat(styles.paddingBottom) || 0);
      const safeInsetX = 36;
      const safeInsetY = 24;
      const containerWidth = Math.max(container.clientWidth - padX, 0);
      const containerHeight = Math.max(container.clientHeight - padY, 0);
      const stageWidth = Math.max(
        Math.min(containerWidth, stage?.clientWidth || containerWidth) - safeInsetX,
        320
      );
      const stageHeight = Math.max(
        Math.min(containerHeight, stage?.clientHeight || containerHeight) - safeInsetY,
        360
      );
      const scale = state.pixelAuditMode ? 1 : (fit === "width"
        ? Math.min(stageWidth / naturalWidth, 1)
        : Math.min(stageWidth / naturalWidth, stageHeight / naturalHeight, 1));
      const scaledWidth = naturalWidth * scale;
      const horizontalInset = state.pixelAuditMode ? 0 : Math.max((stageWidth - scaledWidth) / 2, 0);
      viewport.style.width = `${naturalWidth}px`;
      viewport.style.height = `${naturalHeight}px`;
      viewport.style.transformOrigin = "top left";
      viewport.style.transform = `scale(${scale})`;
      viewport.dataset.scale = scale.toFixed(4);
      viewport.dataset.pixelAudit = state.pixelAuditMode ? "1" : "0";
      viewport.style.marginLeft = `${horizontalInset}px`;
      viewport.style.marginRight = "0";
      viewport.style.marginBottom = state.pixelAuditMode ? "24px" : (fit === "width"
        ? `${Math.max(24, naturalHeight * (1 - scale))}px`
        : `${Math.max(0, naturalHeight * scale - naturalHeight)}px`);
      if (stage) {
        stage.scrollLeft = 0;
        stage.scrollTop = 0;
      }
    }

    function setViewportPresentationMode(viewport, modeId) {
      const canvas = viewport?.parentElement;
      const stage = canvas?.parentElement;
      const isPageMode = modeId === "page";
      viewport?.classList.toggle("viewport--page", isPageMode);
      canvas?.classList.toggle("canvas--page", isPageMode);
      stage?.classList.toggle("pane__stage--page", isPageMode);
    }

    function clamp(value, min, max) {
      return Math.max(min, Math.min(max, value));
    }

    function clearViewportGuides(viewport) {
      if (!viewport) {
        return;
      }
      viewport.querySelectorAll(".guide-overlay, .guide-label, .issue-interaction, .lens-cursor-hud, .lens-wipe-handle, .audit-overlay").forEach((node) => node.remove());
    }

    function formatGuideColumnId(index) {
      let value = index + 1;
      let label = "";
      while (value > 0) {
        const mod = (value - 1) % 26;
        label = String.fromCharCode(65 + mod) + label;
        value = Math.floor((value - 1) / 26);
      }
      return label;
    }

    function formatGuideRowId(index) {
      return String(index + 1).padStart(2, "0");
    }

    function clamp01(value) {
      return Math.max(0, Math.min(1, value));
    }

    function clampIssueRegion(region) {
      if (!region) {
        return null;
      }
      const x = clamp01(Number(region.x));
      const y = clamp01(Number(region.y));
      const w = clamp01(Number(region.w));
      const h = clamp01(Number(region.h));
      if (!Number.isFinite(x) || !Number.isFinite(y) || !Number.isFinite(w) || !Number.isFinite(h)) {
        return null;
      }
      if (w <= 0 || h <= 0) {
        return null;
      }
      return {
        x,
        y,
        w: Math.min(w, 1 - x),
        h: Math.min(h, 1 - y)
      };
    }

    function serializeIssueRegion(region = state.issueRegion) {
      const normalized = clampIssueRegion(region);
      if (!normalized) {
        return "";
      }
      return [normalized.x, normalized.y, normalized.w, normalized.h]
        .map((value) => value.toFixed(4))
        .join(",");
    }

    function parseIssueRegion(value) {
      if (!value) {
        return null;
      }
      const parts = String(value).split(",").map((item) => Number.parseFloat(item.trim()));
      if (parts.length !== 4 || parts.some((item) => !Number.isFinite(item))) {
        return null;
      }
      return clampIssueRegion({
        x: parts[0],
        y: parts[1],
        w: parts[2],
        h: parts[3]
      });
    }

    function normalizeIssueEntry(region, index = 0) {
      const normalized = clampIssueRegion(region);
      if (!normalized) {
        return null;
      }
      return {
        id: region?.id || `issue-${Date.now()}-${index}`,
        x: normalized.x,
        y: normalized.y,
        w: normalized.w,
        h: normalized.h
      };
    }

    function normalizeIssueRegions(regions) {
      if (!Array.isArray(regions)) {
        return [];
      }
      return regions
        .map((region, index) => normalizeIssueEntry(region, index))
        .filter(Boolean);
    }

    function syncIssueState(activeIndex = state.issueActiveIndex) {
      state.issueRegions = normalizeIssueRegions(state.issueRegions);
      if (!state.issueRegions.length) {
        state.issueActiveIndex = -1;
        state.issueRegion = null;
        return;
      }
      state.issueActiveIndex = clamp(
        Number.isFinite(activeIndex) ? activeIndex : state.issueRegions.length - 1,
        0,
        state.issueRegions.length - 1
      );
      const active = state.issueRegions[state.issueActiveIndex];
      state.issueRegion = active ? { x: active.x, y: active.y, w: active.w, h: active.h } : null;
    }

    function serializeIssueRegions(regions = state.issueRegions) {
      const normalized = normalizeIssueRegions(regions);
      if (!normalized.length) {
        return "";
      }
      return normalized
        .map((region) => serializeIssueRegion(region))
        .filter(Boolean)
        .join("|");
    }

    function parseIssueRegions(value) {
      if (!value) {
        return [];
      }
      return String(value)
        .split("|")
        .map((part, index) => {
          const region = parseIssueRegion(part);
          return region ? { ...region, id: `issue-${index + 1}` } : null;
        })
        .filter(Boolean);
    }

    function describeIssueRegion(region, naturalWidth, naturalHeight) {
      const normalized = clampIssueRegion(region);
      if (!normalized || !Number.isFinite(naturalWidth) || !Number.isFinite(naturalHeight)) {
        return null;
      }
      const width = Math.max(1, Math.round(naturalWidth));
      const height = Math.max(1, Math.round(naturalHeight));
      const x = Math.round(normalized.x * width);
      const y = Math.round(normalized.y * height);
      const w = Math.max(1, Math.round(normalized.w * width));
      const h = Math.max(1, Math.round(normalized.h * height));
      const columns = clamp(state.guideColumns, 4, 24);
      const baseline = clamp(state.guideBaseline, 4, 16);
      const baselineStride = Math.max(baseline * 4, 16);
      const rowStride = baselineStride;
      const x2 = Math.min(width - 1, x + w - 1);
      const y2 = Math.min(height - 1, y + h - 1);
      const colStart = Math.min(columns - 1, Math.floor((x / width) * columns));
      const colEnd = Math.min(columns - 1, Math.floor((x2 / width) * columns));
      const rowStart = Math.max(0, Math.floor(y / rowStride));
      const rowEnd = Math.max(0, Math.floor(y2 / rowStride));
      return {
        px: { x, y, w, h },
        cells: {
          columns: `${formatGuideColumnId(colStart)}-${formatGuideColumnId(colEnd)}`,
          rows: `${formatGuideRowId(rowStart)}-${formatGuideRowId(rowEnd)}`
        },
        edges: {
          left: formatGuideColumnId(colStart),
          right: formatGuideColumnId(colEnd),
          top: formatGuideRowId(rowStart),
          bottom: formatGuideRowId(rowEnd),
          leftPx: x,
          rightPx: x + w - 1,
          topPx: y,
          bottomPx: y + h - 1
        },
        summary: `X ${formatGuideColumnId(colStart)}-${formatGuideColumnId(colEnd)} / Y ${formatGuideRowId(rowStart)}-${formatGuideRowId(rowEnd)} / ${w}x${h}px / top ${y}px / bottom ${y + h - 1}px`
      };
    }

    function describeCursorPoint(point, naturalWidth, naturalHeight) {
      if (!point || !Number.isFinite(naturalWidth) || !Number.isFinite(naturalHeight)) {
        return null;
      }
      const width = Math.max(1, Math.round(naturalWidth));
      const height = Math.max(1, Math.round(naturalHeight));
      const x = clamp(Math.round(point.x * width), 0, width - 1);
      const y = clamp(Math.round(point.y * height), 0, height - 1);
      const columns = clamp(state.guideColumns, 4, 24);
      const baseline = clamp(state.guideBaseline, 4, 16);
      const rowStride = Math.max(baseline * 4, 16);
      const col = Math.min(columns - 1, Math.floor((x / width) * columns));
      const row = Math.max(0, Math.floor(y / rowStride));
      return {
        px: { x, y },
        cell: {
          column: formatGuideColumnId(col),
          row: formatGuideRowId(row)
        },
        summary: `Курсор: X ${formatGuideColumnId(col)} / Y ${formatGuideRowId(row)} / ${x}px:${y}px`
      };
    }

    function buildIssuePayload() {
      const descriptors = state.issueRegions
        .map((region, index) => {
          const descriptor = describeIssueRegion(region, currentLensMetrics?.width, currentLensMetrics?.height);
          return descriptor ? {
            id: state.issueRegions[index]?.id || `issue-${index + 1}`,
            index: index + 1,
            region: descriptor.px,
            grid: descriptor.cells,
            edges: descriptor.edges,
            summary: descriptor.summary
          } : null;
        })
        .filter(Boolean);
      const activeDescriptor = descriptors[state.issueActiveIndex] || descriptors[descriptors.length - 1] || null;
      if (!activeDescriptor) {
        return null;
      }
      return {
        family: state.familyId,
        page: state.pageId,
        variant: state.variantId,
        mode: state.modeId,
        screen: state.screenId,
        lens: state.lensId,
        auditScope: state.auditScope,
        auditLayer: state.auditLayerId,
        auditFamily: state.auditFamilyId,
        auditRow: state.auditRowId,
        region: activeDescriptor.region,
        grid: activeDescriptor.grid,
        edges: activeDescriptor.edges,
        regions: descriptors,
        activeIssueIndex: state.issueActiveIndex,
        link: currentDeepLink()
      };
    }

    function cssPathForElement(element) {
      if (!element || element.nodeType !== 1) {
        return "";
      }
      if (element.id) {
        return `#${CSS.escape(element.id)}`;
      }
      const parts = [];
      let node = element;
      while (node && node.nodeType === 1 && node !== node.ownerDocument.body && node !== node.ownerDocument.documentElement && parts.length < 5) {
        let part = String(node.tagName || "").toLowerCase();
        if (!part) {
          break;
        }
        const classList = Array.from(node.classList || []).filter(Boolean).slice(0, 3);
        if (classList.length) {
          part += `.${classList.map((item) => CSS.escape(item)).join(".")}`;
        }
        const parent = node.parentElement;
        if (parent) {
          const sameTag = Array.from(parent.children).filter((item) => item.tagName === node.tagName);
          if (sameTag.length > 1 && !classList.length) {
            part += `:nth-of-type(${sameTag.indexOf(node) + 1})`;
          }
        }
        parts.unshift(part);
        node = parent;
      }
      return parts.join(" > ");
    }

    function collectLiveDomCandidates(region) {
      const frame = nodes.implementationViewport?.querySelector("iframe");
      if (!frame || !region) {
        return { status: "missing_frame", candidates: [] };
      }
      let doc = null;
      let win = null;
      try {
        doc = frame.contentDocument;
        win = frame.contentWindow;
      } catch (error) {
        return { status: "blocked_cross_origin", candidates: [], error: String(error?.message || error) };
      }
      if (!doc || !win || !doc.body) {
        return { status: "missing_document", candidates: [] };
      }
      const target = {
        x: Number(region.x) || 0,
        y: Number(region.y) || 0,
        w: Number(region.w) || 0,
        h: Number(region.h) || 0
      };
      target.x2 = target.x + target.w;
      target.y2 = target.y + target.h;
      const overlap = (box) => {
        const x1 = Math.max(target.x, box.x);
        const y1 = Math.max(target.y, box.y);
        const x2 = Math.min(target.x2, box.x + box.width);
        const y2 = Math.min(target.y2, box.y + box.height);
        const w = Math.max(0, x2 - x1);
        const h = Math.max(0, y2 - y1);
        return w * h;
      };
      const targetArea = Math.max(1, target.w * target.h);
      const ignored = new Set(["SCRIPT", "STYLE", "META", "LINK", "NOSCRIPT", "HEAD", "TITLE"]);
      const candidates = Array.from(doc.body.querySelectorAll("*"))
        .filter((node) => !ignored.has(node.tagName))
        .map((node) => {
          const rect = node.getBoundingClientRect();
          const box = {
            x: +(win.scrollX + rect.left).toFixed(2),
            y: +(win.scrollY + rect.top).toFixed(2),
            width: +rect.width.toFixed(2),
            height: +rect.height.toFixed(2)
          };
          const area = Math.max(1, box.width * box.height);
          const overlapArea = overlap(box);
          if (!overlapArea || box.width < 2 || box.height < 2) {
            return null;
          }
          const style = win.getComputedStyle(node);
          if (style.display === "none" || style.visibility === "hidden" || Number(style.opacity || 1) === 0) {
            return null;
          }
          const text = (node.textContent || "").trim().replace(/\s+/g, " ");
          const score = (overlapArea / targetArea) + Math.min(1, overlapArea / area) - Math.min(0.5, area / (targetArea * 80));
          return {
            selector: cssPathForElement(node),
            tag: String(node.tagName || "").toLowerCase(),
            id: node.id || "",
            className: String(node.className || ""),
            role: node.getAttribute("role") || "",
            ariaLabel: node.getAttribute("aria-label") || "",
            text: text.slice(0, 220),
            box: {
              ...box,
              bottom: +(box.y + box.height).toFixed(2),
              right: +(box.x + box.width).toFixed(2)
            },
            overlap: {
              area: +overlapArea.toFixed(2),
              targetRatio: +(overlapArea / targetArea).toFixed(4),
              elementRatio: +(overlapArea / area).toFixed(4),
              score: +score.toFixed(4)
            },
            style: {
              display: style.display,
              position: style.position,
              fontFamily: style.fontFamily,
              fontSize: style.fontSize,
              fontWeight: style.fontWeight,
              lineHeight: style.lineHeight,
              letterSpacing: style.letterSpacing,
              color: style.color,
              backgroundColor: style.backgroundColor,
              borderRadius: style.borderRadius,
              width: style.width,
              height: style.height,
              padding: style.padding,
              margin: style.margin,
              overflow: style.overflow
            }
          };
        })
        .filter(Boolean)
        .sort((a, b) => b.overlap.score - a.overlap.score)
        .slice(0, 30);
      return {
        status: candidates.length ? "ready" : "empty",
        target,
        frameSrc: frame.src,
        capturedAt: new Date().toISOString(),
        candidates
      };
    }

    function buildIssueCheckPayload() {
      const issue = buildIssuePayload();
      if (!issue) {
        return null;
      }
      const cache = boardRenderCache || {};
      const page = cache.page || currentPage();
      const family = cache.family || currentFamily();
      const variant = cache.variant || currentVariant();
      const screen = cache.screen || currentScreenOption();
      return {
        ...issue,
        artifact_type: "oracle_compare_board_issue",
        schema_version: 2,
        captured_at: new Date().toISOString(),
        context: {
          familyLabel: family?.label || "",
          pageLabel: page?.label || "",
          variantWidth: variant?.width || Number(state.variantId) || null,
          pageSrc: page?.pageSrc || "",
          liveUrl: page?.pageSrc ? resolveLiveUrl(page.pageSrc) : "",
          referenceImage: cache.imageInfo || null,
          screen: screen ? {
            id: screen.id,
            label: screen.label,
            top: screen.top ?? null,
            height: screen.height ?? null,
            topRatio: screen.topRatio ?? null,
            heightRatio: screen.heightRatio ?? null
          } : null,
          implementation: cache.implementation ? {
            pageHeight: cache.implementation.pageHeight,
            frameSrc: cache.implementation.frameSrc,
            liveDomCandidates: collectLiveDomCandidates(issue.region)
          } : null,
          scanDocument: cache.scanDocument ? {
            compare_unit_id: cache.scanDocument.compare_unit_id,
            ethalon: cache.scanDocument.ethalon,
            verstalschik: cache.scanDocument.verstalschik
          } : null,
          auditRoute: serializeAuditRoute(),
          macroGate: serializeMacroGate(),
          audit: serializeAudit()
        }
      };
    }

    function describeAuditCell(colIndex, rowIndex, naturalWidth, naturalHeight) {
      if (!Number.isFinite(colIndex) || !Number.isFinite(rowIndex) || !naturalWidth || !naturalHeight) {
        return null;
      }
      const columns = clamp(state.guideColumns, 4, 24);
      const rowStride = auditRowStride();
      const cellWidth = naturalWidth / columns;
      const cellHeight = rowStride;
      const x = Math.round(colIndex * cellWidth);
      const y = Math.round(rowIndex * cellHeight);
      const w = Math.round((colIndex === columns - 1 ? naturalWidth : (colIndex + 1) * cellWidth) - x);
      const h = Math.round(Math.min(cellHeight, naturalHeight - y));
      if (w <= 0 || h <= 0) {
        return null;
      }
      return {
        id: `${colIndex}:${rowIndex}`,
        label: formatAuditCellId(colIndex, rowIndex),
        x,
        y,
        w,
        h,
        status: currentAuditCells()[`${colIndex}:${rowIndex}`] || "attention"
      };
    }

    function pointToAuditCell(point, naturalWidth, naturalHeight) {
      if (!point || !naturalWidth || !naturalHeight) {
        return null;
      }
      const columns = clamp(state.guideColumns, 4, 24);
      const colIndex = clamp(Math.floor(point.x * columns), 0, columns - 1);
      const rowIndex = clamp(Math.floor((point.y * naturalHeight) / auditRowStride()), 0, Math.max(0, Math.ceil(naturalHeight / auditRowStride()) - 1));
      return { colIndex, rowIndex };
    }

    function describeAuditPoint(point, naturalWidth, naturalHeight) {
      const cellRef = pointToAuditCell(point, naturalWidth, naturalHeight);
      if (!cellRef) {
        return null;
      }
      const descriptor = describeAuditCell(cellRef.colIndex, cellRef.rowIndex, naturalWidth, naturalHeight);
      if (!descriptor) {
        return null;
      }
      const layer = currentAuditLayerMeta();
      return {
        ...descriptor,
        cell: {
          column: formatGuideColumnId(cellRef.colIndex),
          row: formatGuideRowId(cellRef.rowIndex)
        },
        layer,
        summary: `Аудит: ${layer.label} / ${formatGuideColumnId(cellRef.colIndex)}-${formatGuideRowId(cellRef.rowIndex)} / ${descriptor.w}x${descriptor.h}px / ${descriptor.status}`
      };
    }

    function attachAuditOverlay(viewport, naturalWidth, naturalHeight, scanDocument = null) {
      if (!viewport || !Number.isFinite(naturalWidth) || !Number.isFinite(naturalHeight)) {
        return;
      }
      const columns = clamp(state.guideColumns, 4, 24);
      const rowStride = auditRowStride();
      const rowCount = Math.max(1, Math.ceil(naturalHeight / rowStride));
      const layer = document.createElement("div");
      layer.className = `audit-overlay${state.auditMode ? " is-armed" : ""}`;
      layer.style.width = `${naturalWidth}px`;
      layer.style.height = `${naturalHeight}px`;
      layer.dataset.columns = String(columns);
      layer.dataset.rows = String(rowCount);

      const familyRegistry = currentAuditFamilies();
      ensureAuditFamilySelection();

      const renderFamilies = () => {
        layer.innerHTML = "";
        familyRegistry.forEach((family) => {
          const box = document.createElement("button");
          box.type = "button";
          box.className = `audit-family${state.auditFamilyId === family.id ? " is-selected" : ""}`;
          box.dataset.status = currentAuditFamilyStatus(family.id);
          box.style.left = "0px";
          box.style.top = `${Math.round(family.top)}px`;
          box.style.width = `${naturalWidth}px`;
          box.style.height = `${Math.round(family.height)}px`;
          const label = document.createElement("div");
          label.className = "audit-family__label";
          label.textContent = `${family.label} · ${currentAuditFamilyStatus(family.id)}`;
          box.appendChild(label);
          box.addEventListener("pointerdown", (event) => {
            if (!state.auditMode) {
              return;
            }
            state.auditFamilyId = family.id;
            state.auditRowId = "";
            syncAuditFamilyStatus(family.id, state.auditBrush);
            syncUrl();
            renderAuditSummary();
            renderFamilies();
            event.preventDefault();
          });
          layer.appendChild(box);
        });
      };

      const renderRows = () => {
        layer.innerHTML = "";
        const family = currentSelectedAuditFamily();
        if (!family) {
          return;
        }
        const familyBox = document.createElement("div");
        familyBox.className = "audit-family is-selected";
        familyBox.dataset.status = currentAuditFamilyStatus(family.id);
        familyBox.style.left = "0px";
        familyBox.style.top = `${Math.round(family.top)}px`;
        familyBox.style.width = `${naturalWidth}px`;
        familyBox.style.height = `${Math.round(family.height)}px`;
        const familyLabel = document.createElement("div");
        familyLabel.className = "audit-family__label";
        familyLabel.textContent = family.label;
        familyBox.appendChild(familyLabel);
        layer.appendChild(familyBox);

        buildAuditRowsForFamily(family).forEach((row) => {
          const band = document.createElement("button");
          band.type = "button";
          band.className = `audit-rowband${state.auditRowId === row.id ? " is-selected" : ""}`;
          band.dataset.status = currentAuditRowStatus(family.id, row.id);
          band.style.top = `${Math.round(row.top)}px`;
          band.style.height = `${Math.round(row.height)}px`;
          const label = document.createElement("div");
          label.className = "audit-rowband__label";
          label.textContent = `${row.label} · ${currentAuditRowStatus(family.id, row.id)}`;
          band.appendChild(label);
          band.addEventListener("pointerdown", (event) => {
            if (!state.auditMode) {
              return;
            }
            state.auditRowId = row.id;
            syncAuditRowStatus(family.id, row.id, state.auditBrush);
            syncUrl();
            renderAuditSummary();
            renderRows();
            event.preventDefault();
          });
          layer.appendChild(band);
        });
      };

      const renderCells = () => {
        layer.innerHTML = "";
        for (let rowIndex = 0; rowIndex < rowCount; rowIndex += 1) {
          for (let colIndex = 0; colIndex < columns; colIndex += 1) {
            const descriptor = describeAuditCell(colIndex, rowIndex, naturalWidth, naturalHeight);
            if (!descriptor) {
              continue;
            }
            const cell = document.createElement("div");
            cell.className = "audit-cell";
            cell.dataset.cellId = descriptor.id;
            cell.dataset.status = descriptor.status;
            cell.style.left = `${descriptor.x}px`;
            cell.style.top = `${descriptor.y}px`;
            cell.style.width = `${descriptor.w}px`;
            cell.style.height = `${descriptor.h}px`;
            if (!state.auditMode && descriptor.w >= 64 && descriptor.h >= 28) {
              const label = document.createElement("div");
              label.className = "audit-cell__label";
              label.textContent = descriptor.label;
              cell.appendChild(label);
            }
            layer.appendChild(cell);
          }
        }
      };

      const toNormalizedPoint = (event) => {
        const rect = layer.getBoundingClientRect();
        if (!rect.width || !rect.height) {
          return null;
        }
        const localX = clamp(event.clientX - rect.left, 0, rect.width);
        const localY = clamp(event.clientY - rect.top, 0, rect.height);
        return {
          x: clamp01(localX / rect.width),
          y: clamp01(localY / rect.height)
        };
      };

      const paintCell = (cellRef) => {
        if (!cellRef) {
          return;
        }
        const status = state.auditBrush || "attention";
        const previous = currentAuditCells()[`${cellRef.colIndex}:${cellRef.rowIndex}`] || "attention";
        if (previous === status) {
          return;
        }
        syncAuditCell(cellRef.colIndex, cellRef.rowIndex, status);
        renderCells();
        renderAuditSummary();
      };

      layer.addEventListener("pointerdown", (event) => {
        if (!state.auditMode) {
          return;
        }
        const point = toNormalizedPoint(event);
        const cellRef = pointToAuditCell(point, naturalWidth, naturalHeight);
        if (!cellRef) {
          return;
        }
        auditDraft = { pointerId: event.pointerId };
        layer.setPointerCapture(event.pointerId);
        paintCell(cellRef);
        event.preventDefault();
      });

      layer.addEventListener("pointermove", (event) => {
        const point = toNormalizedPoint(event);
        const nextCell = pointToAuditCell(point, naturalWidth, naturalHeight);
        if (!state.auditMode || !auditDraft || auditDraft.pointerId !== event.pointerId) {
          return;
        }
        paintCell(nextCell);
        event.preventDefault();
      });

      const finishAudit = () => {
        auditDraft = null;
      };

      layer.addEventListener("pointerup", finishAudit);
      layer.addEventListener("pointercancel", finishAudit);
      layer.addEventListener("lostpointercapture", finishAudit);

      if (state.auditScope === "families") {
        renderFamilies();
      } else if (state.auditScope === "rows") {
        renderRows();
      } else {
        renderCells();
      }
      viewport.appendChild(layer);
    }

    function attachIssueOverlay(viewport, naturalWidth, naturalHeight) {
      if (!viewport || !Number.isFinite(naturalWidth) || !Number.isFinite(naturalHeight)) {
        return;
      }

      currentLensMetrics = {
        width: Math.max(1, Math.round(naturalWidth)),
        height: Math.max(1, Math.round(naturalHeight))
      };

      const layer = document.createElement("div");
      layer.className = `issue-interaction${state.issueMode ? " is-armed" : ""}`;
      layer.dataset.width = String(currentLensMetrics.width);
      layer.dataset.height = String(currentLensMetrics.height);

      const hud = document.createElement("div");
      hud.className = "lens-cursor-hud";

      const renderBoxes = (previewRegion = null) => {
        layer.querySelectorAll(".issue-region").forEach((node) => node.remove());
        state.issueRegions.forEach((region, index) => {
          const descriptor = describeIssueRegion(region, currentLensMetrics.width, currentLensMetrics.height);
          if (!descriptor) {
            return;
          }
          const box = document.createElement("button");
          box.type = "button";
          box.className = `issue-region ${index === state.issueActiveIndex ? "is-active" : "is-inactive"}`;
          box.dataset.issueIndex = String(index);
          box.style.left = `${descriptor.px.x}px`;
          box.style.top = `${descriptor.px.y}px`;
          box.style.width = `${descriptor.px.w}px`;
          box.style.height = `${descriptor.px.h}px`;
          const badge = document.createElement("div");
          badge.className = "issue-region__index";
          badge.textContent = `#${index + 1}`;
          const label = document.createElement("div");
          label.className = "issue-region__label";
          label.textContent = descriptor.summary;
          box.appendChild(badge);
          box.appendChild(label);
          box.addEventListener("pointerdown", (event) => {
            if (issueDraft) {
              return;
            }
            state.issueActiveIndex = index;
            syncIssueState(index);
            syncUrl();
            renderIssueSummary();
            renderBoxes();
            renderHud();
            event.stopPropagation();
          });
          layer.appendChild(box);
        });

        const draftDescriptor = describeIssueRegion(previewRegion, currentLensMetrics.width, currentLensMetrics.height);
        if (draftDescriptor) {
          const draftBox = document.createElement("div");
          draftBox.className = "issue-region is-active";
          draftBox.style.left = `${draftDescriptor.px.x}px`;
          draftBox.style.top = `${draftDescriptor.px.y}px`;
          draftBox.style.width = `${draftDescriptor.px.w}px`;
          draftBox.style.height = `${draftDescriptor.px.h}px`;
          const badge = document.createElement("div");
          badge.className = "issue-region__index";
          badge.textContent = `#${state.issueRegions.length + 1}`;
          const label = document.createElement("div");
          label.className = "issue-region__label";
          label.textContent = `${draftDescriptor.summary} / draft`;
          draftBox.appendChild(badge);
          draftBox.appendChild(label);
          layer.appendChild(draftBox);
        }
      };

      const renderHud = () => {
        const cursor = describeCursorPoint(currentLensCursor, currentLensMetrics.width, currentLensMetrics.height);
        const auditCell = describeAuditPoint(currentLensCursor, currentLensMetrics.width, currentLensMetrics.height);
        const region = describeIssueRegion(state.issueRegion, currentLensMetrics.width, currentLensMetrics.height);
        hud.innerHTML = `
          <div class="lens-cursor-hud__row">
            <code>${cursor ? escapeHtml(cursor.summary) : "Курсор: наведи на линзу"}</code>
          </div>
          <div class="lens-cursor-hud__row">
            <code>${state.auditMode
              ? escapeHtml(auditCell ? auditCell.summary : "Аудит: наведи курсор на клетку")
              : "Аудит: off"}</code>
          </div>
          <div class="lens-cursor-hud__row">
            <code>${region
              ? escapeHtml(`Зона: ${region.cells.columns} / ${region.cells.rows} / ${region.px.w}x${region.px.h}px`)
              : "Зона: не выделена"}</code>
          </div>
          <div class="lens-cursor-hud__hint">${region
            ? escapeHtml(`Коридор: top ${region.edges.top} (${region.edges.topPx}px) -> bottom ${region.edges.bottom} (${region.edges.bottomPx}px). Это помогает сверять высоту секций, seams и подложки.`)
            : "Наведи курсор для X/Y. Если нужно зафиксировать проблему по высоте или подложке, протяни рамку и получишь top/bottom вместе с row-range."}</div>
        `;
      };

      syncIssueState();
      renderBoxes();
      renderHud();

      const toNormalizedPoint = (event) => {
        const rect = layer.getBoundingClientRect();
        if (!rect.width || !rect.height) {
          return null;
        }
        const scaleX = rect.width / currentLensMetrics.width;
        const scaleY = rect.height / currentLensMetrics.height;
        if (!scaleX || !scaleY) {
          return null;
        }
        const localX = clamp(event.clientX - rect.left, 0, rect.width);
        const localY = clamp(event.clientY - rect.top, 0, rect.height);
        return {
          x: clamp01((localX / scaleX) / currentLensMetrics.width),
          y: clamp01((localY / scaleY) / currentLensMetrics.height)
        };
      };

      const toRegion = (event) => {
        const startPoint = issueDraft?.start;
        const currentPoint = toNormalizedPoint(event);
        if (!startPoint || !currentPoint) {
          return null;
        }
        return clampIssueRegion({
          x: Math.min(startPoint.x, currentPoint.x),
          y: Math.min(startPoint.y, currentPoint.y),
          w: Math.abs(currentPoint.x - startPoint.x),
          h: Math.abs(currentPoint.y - startPoint.y)
        });
      };

      const trackCursor = (event) => {
        currentLensCursor = toNormalizedPoint(event);
        renderHud();
        renderIssueSummary();
      };

      layer.addEventListener("pointerdown", (event) => {
        if (!state.issueMode) {
          return;
        }
        const start = toNormalizedPoint(event);
        if (!start) {
          return;
        }
        currentLensCursor = start;
        issueDraft = { start };
        layer.setPointerCapture(event.pointerId);
        const region = toRegion(event);
        renderBoxes(region);
        renderHud();
        event.preventDefault();
      });

      layer.addEventListener("pointermove", (event) => {
        trackCursor(event);
        if (state.issueMode && issueDraft) {
          renderBoxes(toRegion(event));
          event.preventDefault();
        }
      });

      const finishDraft = (event) => {
        if (!issueDraft) {
          return;
        }
        currentLensCursor = toNormalizedPoint(event);
        const nextRegion = toRegion(event);
        issueDraft = null;
        if (nextRegion) {
          const nextEntry = normalizeIssueEntry(nextRegion, state.issueRegions.length);
          if (nextEntry) {
            state.issueRegions = [...state.issueRegions, nextEntry];
            syncIssueState(state.issueRegions.length - 1);
          }
        }
        syncUrl();
        renderIssueSummary();
        renderBoxes();
        renderHud();
      };

      layer.addEventListener("pointerup", finishDraft);
      layer.addEventListener("pointercancel", finishDraft);
      layer.addEventListener("pointerleave", () => {
        currentLensCursor = null;
        renderHud();
        renderIssueSummary();
      });
      viewport.appendChild(hud);
      viewport.appendChild(layer);
      renderIssueSummary();
    }

    function attachWipeHandle(viewport, topLayer) {
      if (!viewport || !topLayer || state.lensId !== "wipe") {
        return null;
      }

      const handle = document.createElement("div");
      handle.className = "lens-wipe-handle";
      handle.setAttribute("role", "slider");
      handle.setAttribute("aria-label", "Разделение шторки");
      handle.setAttribute("aria-valuemin", "0");
      handle.setAttribute("aria-valuemax", "100");

      const applySplit = (nextSplit) => {
        const split = clamp(Math.round(nextSplit), 0, 100);
        state.overlaySplit = split;
        topLayer.style.clipPath = `inset(0 ${100 - split}% 0 0)`;
        handle.style.left = `${split}%`;
        handle.setAttribute("aria-valuenow", String(split));
        if (nodes.overlaySplit) {
          nodes.overlaySplit.value = String(split);
        }
        if (nodes.overlaySummary) {
          nodes.overlaySummary.textContent = `Шторка готова. Видимое разделение: ${split}%. Верхний слой: ${state.overlayTopLayerId}.`;
        }
        const splitValue = nodes.compareLensFoot?.querySelector("[data-lens-split-value]");
        if (splitValue) {
          splitValue.textContent = `${split}%`;
        }
        syncUrl();
      };

      const splitFromEvent = (event) => {
        const rect = viewport.getBoundingClientRect();
        if (!rect.width) {
          return state.overlaySplit;
        }
        return ((event.clientX - rect.left) / rect.width) * 100;
      };

      let dragPointerId = null;

      const finishDrag = () => {
        dragPointerId = null;
        handle.classList.remove("is-dragging");
      };

      handle.addEventListener("pointerdown", (event) => {
        dragPointerId = event.pointerId;
        handle.classList.add("is-dragging");
        handle.setPointerCapture(event.pointerId);
        applySplit(splitFromEvent(event));
        event.preventDefault();
      });

      handle.addEventListener("pointermove", (event) => {
        if (dragPointerId !== event.pointerId) {
          return;
        }
        applySplit(splitFromEvent(event));
        event.preventDefault();
      });

      handle.addEventListener("pointerup", (event) => {
        if (dragPointerId === event.pointerId) {
          applySplit(splitFromEvent(event));
        }
        finishDrag();
      });

      handle.addEventListener("pointercancel", finishDrag);
      handle.addEventListener("lostpointercapture", finishDrag);

      applySplit(state.overlaySplit);
      viewport.appendChild(handle);
      return handle;
    }

    function applyViewportGuides(viewport, naturalWidth, naturalHeight, extra = {}) {
      if (!viewport || !Number.isFinite(naturalWidth) || !Number.isFinite(naturalHeight)) {
        return;
      }

      clearViewportGuides(viewport);
      const showAnyGuides = state.guideGrid || state.guideSafeArea || state.guideAnchors;
      const width = Math.max(1, Math.round(naturalWidth));
      const height = Math.max(1, Math.round(naturalHeight));
      const safeInset = Math.max(16, Math.round(width * 0.04));
      const columns = clamp(state.guideColumns, 4, 24);
      const baseline = clamp(state.guideBaseline, 4, 16);
      const baselineStride = Math.max(baseline * 4, 16);

      if (showAnyGuides) {
        const overlay = document.createElement("div");
        overlay.className = "guide-overlay";
        overlay.style.width = `${width}px`;
        overlay.style.height = `${height}px`;

        if (state.guideGrid) {
          for (let idx = 1; idx < columns; idx += 1) {
            const line = document.createElement("div");
            line.className = `guide-line guide-line--vertical${idx === Math.floor(columns / 2) ? " guide-line--strong" : ""}`;
            line.style.left = `${Math.round((width / columns) * idx)}px`;
            overlay.appendChild(line);
          }

          for (let top = baselineStride; top < height; top += baselineStride) {
            const line = document.createElement("div");
            const strong = top % (baselineStride * 5) === 0;
            line.className = `guide-line guide-line--horizontal${strong ? " guide-line--strong" : ""}`;
            line.style.top = `${top}px`;
            overlay.appendChild(line);
          }

          const frame = document.createElement("div");
          frame.className = "guide-box";
          overlay.appendChild(frame);
        }

        if (state.guideIndex && !state.auditMode) {
          for (let idx = 0; idx < columns; idx += 1) {
            const chip = document.createElement("div");
            chip.className = "guide-index guide-index--column";
            chip.textContent = formatGuideColumnId(idx);
            chip.style.left = `${Math.round((width / columns) * idx + (width / columns) / 2)}px`;
            overlay.appendChild(chip);
          }

          const rowStride = baselineStride;
          for (let row = 0, top = rowStride / 2; top < height; row += 1, top += rowStride) {
            const chip = document.createElement("div");
            const isMajor = row % 5 === 0;
            chip.className = `guide-index guide-index--row ${isMajor ? "is-major" : "is-minor"}`;
            chip.textContent = formatGuideRowId(row);
            chip.style.top = `${Math.round(top)}px`;
            overlay.appendChild(chip);
          }
        }

        if (state.guideSafeArea && width > safeInset * 2 && height > safeInset * 2) {
          const box = document.createElement("div");
          box.className = "guide-box guide-box--safe";
          box.style.left = `${safeInset}px`;
          box.style.top = `${safeInset}px`;
          box.style.right = `${safeInset}px`;
          box.style.bottom = `${safeInset}px`;
          overlay.appendChild(box);
        }

        if (state.guideAnchors) {
          const points = [
            [0, 0], [0.5, 0], [1, 0],
            [0, 0.5], [0.5, 0.5], [1, 0.5],
            [0, 1], [0.5, 1], [1, 1]
          ];
          points.forEach(([xRatio, yRatio]) => {
            const dot = document.createElement("div");
            dot.className = "guide-anchor";
            dot.style.left = `${Math.round(width * xRatio)}px`;
            dot.style.top = `${Math.round(height * yRatio)}px`;
            overlay.appendChild(dot);
          });
        }

        viewport.appendChild(overlay);
      }

      const label = document.createElement("div");
      label.className = "guide-label";
      label.innerHTML = `
        <code>${extra.kind || "viewport"}</code>
        <code>${width}x${height}</code>
        <code>${columns} cols</code>
        <code>${baseline}px base</code>
        ${state.guideIndex ? `<code>index on</code>` : ""}
        ${extra.screen ? `<code>${escapeHtml(extra.screen)}</code>` : ""}
      `;
      viewport.appendChild(label);
    }

    function normalizeReferenceState(page, variant, section = null, screenSpec = null) {
      const jobs = jobsForVariant(page, variant);
      const hasExport = jobs.some((job) => job.status === "export_exists");
      const hasPending = jobs.some((job) => job.status !== "export_exists");
      const hasManifest = !!(page.manifestTitle || page.blockedReason);

      if (!section) {
        if (hasExport) return { state: "Экспорт из Figma готов", className: "is-ready", detail: "Вся страница" };
        if (hasPending) return { state: "Экспорт ожидается", className: "is-blocked", detail: "Есть export-job" };
        if (hasManifest) return { state: "Только source-contract", className: "is-danger", detail: "Нужен экспорт из Figma" };
        return { state: "Нет эталона", className: "is-danger", detail: "Reference отсутствует" };
      }

      if (hasExport && screenSpec?.spec_path) return { state: "Экран готов", className: "is-ready", detail: "Экспорт + screen spec" };
      if (hasExport) return { state: "Нужен screen spec", className: "is-blocked", detail: "Есть page export" };
      if (hasPending && screenSpec?.spec_path) return { state: "Ждёт page export", className: "is-blocked", detail: "Screen spec уже есть" };
      if (hasPending) return { state: "Ждёт export", className: "is-blocked", detail: "Нет page export" };
      if (hasManifest) return { state: "Только source-contract", className: "is-danger", detail: "Нельзя сверять без экспорта" };
      return { state: "Нет эталона", className: "is-danger", detail: "Reference отсутствует" };
    }

    function getScreenSpecEntry(indexRows, page, order) {
      return (indexRows || []).find((item) => String(item.page || "") === String(page.pageSrc.replace("_unzipped/", "")) && Number.parseInt(item.screen_order || "", 10) === Number(order || 0)) || null;
    }

    function renderReferenceInventory(page, contractPage, screenSpecIndexRows) {
      if (!nodes.referenceInventorySummary || !nodes.referenceInventoryGrid) {
        return;
      }

      const sections = Array.isArray(contractPage?.sections) ? contractPage.sections : [];
      const header = `
        <div class="reference-inventory__header">
          <div>Слот эталона</div>
          ${VARIANTS.map((variant) => `<div>${escapeHtml(variant.label)}px</div>`).join("")}
        </div>
      `;

      const pageRow = `
        <div class="reference-inventory__row">
          <div class="reference-inventory__label">
            <strong>Вся страница</strong>
            <span>Контекст страницы по каждому брейкпоинту</span>
          </div>
          ${VARIANTS.map((variant) => {
            const status = normalizeReferenceState(page, variant);
            return `
              <div class="reference-status ${status.className}">
                <strong>${escapeHtml(status.state)}</strong>
                <code>${escapeHtml(status.detail)}</code>
              </div>
            `;
          }).join("")}
        </div>
      `;

      const screenRows = sections.map((section, index) => {
        const order = Number.isFinite(Number(section?.order)) ? Number(section.order) : index + 1;
        const label = chooseScreenLabel(section, index + 1, `Section ${order}`);
        const screenSpec = getScreenSpecEntry(screenSpecIndexRows, page, order);
        return `
          <div class="reference-inventory__row">
            <div class="reference-inventory__label">
              <strong>${escapeHtml(label)}</strong>
              <span>${screenSpec?.spec_path ? "Экран / bounded compare-unit / spec привязан" : "Экран / bounded compare-unit / spec отсутствует"}</span>
            </div>
            ${VARIANTS.map((variant) => {
              const status = normalizeReferenceState(page, variant, section, screenSpec);
              return `
                <div class="reference-status ${status.className}">
                  <strong>${escapeHtml(status.state)}</strong>
                  <code>${escapeHtml(status.detail)}</code>
                </div>
              `;
            }).join("")}
          </div>
        `;
      }).join("");

      const readyPages = VARIANTS.filter((variant) => normalizeReferenceState(page, variant).className === "is-ready").length;
      const readyScreens = sections.reduce((count, section) => (
        count + VARIANTS.filter((variant) => normalizeReferenceState(page, variant, section, getScreenSpecEntry(screenSpecIndexRows, page, Number(section?.order || 0))).className === "is-ready").length
      ), 0);

      nodes.referenceInventorySummary.innerHTML = `
        <strong>${escapeHtml(page.label)}</strong>: экспорт страницы готов ${readyPages}/${VARIANTS.length},
        экранные эталоны готовы ${readyScreens}/${sections.length * VARIANTS.length || 0}.
        Если обязательный слот не готов, parity должна оставаться заблокированной.
      `;
      nodes.referenceInventoryGrid.innerHTML = header + pageRow + screenRows;
    }

    function renderGuideSummary() {
      if (!nodes.guideSummary) {
        return;
      }
      nodes.guideGrid.checked = state.guideGrid;
      nodes.guideIndex.checked = state.guideIndex;
      nodes.guideSafeArea.checked = state.guideSafeArea;
      nodes.guideAnchors.checked = state.guideAnchors;
      nodes.guideColumns.value = String(state.guideColumns);
      nodes.guideBaseline.value = String(state.guideBaseline);
      const rowStep = Math.max(state.guideBaseline * 4, 16);
      const indexText = state.guideIndex
        ? (state.auditMode ? `hidden in audit, HUD only (${rowStep}px)` : `каждая строка (${rowStep}px)`)
        : "off";
      nodes.guideSummary.textContent = `Направляющие: ${state.guideColumns} cols, baseline ${state.guideBaseline}px, Y-index ${indexText}, safe area ${state.guideSafeArea ? "on" : "off"}, anchors ${state.guideAnchors ? "on" : "off"}.`;
    }

    function currentScaleSummary() {
      const viewports = [
        nodes.referenceViewport,
        nodes.implementationViewport,
        nodes.compareLensViewport
      ].filter(Boolean);
      const scales = viewports
        .map((viewport) => Number.parseFloat(viewport.dataset.scale || ""))
        .filter((value) => Number.isFinite(value) && value > 0);
      if (!scales.length) {
        return state.pixelAuditMode ? "Pixel 1:1 включен; сцена еще не измерена." : "Обзорный режим; сцена еще не измерена.";
      }
      const minScale = Math.min(...scales);
      const scaleText = `${Math.round(minScale * 100)}%`;
      return state.pixelAuditMode
        ? `Pixel 1:1 включен: viewport без transform scale, фактический масштаб ${scaleText}.`
        : `Обзорный режим: сцена может быть уменьшена до ${scaleText}; для type/micro включай Pixel 1:1.`;
    }

    function renderPixelAuditSummary() {
      if (!nodes.pixelAuditSummary || !nodes.pixelAuditMode) {
        return;
      }
      nodes.pixelAuditMode.checked = state.pixelAuditMode;
      nodes.pixelAuditSummary.textContent = currentScaleSummary();
    }

    function currentAuditFamilies() {
      const scanDocument = boardRenderCache?.scanDocument;
      const slices = Array.isArray(scanDocument?.slices) ? scanDocument.slices : [];
      return slices.map((slice, index) => ({
        id: slice.id || `family-${index + 1}`,
        label: slice.label || `Family ${index + 1}`,
        top: Number.isFinite(slice?.implementation?.top) ? slice.implementation.top : 0,
        height: Number.isFinite(slice?.implementation?.height) ? slice.implementation.height : 0,
        role: slice.role || "content",
        order: slice.order || index + 1,
        selector: slice.selector || "",
        key: slice.key || "",
        screenName: slice.screenName || "",
        specPath: slice.specPath || "",
        primaryVerifier: slice.primaryVerifier || "",
        forbiddenReopenLayers: Array.isArray(slice.forbiddenReopenLayers) ? slice.forbiddenReopenLayers : [],
        rowBands: Array.isArray(slice.rowBands) ? slice.rowBands : []
      })).filter((item) => item.height > 0);
    }

    function ensureAuditFamilySelection() {
      const families = currentAuditFamilies();
      if (!families.length) {
        state.auditFamilyId = "";
        return;
      }
      if (!families.some((item) => item.id === state.auditFamilyId)) {
        state.auditFamilyId = families[0].id;
      }
    }

    function currentSelectedAuditFamily() {
      ensureAuditFamilySelection();
      return currentAuditFamilies().find((item) => item.id === state.auditFamilyId) || null;
    }

    function ensureAuditRowSelection() {
      const family = currentSelectedAuditFamily();
      const rows = buildAuditRowsForFamily(family);
      if (!rows.length) {
        state.auditRowId = "";
        return;
      }
      if (!rows.some((item) => item.id === state.auditRowId)) {
        state.auditRowId = rows[0].id;
      }
    }

    function currentSelectedAuditRow() {
      ensureAuditRowSelection();
      const family = currentSelectedAuditFamily();
      return buildAuditRowsForFamily(family).find((item) => item.id === state.auditRowId) || null;
    }

    function inferAuditFamilyKind(family) {
      const text = [
        family?.id || "",
        family?.key || "",
        family?.label || "",
        family?.selector || "",
        family?.screenName || ""
      ].join(" ").toLowerCase();
      if (/hero|header|apn-hero/.test(text)) {
        return "hero_shell";
      }
      if (/faq|answer/.test(text)) {
        return "accordion_stack";
      }
      if (/love|online psychics|clients|reviews|reasons|catalog|cards|psychics|apn-love|apn-online|apn-clients|apn-reasons|apn-faq/.test(text)) {
        return "repeated_card_lane";
      }
      if (/proof|quote|learn more|video|neuro/.test(text)) {
        return "content_corridor";
      }
      if (/footer/.test(text)) {
        return "footer";
      }
      return "generic_section";
    }

    function buildVerifierDescriptor(key) {
      const map = {
        issue_handoff: {
          id: "issue_handoff",
          label: "Issue handoff",
          script: "build_issue_handoff.py",
          path: "H:\\GPT-Codex\\tools\\nebula-audit-factory\\build_issue_handoff.py",
          reason: "Сначала преврати bounded проблему в repair packet, чтобы не потерять scope."
        },
        geometry: {
          id: "geometry",
          label: "Geometry",
          script: "measure_live_breakpoint_geometry.py",
          path: "H:\\GPT-Codex\\tools\\nebula-audit-factory\\measure_live_breakpoint_geometry.py",
          reason: "Используй для seam, высоты, регистраций и shell drift."
        },
        identity: {
          id: "identity",
          label: "Section identity",
          script: "verify_live_section_identity.py",
          path: "H:\\GPT-Codex\\tools\\nebula-audit-factory\\verify_live_section_identity.py",
          reason: "Используй, когда repeated content может маскировать не ту family."
        },
        tiles: {
          id: "tiles",
          label: "Section tile drift",
          script: "scan_section_tile_drift.py",
          path: "H:\\GPT-Codex\\tools\\nebula-audit-factory\\scan_section_tile_drift.py",
          reason: "Используй для локализации visual drift внутри bounded corridor."
        },
        markup: {
          id: "markup",
          label: "Real markup",
          script: "verify_real_markup.py",
          path: "H:\\GPT-Codex\\tools\\nebula-audit-factory\\verify_real_markup.py",
          reason: "Используй для проверки, что live DOM действительно соответствует макетной модели, а не surrogate-структуре."
        },
        asset_origin: {
          id: "asset_origin",
          label: "Asset origin",
          script: "verify_real_markup.py",
          path: "H:\\GPT-Codex\\tools\\nebula-audit-factory\\verify_real_markup.py",
          reason: "Используй для проверки surrogate assets, fill model и совпадения live-asset с Figma truth."
        },
        clusters: {
          id: "clusters",
          label: "Cell clusters",
          script: "extract_cell_clusters.py",
          path: "H:\\GPT-Codex\\tools\\nebula-audit-factory\\extract_cell_clusters.py",
          reason: "Используй только на micro-слое, когда выше уже закрыто и нужен surgical cluster."
        }
      };
      return map[key] || null;
    }

    const DETERMINISTIC_ROUTE_POLICY_MAP = {
      surface: {
        rows: {
          top_seam: "surface_seam_geometry",
          cta_bottom: "surface_seam_geometry",
          next_seam: "surface_seam_geometry",
          default: "surface_plane_tiles"
        },
        families: {
          default: "surface_plane_tiles"
        },
        cells: {
          default: "surface_plane_tiles"
        }
      },
      shell: {
        rows: {
          default: "shell_geometry"
        },
        families: {
          default: "shell_geometry"
        },
        cells: {
          default: "shell_geometry"
        }
      },
      identity: {
        rows: {
          default: "identity_generic_section"
        },
        families: {
          repeated_card_lane: "identity_repeated_card_lane",
          accordion_stack: "identity_repeated_card_lane",
          default: "identity_generic_section"
        },
        cells: {
          default: "identity_generic_section"
        }
      },
      asset: {
        rows: {
          default: "asset_origin_check"
        },
        families: {
          default: "asset_origin_check"
        },
        cells: {
          default: "asset_origin_check"
        }
      },
      type: {
        rows: {
          default: "type_tile_drift"
        },
        families: {
          default: "type_tile_drift"
        },
        cells: {
          default: "type_tile_drift"
        }
      },
      micro: {
        rows: {
          default: "micro_cluster_extract"
        },
        families: {
          default: "micro_cluster_extract"
        },
        cells: {
          default: "micro_cluster_extract"
        }
      }
    };

    function buildDeterministicRoutePolicy(policyId) {
      const policyMap = {
        surface_seam_geometry: {
          id: "surface_seam_geometry",
          source: "layer_row_band_contract",
          primary: buildVerifierDescriptor("geometry"),
          secondary: [buildVerifierDescriptor("tiles"), buildVerifierDescriptor("markup")],
          rationale: ["Surface-first seam contract: top/bottom seam и CTA corridor сначала доказываются геометрией, потом tiles/markup."]
        },
        surface_plane_tiles: {
          id: "surface_plane_tiles",
          source: "layer_scope_contract",
          primary: buildVerifierDescriptor("tiles"),
          secondary: [buildVerifierDescriptor("geometry"), buildVerifierDescriptor("markup")],
          rationale: ["Surface plane contract: underlay, planes и section background сначала локализуются section tiles, не typography."]
        },
        shell_geometry: {
          id: "shell_geometry",
          source: "layer_scope_contract",
          primary: buildVerifierDescriptor("geometry"),
          secondary: [buildVerifierDescriptor("markup"), buildVerifierDescriptor("tiles")],
          rationale: ["Shell contract: width, height, track mode и row registration фиксируются геометрией."]
        },
        identity_repeated_card_lane: {
          id: "identity_repeated_card_lane",
          source: "layer_family_kind_contract",
          primary: buildVerifierDescriptor("identity"),
          secondary: [buildVerifierDescriptor("markup"), buildVerifierDescriptor("tiles")],
          rationale: ["Identity contract for repeated lanes: сначала проверь правильную family/sequence, потом DOM model и corridor drift."]
        },
        identity_generic_section: {
          id: "identity_generic_section",
          source: "layer_scope_contract",
          primary: buildVerifierDescriptor("identity"),
          secondary: [buildVerifierDescriptor("tiles"), buildVerifierDescriptor("markup")],
          rationale: ["Identity-before-spacing: сначала докажи, что секция правильная, а не похожий surrogate-блок."]
        },
        asset_origin_check: {
          id: "asset_origin_check",
          source: "layer_scope_contract",
          primary: buildVerifierDescriptor("asset_origin"),
          secondary: [buildVerifierDescriptor("identity"), buildVerifierDescriptor("markup")],
          rationale: ["Asset-before-type: exact asset origin и fill model должны быть доказаны до typography и micro."]
        },
        type_tile_drift: {
          id: "type_tile_drift",
          source: "layer_scope_contract",
          primary: buildVerifierDescriptor("tiles"),
          secondary: [buildVerifierDescriptor("markup"), buildVerifierDescriptor("geometry")],
          rationale: ["Type contract: bounded text drift локализуется tiles-first только после закрытия higher layers."]
        },
        micro_cluster_extract: {
          id: "micro_cluster_extract",
          source: "layer_scope_contract",
          primary: buildVerifierDescriptor("clusters"),
          secondary: [buildVerifierDescriptor("tiles"), buildVerifierDescriptor("geometry")],
          rationale: ["Micro contract: surgical cluster extraction допустим только как последний verifier pass."]
        }
      };
      return policyMap[policyId] || null;
    }

    function getScopeRoutePolicy(scope, layerId, familyKind, rowId) {
      const layerMap = DETERMINISTIC_ROUTE_POLICY_MAP[layerId] || DETERMINISTIC_ROUTE_POLICY_MAP.micro;
      if (scope === "rows") {
        return layerMap.rows?.[rowId] || layerMap.rows?.default || null;
      }
      if (scope === "families") {
        return layerMap.families?.[familyKind] || layerMap.families?.default || null;
      }
      return layerMap.cells?.default || null;
    }

    function normalizeFamilyPreferredVerifierKey(family) {
      const key = String(family?.primaryVerifier || "").trim().toLowerCase();
      return key || "";
    }

    function resolveDeterministicAuditRoutePolicy(layerId, scope, familyKind, rowId, family) {
      const policyId = getScopeRoutePolicy(scope, layerId, familyKind, rowId);
      const policy = buildDeterministicRoutePolicy(policyId);
      const familyPreferredVerifier = normalizeFamilyPreferredVerifierKey(family);
      return {
        policyId: policy?.id || "",
        policySource: policy?.source || "unresolved",
        familyPreferredVerifier,
        routeMatrixVersion: 1,
        policy
      };
    }

    function getCurrentAuditTargetRecord() {
      const entry = currentAuditEntry();
      if (!entry) {
        return null;
      }
      if (state.auditScope === "families") {
        const family = currentSelectedAuditFamily();
        return family ? entry.families?.[family.id] || null : null;
      }
      if (state.auditScope === "rows") {
        const family = currentSelectedAuditFamily();
        const row = currentSelectedAuditRow();
        return family && row ? entry.rows?.[family.id]?.[row.id] || null : null;
      }
      return null;
    }

    function getAuditLayerBlockers(layerId = state.auditLayerId) {
      const targetRecord = getCurrentAuditTargetRecord();
      const layerIndex = AUDIT_LAYER_ORDER.indexOf(layerId);
      if (!targetRecord || layerIndex <= 0) {
        return [];
      }
      return AUDIT_LAYER_ORDER
        .slice(0, layerIndex)
        .map((id) => ({
          id,
          label: AUDIT_LAYER_META[id].label,
          status: getStoredAuditLayerStatus(targetRecord, id) || "attention"
        }))
        .filter((item) => item.status !== "pass");
    }

    function currentAuditTargetStatus() {
      if (state.auditScope === "families") {
        const family = currentSelectedAuditFamily();
        return family ? currentAuditFamilyStatus(family.id) : "attention";
      }
      if (state.auditScope === "rows") {
        const family = currentSelectedAuditFamily();
        const row = currentSelectedAuditRow();
        return family && row ? currentAuditRowStatus(family.id, row.id) : "attention";
      }
      const entry = currentAuditEntry();
      const counts = getAuditCounts(entry);
      if (counts.in_progress) {
        return "in_progress";
      }
      if (counts.pass && !counts.attention) {
        return "pass";
      }
      return "attention";
    }

    function buildAuditRoute() {
      const family = currentSelectedAuditFamily();
      const row = currentSelectedAuditRow();
      const issuePayload = buildIssuePayload();
      const familyKind = inferAuditFamilyKind(family);
      const status = currentAuditTargetStatus();
      const requestedLayer = currentAuditLayerMeta();
      const blockers = getAuditLayerBlockers(requestedLayer.id);
      const targetLabel = state.auditScope === "families"
        ? (family?.label || "family не выбрана")
        : state.auditScope === "rows"
          ? `${family?.label || "family не выбрана"} / ${row?.label || "строка не выбрана"}`
          : (issuePayload
            ? `bounded issue ${issuePayload.grid?.columns || ""} / ${issuePayload.grid?.rows || ""}`.trim()
            : `${family?.label || "текущий экран"} / cell sweep`);
      const route = {
        scope: state.auditScope,
        status,
        targetLabel,
        familyId: family?.id || "",
        familyLabel: family?.label || "",
        familyKind,
        rowId: row?.id || "",
        rowLabel: row?.label || "",
        requestedLayerId: requestedLayer.id,
        requestedLayerLabel: requestedLayer.label,
        layerId: requestedLayer.id,
        layerLabel: requestedLayer.label,
        blockedByLayers: blockers,
        policyId: "",
        policySource: "",
        decisionKey: "",
        routeMatrixVersion: 1,
        familyPreferredVerifier: normalizeFamilyPreferredVerifierKey(family),
        issueBounded: !!issuePayload,
        primary: null,
        secondary: [],
        preflight: [],
        rationale: []
      };

      if (issuePayload) {
        route.preflight.push(buildVerifierDescriptor("issue_handoff"));
        route.rationale.push("Есть bounded issue-zone: сначала нужен handoff artifact, потом verifier.");
      }

      if (blockers.length) {
        const blocker = blockers[0];
        const blockedRoute = resolveDeterministicAuditRoutePolicy(blocker.id, state.auditScope, familyKind, row?.id || "", family);
        route.layerId = blocker.id;
        route.layerLabel = blocker.label;
        route.policyId = blockedRoute.policyId;
        route.policySource = blockedRoute.policySource;
        route.decisionKey = `${state.auditScope}:${blocker.id}:${familyKind || "generic"}:${row?.id || "default"}`;
        route.routeMatrixVersion = blockedRoute.routeMatrixVersion;
        route.familyPreferredVerifier = blockedRoute.familyPreferredVerifier;
        route.primary = blockedRoute.policy?.primary || null;
        route.secondary = blockedRoute.policy?.secondary || [];
        route.rationale.push(`MRI lock: вход в ${requestedLayer.label} запрещён, пока выше есть red/yellow. Сначала закрой ${blockers.map((item) => `${item.label}=${item.status}`).join(", ")}.`);
        route.rationale.push(...(blockedRoute.policy?.rationale || []));
      } else {
        const selectedRoute = resolveDeterministicAuditRoutePolicy(requestedLayer.id, state.auditScope, familyKind, row?.id || "", family);
        route.policyId = selectedRoute.policyId;
        route.policySource = selectedRoute.policySource;
        route.decisionKey = `${state.auditScope}:${requestedLayer.id}:${familyKind || "generic"}:${row?.id || "default"}`;
        route.routeMatrixVersion = selectedRoute.routeMatrixVersion;
        route.familyPreferredVerifier = selectedRoute.familyPreferredVerifier;
        route.primary = selectedRoute.policy?.primary || null;
        route.secondary = selectedRoute.policy?.secondary || [];
        route.rationale.push(...(selectedRoute.policy?.rationale || []));
      }

      route.commands = [...route.preflight, route.primary, ...route.secondary]
        .filter(Boolean)
        .map((item) => `python ${item.path}`);
      return route;
    }

    function serializeAuditRoute() {
      const route = buildAuditRoute();
      if (!route) {
        return null;
      }
      return {
        family: state.familyId,
        page: state.pageId,
        variant: state.variantId,
        mode: state.modeId,
        screen: state.screenId,
        lens: state.lensId,
        auditScope: state.auditScope,
        auditLayer: state.auditLayerId,
        auditFamily: state.auditFamilyId,
        auditRow: state.auditRowId,
        route,
        link: currentDeepLink()
      };
    }

    function buildAuditHandoffPayload() {
      const audit = serializeAudit();
      const route = serializeAuditRoute();
      const regressionGate = buildAuditLockGatePayload();
      if (!audit || !route) {
        return null;
      }
      return {
        audit,
        route,
        regressionGate,
        issue: buildIssuePayload(),
        doneWhen: route.route.scope === "families"
          ? "Выбранная family перестала быть red/yellow и получила retained verifier proof."
          : route.route.scope === "rows"
            ? "Выбранная row-band удержана без reopening соседних полос."
            : "Bounded cell/corridor закрыт и не требует family-wide blind pass.",
        verifyWith: route.route.commands
      };
    }

    function buildAuditLockTargetDescriptor(routePayload = serializeAuditRoute()) {
      const route = routePayload?.route;
      if (!route) {
        return null;
      }
      const scope = route.scope || state.auditScope;
      const familyId = route.familyId || "";
      const rowId = route.rowId || "";
      const layerId = route.layerId || state.auditLayerId;
      const targetKey = scope === "families"
        ? `families:${familyId}:${layerId}`
        : scope === "rows"
          ? `rows:${familyId}:${rowId}:${layerId}`
          : `cells:${familyId || "page"}:${rowId || "grid"}:${layerId}`;
      return {
        scope,
        familyId,
        familyLabel: route.familyLabel || "",
        rowId,
        rowLabel: route.rowLabel || "",
        layerId,
        layerLabel: route.layerLabel || "",
        targetLabel: route.targetLabel || "",
        targetKey
      };
    }

    function currentAuditTargetRetainedMetrics(entry = currentAuditEntry(), layerId = state.auditLayerId) {
      return {
        cellCounts: getAuditCounts(entry, layerId),
        familyCounts: getAuditFamilyCounts(entry, layerId),
        rowCounts: getAuditRowCounts(entry, layerId)
      };
    }

    function buildAuditLockPayload() {
      const routePayload = serializeAuditRoute();
      const route = routePayload?.route;
      const target = buildAuditLockTargetDescriptor(routePayload);
      if (!route || !target) {
        return null;
      }
      if (route.blockedByLayers?.length || route.status !== "pass") {
        return null;
      }
      const entry = currentAuditEntry();
      const timestamp = new Date().toISOString();
      return {
        lock_version: 1,
        created_at: timestamp,
        updated_at: timestamp,
        family: state.familyId,
        page: state.pageId,
        variant: state.variantId,
        mode: state.modeId,
        screen: state.screenId,
        scope: target.scope,
        layer: target.layerId,
        layerLabel: target.layerLabel,
        targetKey: target.targetKey,
        targetLabel: target.targetLabel,
        familyId: target.familyId,
        familyLabel: target.familyLabel,
        rowId: target.rowId,
        rowLabel: target.rowLabel,
        proof: {
          deepLink: currentDeepLink(),
          routePolicyId: route.policyId || "",
          routePolicySource: route.policySource || "",
          decisionKey: route.decisionKey || "",
          issueBounded: !!route.issueBounded
        },
        verifier: route.primary
          ? {
            id: route.primary.id,
            label: route.primary.label,
            script: route.primary.script,
            path: route.primary.path
          }
          : null,
        retained_metrics: currentAuditTargetRetainedMetrics(entry, target.layerId)
      };
    }

    function currentAuditLockEntry(routePayload = serializeAuditRoute()) {
      const target = buildAuditLockTargetDescriptor(routePayload);
      const scopeEntry = currentAuditLockScopeEntry();
      if (!target || !scopeEntry?.targets) {
        return null;
      }
      return scopeEntry.targets[target.targetKey] || null;
    }

    function lockOverlapsRoute(lockEntry, route) {
      if (!lockEntry || !route) {
        return false;
      }
      if (lockEntry.familyId && route.familyId && lockEntry.familyId !== route.familyId) {
        return false;
      }
      if (route.scope === "families") {
        return lockEntry.familyId === route.familyId;
      }
      if (route.scope === "rows") {
        return lockEntry.familyId === route.familyId && (!lockEntry.rowId || lockEntry.rowId === route.rowId);
      }
      return lockEntry.familyId === route.familyId && (!lockEntry.rowId || lockEntry.rowId === route.rowId);
    }

    function getAffectedAuditLocks(routePayload = serializeAuditRoute()) {
      const route = routePayload?.route;
      const scopeEntry = currentAuditLockScopeEntry();
      if (!route || !scopeEntry?.targets) {
        return [];
      }
      return Object.values(scopeEntry.targets).filter((lockEntry) => lockOverlapsRoute(lockEntry, route));
    }

    function buildAuditLockGatePayload() {
      const routePayload = serializeAuditRoute();
      const route = routePayload?.route;
      if (!route) {
        return null;
      }
      const affectedLocks = getAffectedAuditLocks(routePayload);
      const commands = affectedLocks
        .map((lockEntry) => lockEntry.verifier?.path ? `python ${lockEntry.verifier.path}` : "")
        .filter(Boolean);
      return {
        family: state.familyId,
        page: state.pageId,
        variant: state.variantId,
        mode: state.modeId,
        screen: state.screenId,
        target: buildAuditLockTargetDescriptor(routePayload),
        affectedLocks,
        verifyWith: commands,
        regressionGate: {
          affectedLockCount: affectedLocks.length,
          rerunOnlyAffected: true
        },
        link: currentDeepLink()
      };
    }

    function buildCurrentAuditLockFilePayload() {
      const scopeEntry = currentAuditLockScopeEntry();
      return {
        contract_version: 1,
        generated_at: new Date().toISOString(),
        family: state.familyId,
        page: state.pageId,
        variant: state.variantId,
        mode: state.modeId,
        screen: state.screenId,
        locks: Object.values(scopeEntry?.targets || {})
      };
    }

    function buildMetricsTargetKey(scope, familyId, rowId, layerId) {
      return scope === "families"
        ? `families:${familyId}:${layerId}`
        : scope === "rows"
          ? `rows:${familyId}:${rowId}:${layerId}`
          : `cells:${familyId || "page"}:${rowId || "grid"}:${layerId}`;
    }

    function recordWrongLayerEntryAttempt(requestedLayerId, blockers = []) {
      const metrics = ensureAuditMetricsScopeEntry();
      metrics.wrongLayerEntries.attempts += 1;
      if (blockers.length) {
        metrics.wrongLayerEntries.blocked += 1;
      }
      saveAuditMetricsStore();
    }

    function recordAuditTargetStatus(scope, familyId, rowId, layerId, status) {
      const metrics = ensureAuditMetricsScopeEntry();
      const familyKey = familyId || "page";
      const targetKey = buildMetricsTargetKey(scope, familyId, rowId, layerId);
      const familyCounter = ensureCountMapValue(metrics.passesByFamily, familyKey);
      const trialCounter = ensureCountMapValue(metrics.contourTrials, targetKey);
      if (status === "pass") {
        familyCounter.pass += 1;
        trialCounter.pass += 1;
      } else if (status === "attention" || status === "in_progress") {
        familyCounter.fail += 1;
        trialCounter.fail += 1;
      }
      const lockEntry = currentAuditLockScopeEntry()?.targets?.[targetKey];
      if (lockEntry && status !== "pass") {
        const regressionCounter = ensureCountMapValue(metrics.regressionsByLock, targetKey);
        regressionCounter.regressions += 1;
        trialCounter.regressions += 1;
      }
      saveAuditMetricsStore();
    }

    function getWrongLayerEntryRate(metrics = currentAuditMetricsScopeEntry()) {
      const attempts = Number(metrics?.wrongLayerEntries?.attempts || 0);
      const blocked = Number(metrics?.wrongLayerEntries?.blocked || 0);
      if (!attempts) {
        return 0;
      }
      return blocked / attempts;
    }

    function buildStopRuleSignals(routePayload = serializeAuditRoute(), metrics = currentAuditMetricsScopeEntry()) {
      const route = routePayload?.route;
      if (!route) {
        return [];
      }
      const targetKey = buildMetricsTargetKey(route.scope, route.familyId, route.rowId, route.layerId);
      const trialCounter = metrics?.contourTrials?.[targetKey] || { fail: 0 };
      const signals = [];
      if ((trialCounter.fail || 0) >= 2) {
        signals.push({
          id: "two_failed_trials_same_contour",
          label: "2 failed trials in same contour",
          action: "extract clusters or escalate layer diagnosis"
        });
      }
      if (route.requestedLayerId === "type" && route.blockedByLayers?.some((item) => item.id === "asset")) {
        signals.push({
          id: "asset_failure_blocks_type",
          label: "asset failure blocks typography",
          action: "resolve asset-origin before typography"
        });
      }
      if (route.requestedLayerId === "type" && route.blockedByLayers?.some((item) => item.id === "identity")) {
        signals.push({
          id: "identity_failure_blocks_spacing",
          label: "identity failure blocks spacing",
          action: "resolve family identity before typography/spacing"
        });
      }
      return signals;
    }

    function buildAuditMetricsPayload(routePayload = serializeAuditRoute()) {
      const metrics = currentAuditMetricsScopeEntry();
      const route = routePayload?.route || null;
      const stopRules = buildStopRuleSignals(routePayload, metrics);
      return {
        contract_version: 1,
        generated_at: new Date().toISOString(),
        family: state.familyId,
        page: state.pageId,
        variant: state.variantId,
        mode: state.modeId,
        screen: state.screenId,
        passesPerFamily: metrics?.passesByFamily || {},
        regressionsPerLock: metrics?.regressionsByLock || {},
        wrongLayerEntry: {
          attempts: Number(metrics?.wrongLayerEntries?.attempts || 0),
          blocked: Number(metrics?.wrongLayerEntries?.blocked || 0),
          rate: getWrongLayerEntryRate(metrics)
        },
        contourTrials: metrics?.contourTrials || {},
        stopRules,
        route: route,
        link: currentDeepLink()
      };
    }

    function buildCurrentAuditMetricsFilePayload() {
      const payload = buildAuditMetricsPayload();
      return {
        contract_version: 1,
        generated_at: new Date().toISOString(),
        family: state.familyId,
        page: state.pageId,
        variant: state.variantId,
        mode: state.modeId,
        screen: state.screenId,
        metrics: payload
      };
    }

    function buildAuditRowsForFamily(family) {
      if (!family || !family.height) {
        return [];
      }
      const total = family.height;
      const bands = Array.isArray(family.rowBands) && family.rowBands.length
        ? family.rowBands
        : [
          { id: "top_seam", label: "Top seam", ratio: 0.08 },
          { id: "head", label: "Head", ratio: 0.18 },
          { id: "content_core", label: "Content core", ratio: 0.46 },
          { id: "cta_bottom", label: "CTA / bottom", ratio: 0.18 },
          { id: "next_seam", label: "Next seam", ratio: 0.10 }
        ];
      let cursor = family.top;
      return bands.map((band, index) => {
        const isLast = index === bands.length - 1;
        const height = isLast
          ? Math.max(1, Math.round(family.top + total - cursor))
          : Math.max(1, Math.round(total * band.ratio));
        const row = {
          id: band.id,
          label: band.label,
          top: Math.round(cursor),
          height
        };
        cursor += height;
        return row;
      });
    }

    function renderAuditBrushes() {
      if (!nodes.auditBrushes) {
        return;
      }
      const brushes = [
        { id: "pass", label: "Зелёный", help: "Отметить выбранный audit target как совпадающий с эталоном." },
        { id: "in_progress", label: "Жёлтый", help: "Отметить target как спорный: есть риск, частичный drift или нужна ручная проверка." },
        { id: "attention", label: "Красный", help: "Отметить target как дефект, который нужно исправить до lock." }
      ];
      nodes.auditBrushes.innerHTML = brushes.map((brush) => `
        <button
          type="button"
          class="chip is-audit-brush${state.auditBrush === brush.id ? " is-active" : ""}"
          data-brush="${escapeHtml(brush.id)}"
          title="${escapeHtml(brush.help)}"
          aria-label="${escapeHtml(`${brush.label}: ${brush.help}`)}"
        >${escapeHtml(brush.label)}</button>
      `).join("");
      nodes.auditBrushes.querySelectorAll("[data-brush]").forEach((button) => {
        button.addEventListener("click", () => {
          state.auditBrush = button.dataset.brush || "attention";
          renderAuditBrushes();
          renderAuditSummary();
          renderCompareLens(boardRenderCache);
        });
      });
    }

    function renderAuditLayers() {
      if (!nodes.auditLayerChips) {
        return;
      }
      const layers = AUDIT_LAYER_ORDER.map((id) => AUDIT_LAYER_META[id]);
      renderChipGroup(nodes.auditLayerChips, layers, state.auditLayerId, (id) => {
        const blockers = getAuditLayerBlockers(id);
        recordWrongLayerEntryAttempt(id, blockers);
        state.auditLayerId = id;
        syncUrl();
        renderAuditSummary();
        renderCompareLens(boardRenderCache);
      });
    }

    function renderAuditScopes() {
      if (!nodes.auditScopeChips) {
        return;
      }
      const scopes = [
        { id: "families", label: "Семейства", help: "Крупный проход по секциям страницы: hero, cards, FAQ, footer и т.п." },
        { id: "rows", label: "Строки", help: "Проверка выбранной секции по вертикальным bands: top/head/core/CTA/seam." },
        { id: "cells", label: "Клетки", help: "Точная локализация дефекта по сетке и baseline." }
      ];
      renderChipGroup(nodes.auditScopeChips, scopes, state.auditScope, (id) => {
        state.auditScope = id;
        if (id !== "cells") {
          ensureAuditFamilySelection();
          ensureAuditRowSelection();
        }
        syncUrl();
        renderAuditSummary();
        renderCompareLens(boardRenderCache);
      });
    }

    function renderAuditFamilies() {
      if (!nodes.auditFamilyChips) {
        return;
      }
      const families = currentAuditFamilies();
      if (!families.length || state.auditScope === "cells") {
        nodes.auditFamilyChips.innerHTML = "";
        return;
      }
      ensureAuditFamilySelection();
      nodes.auditFamilyChips.innerHTML = families.map((family) => {
        const status = currentAuditFamilyStatus(family.id);
        const active = state.auditFamilyId === family.id ? " is-active" : "";
        const help = `${family.label}: выбрать секцию как target для row/family audit.`;
        return `<button type="button" class="chip${active}" data-audit-family="${escapeHtml(family.id)}" data-status="${escapeHtml(status)}" title="${escapeHtml(help)}" aria-label="${escapeHtml(help)}">${escapeHtml(family.label)}</button>`;
      }).join("");
      nodes.auditFamilyChips.querySelectorAll("[data-audit-family]").forEach((button) => {
        button.addEventListener("click", () => {
          state.auditFamilyId = button.dataset.auditFamily || "";
          state.auditRowId = "";
          syncUrl();
          renderAuditSummary();
          renderCompareLens(boardRenderCache);
        });
      });
    }

    function renderMacroGateBrushes() {
      if (!nodes.macroBrushes) {
        return;
      }
      const brushes = [
        { id: "pass", label: "Зелёный", help: "Macro check совпадает, можно двигаться глубже." },
        { id: "in_progress", label: "Жёлтый", help: "Macro check спорный или частично проверен." },
        { id: "attention", label: "Красный", help: "Macro check сломан, детальный аудит пока рискован." }
      ];
      nodes.macroBrushes.innerHTML = brushes.map((brush) => `
        <button
          type="button"
          class="chip is-audit-brush${state.macroBrush === brush.id ? " is-active" : ""}"
          data-macro-brush="${escapeHtml(brush.id)}"
          data-brush="${escapeHtml(brush.id)}"
          title="${escapeHtml(brush.help)}"
          aria-label="${escapeHtml(`${brush.label}: ${brush.help}`)}"
        >${escapeHtml(brush.label)}</button>
      `).join("");
      nodes.macroBrushes.querySelectorAll("[data-macro-brush]").forEach((button) => {
        button.addEventListener("click", () => {
          state.macroBrush = button.dataset.macroBrush || "attention";
          renderMacroGateBrushes();
        });
      });
    }

    function renderMacroGateChecks() {
      if (!nodes.macroGateChecks) {
        return;
      }
      const entry = currentMacroGateEntry();
      nodes.macroGateChecks.innerHTML = MACRO_GATE_CHECKS.map((check) => {
        const status = isAuditStatusValue(entry?.checks?.[check.id]) ? entry.checks[check.id] : "missing";
        return `<button type="button" class="chip is-macro-check" data-macro-check="${escapeHtml(check.id)}" data-status="${escapeHtml(status)}" title="${escapeHtml(check.help)}" aria-label="${escapeHtml(`${check.label}: ${check.help}`)}">${escapeHtml(check.label)}</button>`;
      }).join("");
      nodes.macroGateChecks.querySelectorAll("[data-macro-check]").forEach((button) => {
        button.addEventListener("click", () => {
          const checkId = button.dataset.macroCheck || "";
          if (!state.macroGateMode || !checkId) {
            return;
          }
          const current = currentMacroGateStatus(checkId);
          const next = current === state.macroBrush ? "clear" : state.macroBrush;
          setMacroGateStatus(checkId, next);
          syncUrl();
          renderMacroGateSummary();
          renderAuditSummary();
          updateFocusBar();
        });
      });
    }

    function renderMacroGateSummary() {
      if (!nodes.macroGateSummary || !nodes.macroGateMode || !nodes.copyMacroGateBtn || !nodes.clearMacroGateBtn) {
        return;
      }
      nodes.macroGateMode.checked = !!state.macroGateMode;
      renderMacroGateBrushes();
      renderMacroGateChecks();
      const entry = currentMacroGateEntry();
      const summary = summarizeMacroGate(entry);
      const totalChecked = summary.pass + summary.in_progress + summary.attention;
      nodes.copyMacroGateBtn.disabled = !entry || !totalChecked;
      nodes.clearMacroGateBtn.disabled = !entry || !totalChecked;
      if (state.macroGateMode) {
        const blockersText = summary.blockers.length ? ` Блокеры: ${summary.blockers.join(", ")}.` : "";
        nodes.macroGateSummary.textContent = summary.blocked
          ? `Macro Gate armed. Кисть: ${state.macroBrush === "pass" ? "зелёный" : state.macroBrush === "in_progress" ? "жёлтый" : "красный"}. Pass ${summary.pass}, yellow ${summary.in_progress}, red ${summary.attention}, missing ${summary.missing}. Deep audit blocked, пока весь macro-shell не станет green.${blockersText}`
          : `Macro Gate complete. Все ${summary.total} экранных checks зелёные, deep audit разрешён.`;
      } else if (entry && totalChecked) {
        nodes.macroGateSummary.textContent = summary.blocked
          ? `Macro Gate сохранён: pass ${summary.pass}, yellow ${summary.in_progress}, red ${summary.attention}, missing ${summary.missing}. Deep audit пока blocked.`
          : `Macro Gate сохранён: все ${summary.total} checks green, можно идти в глубокий аудит.`;
      } else {
        nodes.macroGateSummary.textContent = "Выключено. Включи Macro Gate и быстро отметь shell, surface и ключевые экранные оси до family/cell аудита.";
      }
    }

    function renderAuditSummary() {
      if (!nodes.auditSummary || !nodes.auditMode || !nodes.copyAuditBtn || !nodes.copyAuditRouteBtn || !nodes.copyAuditHandoffBtn || !nodes.clearAuditBtn || !nodes.auditRoutingSummary || !nodes.lockAuditTargetBtn || !nodes.copyLockGateBtn || !nodes.copyLockFileBtn || !nodes.clearAuditLockBtn || !nodes.copyMetricsBtn || !nodes.auditMetricsSummary) {
        return;
      }
      nodes.auditMode.checked = !!state.auditMode;
      const macroSummary = summarizeMacroGate();
      nodes.auditMode.disabled = macroSummary.blocked && !state.auditMode;
      renderAuditScopes();
      renderAuditLayers();
      renderAuditBrushes();
      renderAuditFamilies();
      ensureAuditRowSelection();
      const entry = currentAuditEntry();
      const layer = currentAuditLayerMeta();
      const counts = getAuditCounts(entry, state.auditLayerId);
      const familyCounts = getAuditFamilyCounts(entry, state.auditLayerId);
      const rowCounts = getAuditRowCounts(entry, state.auditLayerId);
      const totalMarked = counts.pass + counts.in_progress + counts.attention;
      const totalFamilies = familyCounts.pass + familyCounts.in_progress + familyCounts.attention;
      const totalRows = rowCounts.pass + rowCounts.in_progress + rowCounts.attention;
      nodes.copyAuditBtn.disabled = !entry || !(totalMarked || totalFamilies || totalRows);
      const hasFamilyState = !!Object.keys(entry?.families || {}).length;
      const hasRowState = !!Object.keys(entry?.rows || {}).length;
      nodes.clearAuditBtn.disabled = !entry || (!Object.keys(entry?.cells || {}).length && !hasFamilyState && !hasRowState);
      const family = currentSelectedAuditFamily();
      const row = currentSelectedAuditRow();
      const route = serializeAuditRoute();
      const routePrimary = route?.route?.primary;
      const routePreflight = route?.route?.preflight?.length ? route.route.preflight[0] : null;
      const routeSecondary = route?.route?.secondary?.filter(Boolean) || [];
      const lockEntry = currentAuditLockEntry(route);
      const lockGate = buildAuditLockGatePayload();
      const affectedLockCount = lockGate?.affectedLocks?.length || 0;
      const metricsPayload = buildAuditMetricsPayload(route);
      const stopRules = metricsPayload?.stopRules || [];
      nodes.copyAuditRouteBtn.disabled = !route;
      nodes.copyAuditHandoffBtn.disabled = !route || (!entry && !state.issueRegions.length);
      nodes.lockAuditTargetBtn.disabled = !route || route.route.status !== "pass" || !!route.route.blockedByLayers?.length;
      nodes.copyLockGateBtn.disabled = !route;
      nodes.copyLockFileBtn.disabled = !currentAuditLockScopeEntry();
      nodes.clearAuditLockBtn.disabled = !lockEntry;
      nodes.copyMetricsBtn.disabled = !metricsPayload;
      if (macroSummary.blocked && !state.auditMode) {
        nodes.auditSummary.textContent = `MRI audit заблокирован Macro Gate. Сначала cheap-pass по экрану: pass ${macroSummary.pass}, yellow ${macroSummary.in_progress}, red ${macroSummary.attention}, missing ${macroSummary.missing}.`;
      } else if (state.auditMode) {
        const scopeText = state.auditScope === "families"
          ? `scope=семейства, слой=${layer.label}, зелёных family ${familyCounts.pass}, жёлтых ${familyCounts.in_progress}, красных ${familyCounts.attention}`
          : state.auditScope === "rows"
            ? `scope=строки, слой=${layer.label}, family=${family ? family.label : "не выбрана"}, row=${row ? row.label : "не выбрана"}`
            : `scope=клетки, слой=${layer.label}, зелёных ${counts.pass}, жёлтых ${counts.in_progress}, красных ${counts.attention}`;
        const lockText = lockEntry ? ` Lock=${lockEntry.layerLabel} @ ${lockEntry.targetLabel}.` : "";
        nodes.auditSummary.textContent = `MRI audit armed. Кисть: ${state.auditBrush === "pass" ? "зелёный" : state.auditBrush === "in_progress" ? "жёлтый" : "красный"}. ${scopeText}. Непомеченные области считаются красной зоной до проверки, а нижний слой запрещён, пока верхний не green.${lockText}`;
      } else if (entry && (totalMarked || totalFamilies || totalRows)) {
        if (totalFamilies && !totalMarked) {
          nodes.auditSummary.textContent = `MRI state сохранён: слой ${layer.label}, family pass ${familyCounts.pass}, in_progress ${familyCounts.in_progress}, attention ${familyCounts.attention}.`;
        } else {
          nodes.auditSummary.textContent = `MRI state сохранён: слой ${layer.label}, зелёных ${counts.pass}, жёлтых ${counts.in_progress}, красных ${counts.attention}. Включи аудит, чтобы продолжить проход.`;
        }
      } else if (entry && hasFamilyState) {
        nodes.auditSummary.textContent = `MRI state сохранён: слой ${layer.label}, family pass ${familyCounts.pass}, in_progress ${familyCounts.in_progress}, attention ${familyCounts.attention}.`;
      } else {
        nodes.auditSummary.textContent = "Выключено. Включи аудит, выбери MRI-слой и отметь статус проверки по family/row/cell.";
      }
      if (!route || !routePrimary) {
        nodes.auditRoutingSummary.textContent = "MRI routing появится после выбора family, строки или bounded issue-зоны.";
        return;
      }
      const preflightText = routePreflight ? `Сначала ${routePreflight.label}. ` : "";
      const secondaryText = routeSecondary.length ? ` Затем ${routeSecondary.map((item) => item.label).join(" -> ")}.` : "";
      const lockText = route.route.blockedByLayers?.length
        ? ` MRI lock: requested ${route.route.requestedLayerLabel}, но следующий допустимый слой ${route.route.layerLabel}.`
        : "";
      const policyText = route.route.policyId
        ? ` Policy=${route.route.policyId} (${route.route.policySource}), key=${route.route.decisionKey}.`
        : "";
      const positiveLockText = lockEntry
        ? ` Positive lock active: ${lockEntry.layerLabel} / ${lockEntry.targetLabel}.`
        : "";
      const regressionText = affectedLockCount
        ? ` Regression gate: затронуто lock-зон ${affectedLockCount}, rerun only affected verifiers.`
        : " Regression gate: затронутых lock-зон пока нет.";
      nodes.auditRoutingSummary.textContent = `Следующий verifier: ${routePrimary.label} (${routePrimary.script}) для ${route.route.targetLabel}. Layer=${route.route.layerLabel}. Статус: ${route.route.status}.${lockText}${policyText}${positiveLockText} ${preflightText}${routePrimary.reason}${secondaryText}${regressionText}`;
      const wrongLayerRate = Number(metricsPayload?.wrongLayerEntry?.rate || 0);
      const stopRuleText = stopRules.length
        ? ` Stop-rules: ${stopRules.map((item) => `${item.label} -> ${item.action}`).join(" | ")}.`
        : "";
      nodes.auditMetricsSummary.textContent = `Wave 6: wrong-layer rate ${wrongLayerRate.toFixed(2)}, blocked ${metricsPayload?.wrongLayerEntry?.blocked || 0}/${metricsPayload?.wrongLayerEntry?.attempts || 0}, families tracked ${Object.keys(metricsPayload?.passesPerFamily || {}).length}, lock regressions ${Object.keys(metricsPayload?.regressionsPerLock || {}).length}.${stopRuleText}`;
    }

    function getIssueProgress(result, diagnosis, queue) {
      const stateValue = queue.state || (result.status === "ready" ? "verify" : "open");
      const priorityValue = queue.priority || "normal";
      const blocked = priorityValue === "blocked" || stateValue === "blocked" || Number(diagnosis.missing_font_count || 0) > 0;
      const stages = [
        { key: "captured", label: "Зона" },
        { key: "diagnosed", label: "Диагностика" },
        { key: "queued", label: "Очередь" },
        { key: "in_progress", label: "В работе" },
        { key: "fixed", label: "Fixed" },
        { key: "verified", label: "Verified" }
      ];
      const stateIndex = {
        open: 2,
        verify: 2,
        in_progress: 3,
        fixed: 4,
        verified: 5,
        rejected: 2,
        blocked: Math.max(2, queue.previous_state === "in_progress" ? 3 : 2)
      };
      const activeIndex = stateIndex[stateValue] ?? 2;
      const percent = Math.round((activeIndex / (stages.length - 1)) * 100);
      const stageLabel = stateValue === "in_progress" && blocked
        ? "В работе, есть блокер"
        : stateValue === "open"
          ? "Готово к доработке"
          : stateValue === "verify"
            ? "Ждет проверки"
            : stateValue;
      const eta = stateValue === "verified"
        ? "Готово"
        : stateValue === "fixed"
          ? "5-10 мин на финальную проверку"
          : stateValue === "in_progress" && blocked
            ? "Принято в доработку; блокер разбирается в рамках ремонта"
            : stateValue === "in_progress"
              ? "Принято в доработку; идет repair/verify цикл"
              : blocked
                ? "Готово к отправке на доработку"
                : "Готово к отправке на доработку";
      const blockerNote = blocked
        ? `Блокер: ${Number(diagnosis.missing_font_count || 0) ? "есть отсутствующий/неподтвержденный font" : "priority=blocked"}. Это не ожидание в очереди: блокер уходит в работу вместе с задачей.`
        : "Блокеров по runner-диагностике нет; дальше идет обычный repair/verify цикл.";
      return { stages, activeIndex, percent, stateValue, priorityValue, stageLabel, eta, blocked, blockerNote };
    }

    function renderIssueProgress(result, diagnosis, queue) {
      const progress = getIssueProgress(result, diagnosis, queue);
      const stepsHtml = progress.stages.map((stage, index) => {
        const cls = [
          "issue-progress__step",
          index <= progress.activeIndex ? "is-done" : "",
          index === progress.activeIndex ? "is-active" : ""
        ].filter(Boolean).join(" ");
        return `<div class="${cls}"><i class="issue-progress__dot" aria-hidden="true"></i><span>${escapeHtml(stage.label)}</span></div>`;
      }).join("");
      return `
        <div class="issue-progress ${progress.blocked ? "is-blocked" : ""}" style="--issue-progress:${progress.percent}%">
          <div class="issue-progress__header">
            <div>Стадия: <strong>${escapeHtml(progress.stageLabel)}</strong></div>
            <div>Оценка: <strong>${escapeHtml(progress.eta)}</strong></div>
            <div>State / priority: <strong>${escapeHtml(`${progress.stateValue} / ${progress.priorityValue}`)}</strong></div>
          </div>
          <div class="issue-progress__bar" aria-label="Issue progress"><i class="issue-progress__fill"></i></div>
          <div class="issue-progress__steps">${stepsHtml}</div>
          <div class="issue-progress__note">${escapeHtml(progress.blockerNote)}</div>
        </div>
      `;
    }

    function renderIssueCheckResult(result) {
      if (!nodes.issueResultPanel) {
        return;
      }
      if (!result) {
        nodes.issueResultPanel.classList.remove("is-visible");
        nodes.issueResultPanel.innerHTML = "";
        return;
      }
      const diagnosis = result.diagnosis || {};
      const artifacts = result.artifacts || {};
      const task = result.repair_task || {};
      const queue = result.queue_item || {};
      const caster = result.caster || task.assistants?.caster || queue.assistants?.caster || {};
      const scope = task.scope || {};
      const nextActions = (diagnosis.next_actions || task.next_actions || []).slice(0, 3);
      const progressHtml = renderIssueProgress(result, diagnosis, queue);
      const actionHtml = nextActions.length
        ? `<div class="issue-result__cell" style="grid-column:1/-1"><span>Next</span><strong>${escapeHtml(nextActions.join(" / "))}</strong></div>`
        : "";
      nodes.issueResultPanel.classList.add("is-visible");
      nodes.issueResultPanel.innerHTML = `
        ${progressHtml}
        <div class="issue-result__cell"><span>Status</span><strong>${escapeHtml(result.status || "unknown")}</strong></div>
        <div class="issue-result__cell"><span>Layer</span><strong>${escapeHtml(diagnosis.recommended_layer || scope.recommended_layer || "unknown")}</strong></div>
        <div class="issue-result__cell"><span>Text / Fonts / DOM</span><strong>${escapeHtml(`${diagnosis.text_node_count ?? "n/a"} / ${diagnosis.missing_font_count ?? "n/a"} / ${diagnosis.live_dom_candidate_count ?? "n/a"}`)}</strong></div>
        <div class="issue-result__cell"><span>Queue</span><strong>${escapeHtml(`${queue.state || "n/a"} / ${queue.priority || "n/a"}`)}</strong></div>
        <div class="issue-result__cell"><span>Family</span><strong>${escapeHtml(diagnosis.defect_family || scope.defect_family || "unknown")}</strong></div>
        <div class="issue-result__cell"><span>Caster gate</span><strong>${caster.required ? "expert verdict required" : "optional"}</strong></div>
        <div class="issue-result__cell" style="grid-column:1/-1"><span>Artifacts</span><code title="${escapeHtml(result.issue_dir || "")}">${escapeHtml(result.issue_dir || "")}</code></div>
        ${artifacts.repair_task_md ? `<div class="issue-result__cell" style="grid-column:1/-1"><span>Repair task</span><code title="${escapeHtml(artifacts.repair_task_md)}">${escapeHtml(artifacts.repair_task_md)}</code></div>` : ""}
        ${artifacts.caster_task_md ? `<div class="issue-result__cell" style="grid-column:1/-1"><span>Caster task</span><code title="${escapeHtml(artifacts.caster_task_md)}">${escapeHtml(artifacts.caster_task_md)}</code></div>` : ""}
        ${artifacts.queue_item ? `<div class="issue-result__cell" style="grid-column:1/-1"><span>Queue item</span><code title="${escapeHtml(artifacts.queue_item)}">${escapeHtml(artifacts.queue_item)}</code></div>` : ""}
        ${actionHtml}
        <div class="issue-result__actions">
          <button type="button" class="chip" data-issue-action="copy-task">Копировать repair task</button>
          <button type="button" class="chip" data-issue-action="copy-caster">Копировать Caster verdict task</button>
          <button type="button" class="chip" data-issue-action="copy-queue">Копировать queue item</button>
          <button type="button" class="chip" data-issue-action="copy-result">Копировать result JSON</button>
          <button type="button" class="chip" data-issue-action="set-state" data-state="in_progress">Отправить на доработку</button>
          <button type="button" class="chip" data-issue-action="set-state" data-state="fixed">Fixed</button>
          <button type="button" class="chip" data-issue-action="set-state" data-state="verified">Verified</button>
        </div>
      `;
    }

    async function setIssueQueueState(result, nextState, note, actor = "compare-board") {
      const queue = result?.queue_item || {};
      const issueId = result?.issue_id || queue.issue_id || "";
      if (!issueId || !nextState) {
        throw new Error("нет issue_id или target state");
      }
      const response = await fetch("http://127.0.0.1:4176/oracle/issues/queue/update", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          issue_id: issueId,
          state: nextState,
          page: result.page || queue.page || "",
          variant: result.variant || queue.variant || "",
          actor,
          note
        })
      });
      const payload = await response.json();
      if (!response.ok) {
        throw new Error(payload?.error || `HTTP ${response.status}`);
      }
      result.queue_item = payload.item || result.queue_item;
      return result.queue_item;
    }

    async function sendIssueToRepair(result) {
      const stateValue = result?.queue_item?.state || "";
      if (!result || ["in_progress", "fixed", "verified"].includes(stateValue)) {
        return false;
      }
      await setIssueQueueState(result, "in_progress", "Auto-send to repair after compare-board check", "compare-board");
      return true;
    }

    function renderIssueSummary() {
      if (!nodes.issueSummary || !nodes.issueMode || !nodes.copyIssueBtn || !nodes.clearIssueBtn || !nodes.removeIssueBtn || !nodes.runIssueCheckBtn || !nodes.downloadIssueBtn) {
        return;
      }
      nodes.issueMode.checked = !!state.issueMode;
      syncIssueState();
      const descriptor = describeIssueRegion(state.issueRegion, currentLensMetrics?.width, currentLensMetrics?.height);
      const lensReady = !!currentLensMetrics;
      const cursor = describeCursorPoint(currentLensCursor, currentLensMetrics?.width, currentLensMetrics?.height);
      nodes.issueMode.disabled = !lensReady && !state.issueMode;
      nodes.runIssueCheckBtn.disabled = !state.issueRegions.length;
      nodes.copyIssueBtn.disabled = !state.issueRegions.length;
      nodes.downloadIssueBtn.disabled = !state.issueRegions.length;
      nodes.clearIssueBtn.disabled = !state.issueRegions.length;
      nodes.removeIssueBtn.disabled = state.issueActiveIndex < 0;
      nodes.copyIssueBtn.textContent = state.issueRegions.length > 1 ? "Копировать зоны" : "Копировать зону";
      if (!lensReady && !descriptor) {
        nodes.issueSummary.textContent = "Режим проблемной зоны доступен в Наложении или Шторке, когда линза сравнения уже собрана.";
        return;
      }
      if (!descriptor) {
        nodes.issueSummary.textContent = state.issueMode
          ? (cursor
            ? `${cursor.summary}. Протяни рамку в линзе, чтобы зафиксировать bounded зону с top/bottom и шириной/высотой.`
            : "Режим включён. Наведи курсор для X/Y или протяни рамку в линзе, чтобы зафиксировать bounded зону.")
          : (cursor
            ? `${cursor.summary}. Включи режим и протяни рамку, если нужно сохранить проблему как bounded artifact.`
            : "Выключено. Включи режим и протяни рамку в линзе сравнения, чтобы зафиксировать проблемную область.");
        return;
      }
      const countText = state.issueRegions.length > 1
        ? `Активная зона #${state.issueActiveIndex + 1} из ${state.issueRegions.length}. `
        : "";
      nodes.issueSummary.textContent = `${countText}Зона: ${descriptor.summary}. Границы: left ${descriptor.edges.left} (${descriptor.edges.leftPx}px), right ${descriptor.edges.right} (${descriptor.edges.rightPx}px), top ${descriptor.edges.top} (${descriptor.edges.topPx}px), bottom ${descriptor.edges.bottom} (${descriptor.edges.bottomPx}px). Клик по рамке делает её активной, копирование отдаёт весь bundle зон.`;
    }

    function slugify(value) {
      return String(value || "")
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, "-")
        .replace(/^-+|-+$/g, "") || "screen";
    }

    function trimLabel(value, max = 48) {
      const text = String(value || "").replace(/\s+/g, " ").trim();
      if (text.length <= max) {
        return text;
      }
      return `${text.slice(0, max - 1).trimEnd()}…`;
    }

    function normalizeClassTokens(value) {
      return String(value || "")
        .split(/\s+/)
        .map((token) => token.trim().toLowerCase())
        .filter(Boolean);
    }

    function chooseScreenLabel(section, index, fallbackLabel = "") {
      const headings = normalizeItems(section && section.headings);
      const firstHeading = headings.find(Boolean);
      if (firstHeading) {
        return `${String(index + 1).padStart(2, "0")} ${trimLabel(firstHeading)}`;
      }

      const classTokens = normalizeClassTokens(section && section.section_class);
      const joined = classTokens.join(" ");
      const rules = [
        { test: /hero/, label: "Hero" },
        { test: /grid/, label: "Grid" },
        { test: /plain/, label: "Overview" },
        { test: /columns/, label: "Columns" },
        { test: /cta|banner|offer/, label: "CTA" },
        { test: /review|trust/, label: "Reviews / Trust" },
        { test: /faq/, label: "FAQ" },
        { test: /expert/, label: "Experts" },
        { test: /topic/, label: "Topic block" },
        { test: /card/, label: "Cards" }
      ];

      const matched = rules.find((rule) => rule.test.test(joined));
      if (matched) {
        return `${String(index + 1).padStart(2, "0")} ${matched.label}`;
      }

      if (fallbackLabel) {
        return `${String(index + 1).padStart(2, "0")} ${trimLabel(fallbackLabel.replace(/^\d+\s+/, ""))}`;
      }

      if (section && section.section_class) {
        return `${String(index + 1).padStart(2, "0")} ${trimLabel(section.section_class.replace(/[-_]+/g, " "))}`;
      }

      return `${String(index + 1).padStart(2, "0")} Section`;
    }

    function humanizeSectionLabel(section, index) {
      return chooseScreenLabel(section, index);
    }

    function buildSelectorFromSectionClass(value) {
      const tokens = String(value || "")
        .split(/\s+/)
        .map((token) => token.trim())
        .filter(Boolean)
        .map((token) => token.replace(/^[.#]/, ""))
        .filter(Boolean);

      if (!tokens.length) {
        return "";
      }

      return `.${tokens.join(".")}`;
    }

    function effectiveScrollRoot(doc) {
      if (!doc || !doc.documentElement || !doc.body) {
        return null;
      }

      const candidates = [
        doc.scrollingElement,
        doc.documentElement,
        doc.body
      ].filter(Boolean);

      return candidates.reduce((best, item) => {
        if (!best) {
          return item;
        }
        const bestHeight = Math.max(best.scrollHeight || 0, best.offsetHeight || 0);
        const itemHeight = Math.max(item.scrollHeight || 0, item.offsetHeight || 0);
        return itemHeight > bestHeight ? item : best;
      }, null);
    }

    function scrollRootLabel(doc, root) {
      if (!root) {
        return "unknown";
      }
      if (root === doc.body) {
        return "body";
      }
      if (root === doc.documentElement) {
        return "documentElement";
      }
      if (root === doc.scrollingElement) {
        return "scrollingElement";
      }
      return root.tagName ? root.tagName.toLowerCase() : "custom";
    }

    function rectFromElement(doc, element) {
      if (!element) {
        return null;
      }

      const root = effectiveScrollRoot(doc) || doc.scrollingElement || doc.documentElement || doc.body;
      const view = doc.defaultView || window;
      const top = element.getBoundingClientRect().top + (root.scrollTop || view.pageYOffset || 0);
      const height = Math.max(element.getBoundingClientRect().height, element.offsetHeight || 0, 120);

      if (!Number.isFinite(top) || !Number.isFinite(height) || height <= 0) {
        return null;
      }

      return { top, height };
    }

    function collectFallbackSections(doc) {
      const selectors = [
        "main > section",
        "main > article",
        "main > div > section",
        "main > div > article",
        "section",
        "article"
      ];
      const seen = new Set();
      const sections = [];

      selectors.forEach((selector) => {
        doc.querySelectorAll(selector).forEach((element) => {
          if (seen.has(element)) {
            return;
          }
          seen.add(element);
          const rect = rectFromElement(doc, element);
          if (!rect || rect.height < 140) {
            return;
          }
          const heading = element.querySelector("h1, h2, h3, h4");
          sections.push({
            id: `screen-${sections.length + 1}`,
            label: `${String(sections.length + 1).padStart(2, "0")} ${heading ? heading.textContent.trim() : (element.className || "Section")}`,
            top: rect.top,
            height: rect.height
          });
        });
      });

      return sections
        .sort((a, b) => a.top - b.top)
        .slice(0, 12);
    }

    function takeFallbackSection(fallbackSections, usedIndexes, preferredIndex) {
      if (!fallbackSections.length) {
        return null;
      }

      if (Number.isInteger(preferredIndex) && preferredIndex >= 0 && preferredIndex < fallbackSections.length && !usedIndexes.has(preferredIndex)) {
        usedIndexes.add(preferredIndex);
        return fallbackSections[preferredIndex];
      }

      const nextIndex = fallbackSections.findIndex((_, index) => !usedIndexes.has(index));
      if (nextIndex === -1) {
        return null;
      }

      usedIndexes.add(nextIndex);
      return fallbackSections[nextIndex];
    }

    function extractScreenOptions(doc, sourceSpec, pageHeight) {
      const options = [defaultScreenOption()];
      const usedElements = new Set();
      const fallbackSections = collectFallbackSections(doc);
      const usedFallbackIndexes = new Set();

      if (sourceSpec && Array.isArray(sourceSpec.sections) && sourceSpec.sections.length) {
        sourceSpec.sections.forEach((section, index) => {
          let element = null;
          const selector = buildSelectorFromSectionClass(section.section_class);
          if (selector) {
            element = doc.querySelector(`main ${selector}`) || doc.querySelector(selector);
          }

          if (element && usedElements.has(element)) {
            element = null;
          }

          if (element) {
            usedElements.add(element);
          }

          let rect = rectFromElement(doc, element);
          const fallbackSection = !rect ? takeFallbackSection(fallbackSections, usedFallbackIndexes, index) : null;
          if (!rect && fallbackSection) {
            rect = { top: fallbackSection.top, height: fallbackSection.height };
          }
          const label = chooseScreenLabel(section, index, fallbackSection ? fallbackSection.label : "");
          const screen = {
            id: `screen-${section.order || index + 1}-${slugify(label)}`,
            label,
            kind: "section",
            sourceSectionOrder: section.order || index + 1,
            top: rect ? rect.top : null,
            height: rect ? rect.height : null,
            topRatio: rect ? clamp(rect.top / pageHeight, 0, 1) : null,
            heightRatio: rect ? clamp(rect.height / pageHeight, 0.08, 1) : null
          };
          options.push(screen);
        });
      }

      if (options.length === 1) {
        fallbackSections.forEach((section) => {
          options.push({
            id: section.id,
            label: trimLabel(section.label),
            kind: "section",
            top: section.top,
            height: section.height,
            topRatio: clamp(section.top / pageHeight, 0, 1),
            heightRatio: clamp(section.height / pageHeight, 0.08, 1)
          });
        });
      }

      return options.sort((a, b) => {
        if (a.id === "full-page") {
          return -1;
        }
        if (b.id === "full-page") {
          return 1;
        }
        if (Number.isFinite(a.top) && Number.isFinite(b.top)) {
          return a.top - b.top;
        }
        return (a.sourceSectionOrder || 999) - (b.sourceSectionOrder || 999);
      });
    }

    function extractAuditFamilies(doc, familyRegistryEntry, pageHeight) {
      const families = Array.isArray(familyRegistryEntry?.families) ? familyRegistryEntry.families : [];
      if (!families.length) {
        return [];
      }

      const usedElements = new Set();
      const fallbackSections = collectFallbackSections(doc);
      const usedFallbackIndexes = new Set();

      return families.map((family, index) => {
        let element = null;
        const selector = family.selector || buildSelectorFromSectionClass(family.screen_name || "");
        if (selector) {
          element = doc.querySelector(`main ${selector}`) || doc.querySelector(selector);
        }

        if (element && usedElements.has(element)) {
          element = null;
        }
        if (element) {
          usedElements.add(element);
        }

        let rect = rectFromElement(doc, element);
        const fallbackSection = !rect ? takeFallbackSection(fallbackSections, usedFallbackIndexes, index) : null;
        if (!rect && fallbackSection) {
          rect = { top: fallbackSection.top, height: fallbackSection.height };
        }

        return {
          id: family.id || `family-${index + 1}`,
          key: family.key || family.id || "",
          label: family.label || family.key || `Family ${index + 1}`,
          selector,
          specPath: family.spec_path || "",
          screenName: family.screen_name || "",
          primaryVerifier: family.primary_verifier || "",
          forbiddenReopenLayers: Array.isArray(family.forbidden_reopen_layers) ? family.forbidden_reopen_layers : [],
          rowBands: Array.isArray(family.row_bands) ? family.row_bands : [],
          order: Number(family.order) || index + 1,
          top: rect ? rect.top : null,
          height: rect ? rect.height : null,
          topRatio: rect ? clamp(rect.top / pageHeight, 0, 1) : null,
          heightRatio: rect ? clamp(rect.height / pageHeight, 0.02, 1) : null
        };
      }).filter((item) => Number.isFinite(item.top) && Number.isFinite(item.height));
    }

    function normalizeScreenChoice(options) {
      const valid = options.some((item) => item.id === state.screenId);
      if (!valid) {
        state.screenId = options[0] ? options[0].id : "full-page";
      }
      if (state.modeId === "page") {
        state.screenId = "full-page";
      }
    }

    function updateNavigatorUi() {
      const page = currentPage();
      const variant = currentVariant();
      const options = currentScreenOptions();
      const currentIndex = Math.max(0, options.findIndex((item) => item.id === state.screenId));
      const current = options[currentIndex] || defaultScreenOption();
      const screenMode = state.modeId === "screen";
      const pageMode = !screenMode || current.id === "full-page";
      const screenCompareReady = hasVisualScreenCompare(page, variant);

      nodes.prevScreenBtn.disabled = !screenMode || !screenCompareReady || currentIndex <= 0;
      nodes.nextScreenBtn.disabled = !screenMode || !screenCompareReady || currentIndex >= options.length - 1;
      nodes.prevScreenBtn.classList.toggle("is-disabled", nodes.prevScreenBtn.disabled);
      nodes.nextScreenBtn.classList.toggle("is-disabled", nodes.nextScreenBtn.disabled);

      if (!screenCompareReady) {
        nodes.screenSummary.textContent = "Сравнение по экранам отключено: для этого брейкпоинта нет реального PNG-эталона.";
      } else {
        nodes.screenSummary.textContent = pageMode
          ? `Режим страницы. Для этой страницы найдено ${Math.max(options.length - 1, 0)} валидных экранных слотов.`
          : `Экран ${currentIndex} из ${Math.max(options.length - 1, 1)}: ${current.label}`;
      }

      nodes.deepLinkField.value = currentDeepLink();
      nodes.overlayOpacity.value = String(state.overlayOpacity);
      nodes.overlaySplit.value = String(state.overlaySplit);
      nodes.overlayOpacity.disabled = state.lensId === "split";
      nodes.overlaySplit.disabled = state.lensId !== "wipe";
      nodes.screenRow.classList.toggle("is-hidden", !screenCompareReady || state.modeId !== "screen");
      nodes.lensControlsRow.classList.toggle("is-hidden", state.lensId === "split");
      nodes.reviewStage.dataset.lens = state.lensId;
      updateFocusBar();
    }

    function renderLinkMatrix() {
      const page = currentPage();
      const variant = currentVariant();
      const screen = currentScreenOption();
      const links = [];

      links.push({
        label: "Текущая страница",
        href: buildDeepLink({ mode: "page", screen: "full-page" })
      });

      if (hasVisualScreenCompare(page, variant) && screen && screen.id !== "full-page") {
        links.push({
          label: `Текущий экран`,
          href: buildDeepLink({ mode: "screen", screen: screen.id })
        });
      }

      VARIANTS.forEach((variant) => {
        links.push({
          label: `${variant.label} страница`,
          href: buildDeepLink({ variant: variant.id, mode: "page", screen: "full-page" })
        });
      });

      if (hasVisualScreenCompare(page, variant) && screen && screen.id !== "full-page") {
        VARIANTS.forEach((variant) => {
          links.push({
            label: `${variant.label} экран`,
            href: buildDeepLink({ variant: variant.id, mode: "screen", screen: screen.id })
          });
        });
      }

      nodes.linkMatrix.innerHTML = links
        .map((item) => `<a class="link-chip" href="${escapeHtml(item.href)}">${escapeHtml(item.label)}</a>`)
        .join("");
    }

    function summarizePageSourceStatus(page) {
      const jobs = Array.isArray(page.jobs) ? page.jobs : [];
      const exportJobs = jobs.filter((job) => job.status === "export_exists");
      const pendingJobs = jobs.filter((job) => job.status !== "export_exists");

      if (exportJobs.length && pendingJobs.length) {
        return {
          label: "экспорт частично готов",
          className: "route-status is-partial"
        };
      }

      if (exportJobs.length) {
        return {
          label: "экспорт из Figma готов",
          className: "route-status is-export"
        };
      }

      if (pendingJobs.length) {
        return {
          label: "экспорт ожидается",
          className: "route-status is-pending"
        };
      }

      return {
        label: "blocker: только source-contract",
        className: "route-status is-danger"
      };
    }

    function summarizeVariantSourceStatus(page, variant) {
      const exportJobs = exportJobsForVariant(page, variant);
      const pendingJobs = jobsForVariant(page, variant).filter((job) => job.status !== "export_exists");

      if (exportJobs.length && pendingJobs.length) {
        return {
          label: "Эталон частично готов",
          badgeClass: "focus-pill is-warn",
          note: "У этого брейкпоинта есть реальный source PNG, но не весь responsive set закрыт."
        };
      }
      if (exportJobs.length) {
        return {
          label: "Эталон готов",
          badgeClass: "focus-pill is-good",
          note: "Визуальное сравнение по source/live доступно."
        };
      }
      if (pendingJobs.length) {
        return {
          label: "Экспорт ожидается",
          badgeClass: "focus-pill is-warn",
          note: "Для этого брейкпоинта source PNG еще не доступен."
        };
      }
      return {
        label: "Только source-contract",
        badgeClass: "focus-pill is-muted",
        note: "Есть только structural fallback, без реального export PNG."
      };
    }

    function updateFocusBar() {
      const page = currentPage();
      const variant = currentVariant();
      const screen = currentScreenOption();
      const sourceState = summarizeVariantSourceStatus(page, variant);
      const screenReady = hasVisualScreenCompare(page, variant);
      const isScreenMode = state.modeId === "screen" && screenReady && screen && screen.id !== "full-page";
      const compareScope = isScreenMode ? screen.label : "Вся страница";
      const lensLabel = COMPARE_LENSES.find((item) => item.id === state.lensId)?.label || state.lensId;
      const macroSummary = summarizeMacroGate();
      const macroPill = macroSummary.blocked
        ? {
            label: `Macro blocked ${macroSummary.pass}/${macroSummary.total}`,
            className: "focus-pill is-warn"
          }
        : {
            label: `Macro green ${macroSummary.total}/${macroSummary.total}`,
            className: "focus-pill is-good"
          };

      nodes.focusTitle.textContent = `${page.label} / ${variant.label}px / ${compareScope}`;
      nodes.focusText.textContent = screenReady
        ? (state.lensId === "split"
          ? "Сначала сравни обе панели глазами. Если нужно поймать точные сдвиги, переключись на Наложение или Шторку."
          : `Сейчас активен ${lensLabel}. Используй его для точной проверки отступов, размеров и несовпадений.`)
        : "Для этого состояния нет реального PNG-эталона, поэтому панель честно ограничивает visual compare и не показывает ложное наложение.";

      const pills = [
        { label: sourceState.label, className: sourceState.badgeClass },
        { label: `${state.modeId === "screen" && screenReady ? "Режим экрана" : "Режим страницы"}`, className: "focus-pill" },
        { label: `${lensLabel}`, className: "focus-pill" },
        { label: state.pixelAuditMode ? "Pixel 1:1" : "Scaled overview", className: state.pixelAuditMode ? "focus-pill is-good" : "focus-pill is-warn" },
        macroPill,
        { label: screenReady ? "Визуальное proof доступно" : "Визуального proof нет", className: screenReady ? "focus-pill is-good" : "focus-pill is-warn" }
      ];
      nodes.focusPills.innerHTML = pills.map((item) => `<span class="${item.className}">${escapeHtml(item.label)}</span>`).join("");
    }

    function renderReviewRoutes() {
      const recoveryGroup = buildRecoveryRouteGroup();
      const groups = recoveryGroup ? [recoveryGroup, ...REVIEW_ROUTE_FAMILIES] : REVIEW_ROUTE_FAMILIES.slice();

      nodes.reviewRouteGroups.innerHTML = groups.map((group) => {
        const isRecoveryGroup = group.id === "__recovery_priority__";
        const family = !isRecoveryGroup ? findFamily(group.id) : null;
        if (!isRecoveryGroup && !family) {
          return "";
        }

        const rows = group.pages
          .map((entry) => {
          const familyId = entry.familyId || group.id;
          const page = findPage(familyId, entry.pageId);
          if (!page) {
            return null;
          }

          const status = summarizePageSourceStatus(page);
          const locatorEntry = getLocatorEntry(sourceLocatorData || { pages: [] }, page);
          const variantIds = Array.isArray(entry.variants) && entry.variants.length ? entry.variants : ["1200"];
          const variantLinks = variantIds.map((variantId) => {
            const variant = VARIANTS.find((item) => item.id === variantId);
            if (!variant) {
              return "";
            }
            return `<a class="link-chip" href="${escapeHtml(buildDeepLink({ family: familyId, page: entry.pageId, variant: variant.id, mode: "page", screen: "full-page" }))}">${escapeHtml(`${variant.label} страница`)}</a>`;
          }).join("");

          const preferredScreenVariant = variantIds.find((variantId) => canOpenScreenFlow(page, variantId)) || null;
          const screenEntry = preferredScreenVariant
            ? `<a class="link-chip" href="${escapeHtml(buildDeepLink({ family: familyId, page: entry.pageId, variant: preferredScreenVariant, mode: "screen", screen: "full-page" }))}">поток экранов</a>`
            : `<span class="route-status is-danger">поток экранов заблокирован</span>`;
          const recoveryLane = !pageHasAnyRealSource(page)
            ? `<a class="link-chip" href="${escapeHtml(buildDeepLink({ family: familyId, page: entry.pageId, variant: variantIds[0], mode: "page", screen: "full-page" }))}">контур восстановления</a>`
            : "";
          const signalChip = !pageHasAnyRealSource(page) && locatorEntry
            ? `<span class="route-status is-manifest">${escapeHtml(locatorSignalLabel(locatorEntry.signal_level))}</span>`
            : "";
          const recoveryBlock = !pageHasAnyRealSource(page) && locatorEntry
            ? `
              <div class="route-recovery">
                <div><strong>Причина блокировки</strong></div>
                <div>${escapeHtml((locatorEntry.blocked_by || []).join(" ") || page.blockedReason || "Экспорт из Figma пока не зафиксирован.")}</div>
                ${locatorEntry.next_recovery_action ? `<div><strong>Следующий шаг</strong> <code>${escapeHtml(locatorEntry.next_recovery_action)}</code></div>` : ""}
              </div>
            `
            : "";

          return {
            order: isRecoveryGroup ? group.pages.findIndex((item) => item.pageId === entry.pageId && (item.familyId || group.id) === familyId) : null,
            priority: pageSourcePriority(page),
            label: page.label,
            html: `
              <div class="route-row">
                <div class="route-title">${escapeHtml(page.label)}</div>
                <span class="${status.className}">${escapeHtml(status.label)}</span>
                ${signalChip}
                ${variantLinks}
                ${screenEntry}
                ${recoveryLane}
                ${recoveryBlock}
              </div>
            `
          };
        })
          .filter(Boolean)
          .sort((a, b) => {
            if (isRecoveryGroup) {
              return (a.order ?? 999) - (b.order ?? 999);
            }
            return a.priority - b.priority || String(a.label).localeCompare(String(b.label));
          })
          .map((item) => item.html)
          .join("");

        return `
          <article class="route-card">
            <h3>${escapeHtml(group.label)}</h3>
            <p>${escapeHtml(group.text)}</p>
            <div class="route-stack">${rows}</div>
          </article>
        `;
      }).join("");
    }

    function loadImageCandidate(paths) {
      return new Promise((resolve, reject) => {
        const candidates = paths.slice();

        function tryNext() {
          const next = candidates.shift();
          if (!next) {
            reject(new Error("no existing source export found"));
            return;
          }

          const img = new Image();
          const url = resolveUrl(next);
          img.onload = () => resolve({ path: next, url, width: img.naturalWidth, height: img.naturalHeight });
          img.onerror = () => tryNext();
          img.src = url;
        }

        tryNext();
      });
    }

    function loadSourceContract() {
      if (!sourceContractPromise) {
        sourceContractPromise = fetch(resolveUrl("figma-manifest/topnav-source-contract.json"))
          .then((response) => {
            if (!response.ok) {
              throw new Error(`source contract unavailable: ${response.status}`);
            }
            return response.json();
          })
            .catch(() => ({ pages: [] }));
      }
      return sourceContractPromise;
    }

    function loadSourceLocator() {
      if (!sourceLocatorPromise) {
        sourceLocatorPromise = fetch(resolveUrl("figma-manifest/topnav-export-locator.json"))
          .then((response) => {
            if (!response.ok) {
              throw new Error(`source locator unavailable: ${response.status}`);
            }
            return response.json();
          })
          .catch(() => ({ pages: [] }))
          .then((data) => {
            sourceLocatorData = data;
            return data;
          });
      }
      return sourceLocatorPromise;
    }

    function parseQuotedCsv(text) {
      const rows = [];
      const lines = String(text || "").split(/\r?\n/).filter(Boolean);
      if (!lines.length) {
        return rows;
      }
      const parseLine = (line) => {
        const values = [];
        let current = "";
        let inQuotes = false;
        for (let index = 0; index < line.length; index += 1) {
          const char = line[index];
          const next = line[index + 1];
          if (char === "\"" && inQuotes && next === "\"") {
            current += "\"";
            index += 1;
            continue;
          }
          if (char === "\"") {
            inQuotes = !inQuotes;
            continue;
          }
          if (char === "," && !inQuotes) {
            values.push(current);
            current = "";
            continue;
          }
          current += char;
        }
        values.push(current);
        return values.map((item) => String(item || "").trim());
      };
      const headers = parseLine(lines[0]);
      lines.slice(1).forEach((line) => {
        const values = parseLine(line);
        const row = {};
        headers.forEach((header, index) => {
          row[header] = values[index] || "";
        });
        rows.push(row);
      });
      return rows;
    }

    function loadScreenSpecIndex() {
      if (!screenSpecIndexPromise) {
        screenSpecIndexPromise = fetch(resolveUrl("figma-manifest/screen-specs/_index.csv"))
          .then((response) => {
            if (!response.ok) {
              throw new Error(`screen spec index unavailable: ${response.status}`);
            }
            return response.text();
          })
          .then((text) => parseQuotedCsv(text))
          .catch(() => []);
      }
      return screenSpecIndexPromise;
    }

    function loadFamilyRegistry() {
      if (!familyRegistryPromise) {
        familyRegistryPromise = fetch(resolveUrl("figma-manifest/family-registry.json"))
          .then((response) => {
            if (!response.ok) {
              throw new Error(`family registry unavailable: ${response.status}`);
            }
            return response.json();
          })
          .catch(() => ({ pages: [] }))
          .then((data) => {
            familyRegistryData = data;
            return data;
          });
      }
      return familyRegistryPromise;
    }

    function getFamilyRegistryEntry(registry, page, variant) {
      const fileName = page.pageSrc.replace("_unzipped/", "");
      const pageEntry = (registry.pages || []).find((item) => item.page === fileName);
      if (!pageEntry || !pageEntry.variants) {
        return null;
      }
      return pageEntry.variants[variant.id] || null;
    }

    function getSourceSpec(contract, page) {
      return (contract.pages || []).find((item) => item.page === page.pageSrc.replace("_unzipped/", ""));
    }

    function getLocatorEntry(locator, page) {
      const fileName = page.pageSrc.replace("_unzipped/", "");
      return (locator.pages || []).find((item) => item.page === fileName);
    }

    function sourceContractMeta(contract) {
      return {
        generatedAt: contract && contract.generated_at ? contract.generated_at : "неизвестно",
        sourceCsv: contract && contract.source_csv ? contract.source_csv : "неизвестно"
      };
    }

    function analyzeSourceSpec(spec) {
      const markers = [
        /template/ig,
        /works best/ig,
        /how it works/ig,
        /reusable shell/ig,
        /approved home baseline/ig,
        /visual language/ig,
        /\bstage\b/ig,
        /\bnew\b/ig
      ];

      const pool = [
        ...(normalizeItems(spec.headings)),
        ...((spec.sections || []).flatMap((section) => [
          ...normalizeItems(section.headings),
          ...normalizeItems(section.text_samples)
        ]))
      ].filter(Boolean);

      const hits = [];
      pool.forEach((item) => {
        markers.forEach((pattern) => {
          pattern.lastIndex = 0;
          if (pattern.test(item)) {
            hits.push(item);
          }
        });
      });

      return {
        staleLike: hits.length > 0,
        samples: [...new Set(hits)].slice(0, 4)
      };
    }

    function normalizeItems(value) {
      if (Array.isArray(value)) {
        return value.filter(Boolean);
      }
      if (typeof value === "string" && value.trim()) {
        return [value];
      }
      return [];
    }

    function renderLocatorEvidence(entry) {
      if (!entry || !Array.isArray(entry.evidence) || !entry.evidence.length) {
        return "";
      }

      return `
        <div class="pending__section">
          <strong>Восстановительное evidence</strong>
          <ul class="pending__list">
            ${entry.evidence.map((item) => `<li><strong>${escapeHtml(item.type)}:</strong> ${escapeHtml(item.detail)}<div><code>${escapeHtml(item.path)}</code></div></li>`).join("")}
          </ul>
        </div>
      `;
    }

    function renderLocatorFooter(entry) {
      if (!entry) {
        return "";
      }

      const blocked = Array.isArray(entry.blocked_by) && entry.blocked_by.length
        ? `<div><strong>Заблокировано:</strong> <code>${escapeHtml(entry.blocked_by.join(" | "))}</code></div>`
        : "";
      const nextStep = entry.next_recovery_action
        ? `<div><strong>Следующий шаг восстановления:</strong> <code>${escapeHtml(entry.next_recovery_action)}</code></div>`
        : "";

      return `
        <div><strong>Сигнал locator:</strong> <code>${escapeHtml(entry.signal_level || "неизвестно")}</code></div>
        ${blocked}
        ${nextStep}
      `;
    }

    function renderSourceSpec(page, variant, spec, jobs, contract, screen, locatorEntry) {
      const matchingJobs = jobs.filter((job) => !job.variantId || job.variantId === variant.id);
      const allSections = spec.sections || [];
      const visibleSections = screen && screen.id !== "full-page"
        ? allSections.filter((section) => (section.order || 0) === (screen.sourceSectionOrder || -1))
        : allSections.slice(0, 4);
      const meta = sourceContractMeta(contract);
      const analysis = analyzeSourceSpec(spec);
      nodes.referenceViewport.innerHTML = `
        <div class="pending">
          <div class="pending__title">${screen && screen.id !== "full-page" ? `Резервный source-contract: ${escapeHtml(screen.label)}` : "Резервный source-contract"}</div>
          <div class="pending__note">Raster export для этой страницы локально не найден, но панель показывает source-contract по секциям из <code>figma-links.local.csv</code>. Это fallback со стороны эталона, а не разрешение дорисовывать дизайн локально и не доказательство свежего content parity.</div>
          <div><strong>Заголовок:</strong> <code>${escapeHtml(spec.title || page.label)}</code></div>
          <div><strong>Секций загружено:</strong> <code>${escapeHtml(String(allSections.length))}</code></div>
          <div><strong>Контракт сгенерирован:</strong> <code>${escapeHtml(meta.generatedAt)}</code></div>
          ${locatorEntry ? `<div><strong>Сигнал locator:</strong> <code>${escapeHtml(locatorEntry.signal_level || "неизвестно")}</code></div>` : ""}
          ${analysis.staleLike ? `<div class="notice"><strong>Обнаружены stale-маркеры:</strong> contract всё ещё содержит template/draft-era формулировки и должен считаться слабой structural reference, а не свежим content proof.</div>` : ""}
          ${visibleSections.map((section) => {
            const headings = normalizeItems(section.headings).slice(0, 3);
            const samples = normalizeItems(section.text_samples).slice(0, 4);
            return `
              <div class="pending__section">
                <strong>${escapeHtml(`#${section.order} ${section.section_class || "section"}`)}</strong>
                ${headings.length ? `<div><strong>Заголовки:</strong> ${headings.map((item) => `<code>${escapeHtml(item)}</code>`).join(" ")}</div>` : ""}
                ${samples.length ? `<ul class="pending__list">${samples.map((item) => `<li>${escapeHtml(item)}</li>`).join("")}</ul>` : ""}
                <div><code>images=${section.image_count}; links=${section.link_count}</code></div>
              </div>
            `;
          }).join("")}
          ${renderLocatorEvidence(locatorEntry)}
          ${matchingJobs.length ? `<div class="pending__note">Export-jobs для этой страницы уже известны локально, но raster-артефакты всё ещё отсутствуют.</div>` : ""}
        </div>
      `;
      setPaneTag(nodes.referenceTag, "Нет экспорта из Figma", "danger");
      nodes.referenceFoot.innerHTML = `
        <div><strong>Источник:</strong> <code>figma-manifest/topnav-source-contract.json</code></div>
        <div><strong>Режим сравнения:</strong> <code>${escapeHtml(screen && screen.id !== "full-page" ? `screen / ${screen.label}` : "page / full-page")}</code></div>
        <div><strong>Происхождение:</strong> <code>${escapeHtml(meta.sourceCsv)}</code></div>
        ${analysis.staleLike ? `<div><strong>Найденные маркеры:</strong> <code>${escapeHtml(analysis.samples.join(" | "))}</code></div>` : ""}
        ${renderLocatorFooter(locatorEntry)}
        <div class="notice">Fallback-spec полезен для section-contract и структуры, но может отставать от локальной очистки wording в верстке.</div>
      `;
    }

    function renderPendingSource(page, variant, jobs, screen, locatorEntry) {
      const matchingJobs = jobs.filter((job) => !job.variantId || job.variantId === variant.id);
      const allArtifacts = matchingJobs.flatMap((job) => job.expectedArtifacts || []);
      const manifestBlock = page.manifestTitle
        ? `<div><strong>Manifest-титул:</strong> <code>${escapeHtml(page.manifestTitle)}</code></div>`
        : `<div class="notice">Manifest-backed title для этой страницы пока не подключён к конфигурации board.</div>`;
      const reasonBlock = page.blockedReason
        ? `<div><strong>Причина статуса:</strong> <span>${escapeHtml(page.blockedReason)}</span></div>`
        : "";
      nodes.referenceViewport.innerHTML = `
        <div class="pending">
          <div class="pending__title">${screen && screen.id !== "full-page" ? `Экспорт эталона ожидается: ${escapeHtml(screen.label)}` : "Экспорт эталона ожидается"}</div>
          <div class="pending__note">Для этой страницы нет локально доступного PNG-эталона, который панель может честно показать слева. Compare по исходнику станет доступен сразу после появления export artifact в ожидаемом path. Отсутствие экспорта не является разрешением дорисовывать страницу локально.</div>
          <div><strong>Страница:</strong> <code>${escapeHtml(page.pageSrc)}</code></div>
          ${manifestBlock}
          ${reasonBlock}
          <div><strong>Брейкпоинт:</strong> <code>${escapeHtml(variant.id)}</code></div>
          <div><strong>Подходящих jobs:</strong> <code>${escapeHtml(String(matchingJobs.length))}</code></div>
          ${locatorEntry ? `<div><strong>Сигнал locator:</strong> <code>${escapeHtml(locatorEntry.signal_level || "неизвестно")}</code></div>` : ""}
          ${allArtifacts.length ? `<div><strong>Ожидаемые артефакты:</strong></div><ul class="pending__list">${allArtifacts.map((artifact) => `<li><code>${escapeHtml(artifact)}</code></li>`).join("")}</ul>` : `<div class="notice">Для этой страницы export-jobs пока вообще не зафиксированы в локальном figma-export слое.</div>`}
          ${renderLocatorEvidence(locatorEntry)}
        </div>
      `;
      setPaneTag(nodes.referenceTag, matchingJobs.length ? "Экспорт из Figma ожидается" : "Нет source-contract", matchingJobs.length ? "warn" : "danger");
      nodes.referenceFoot.innerHTML = matchingJobs.length
        ? `<div><strong>Режим сравнения:</strong> <code>${escapeHtml(screen && screen.id !== "full-page" ? `screen / ${screen.label}` : "page / full-page")}</code></div>` + matchingJobs.map((job) => `<div><strong>${escapeHtml(job.name)}</strong>: <code>${escapeHtml(job.status)}</code></div>`).join("") + renderLocatorFooter(locatorEntry)
        : renderLocatorFooter(locatorEntry) + `<div class="notice">Для выбранной страницы нет source-jobs в локальном export-plan.</div>`;
    }

    function renderImplementationError(page, variant, family, message) {
      nodes.implementationViewport.innerHTML = `
        <div class="pending">
          <div class="pending__title">Live-верстка заблокирована</div>
          <div class="pending__note">Правая compare-pane не смогла стабильно поднять live-верстку для этой страницы. Это runtime-проблема панели или пути загрузки страницы, а не молчаливое пустое состояние.</div>
          <div><strong>Семейство:</strong> <code>${escapeHtml(family.label)}</code></div>
          <div><strong>Страница:</strong> <code>${escapeHtml(page.pageSrc)}</code></div>
          <div><strong>Брейкпоинт:</strong> <code>${escapeHtml(variant.id)}</code></div>
          <div><strong>Ошибка:</strong> <code>${escapeHtml(message)}</code></div>
        </div>
      `;
      clearViewportGuides(nodes.implementationViewport);
    }

    function renderReferenceImage(imageInfo, variant, screen, implementation) {
      nodes.referenceViewport.innerHTML = "";
      clearViewportGuides(nodes.referenceViewport);
      const img = new Image();
      img.className = "viewport__img";
      img.src = imageInfo.url;
      img.alt = "Экспорт эталона";
      img.onload = () => {
        let cropTop = 0;
        let cropHeight = img.naturalHeight;
        const isScreenMode = state.modeId === "screen" && screen && screen.id !== "full-page";
        if (isScreenMode && implementation && Number.isFinite(screen.topRatio) && Number.isFinite(screen.heightRatio)) {
          cropTop = Math.round(img.naturalHeight * screen.topRatio);
          cropHeight = Math.max(120, Math.round(img.naturalHeight * screen.heightRatio));
          cropHeight = Math.min(cropHeight, img.naturalHeight - cropTop);
          img.style.top = `${-cropTop}px`;
        } else {
          img.style.top = "0";
        }
        img.style.width = `${img.naturalWidth}px`;
        img.style.height = `${img.naturalHeight}px`;
        nodes.referenceViewport.appendChild(img);
        setViewportPresentationMode(nodes.referenceViewport, state.modeId);
        scaleToFit(nodes.referenceViewport, img.naturalWidth, cropHeight, {
          fit: isScreenMode ? "both" : "width"
        });
        applyViewportGuides(nodes.referenceViewport, img.naturalWidth, cropHeight, {
          kind: "source",
          screen: state.modeId === "screen" && screen && screen.id !== "full-page" ? screen.label : "full-page"
        });
      };
      setPaneTag(nodes.referenceTag, state.modeId === "screen" && screen && screen.id !== "full-page" ? "Экспорт из Figma: экран" : "Экспорт из Figma готов", "good");
      nodes.referenceFoot.innerHTML = `
        <div><strong>Разрешённый источник:</strong> <code>${escapeHtml(imageInfo.url)}</code></div>
        <div><strong>Натуральный размер:</strong> <code>${imageInfo.width}x${imageInfo.height}</code></div>
        <div><strong>Режим сравнения:</strong> <code>${escapeHtml(state.modeId === "screen" && screen && screen.id !== "full-page" ? `screen / ${screen.label}` : "page / full-page")}</code></div>
      `;
    }

    function measureImplementationFrame(frame, sourceSpec, familyRegistryEntry) {
      const doc = frame.contentDocument;
      if (!doc || !doc.documentElement || !doc.body) {
        return null;
      }

      const root = effectiveScrollRoot(doc) || doc.scrollingElement || doc.documentElement || doc.body;
      const bodyRect = doc.body.getBoundingClientRect();
      const pageHeight = Math.max(
        root.scrollHeight || 0,
        root.offsetHeight || 0,
        doc.body.scrollHeight || 0,
        doc.body.offsetHeight || 0,
        doc.documentElement.scrollHeight || 0,
        doc.documentElement.offsetHeight || 0,
        640
      );

      return {
        pageHeight,
        scrollRoot: scrollRootLabel(doc, root),
        frameSrc: frame.src,
        readyState: doc.readyState || "неизвестно",
        viewport: {
          innerWidth: frame.contentWindow?.innerWidth || 0,
          innerHeight: frame.contentWindow?.innerHeight || 0,
          devicePixelRatio: frame.contentWindow?.devicePixelRatio || 1,
          visualViewportWidth: frame.contentWindow?.visualViewport?.width || 0,
          documentClientWidth: doc.documentElement.clientWidth || 0,
          bodyClientWidth: doc.body.clientWidth || 0,
          bodyRectWidth: Math.round(bodyRect.width || 0)
        },
        screens: extractScreenOptions(doc, sourceSpec, pageHeight),
        auditFamilies: extractAuditFamilies(doc, familyRegistryEntry, pageHeight)
      };
    }

    function loadImplementation(page, variant, sourceSpec, familyRegistryEntry) {
      return new Promise((resolve, reject) => {
        nodes.implementationViewport.innerHTML = "";
        const frame = document.createElement("iframe");
        frame.className = "viewport__frame";
        frame.loading = "eager";
        frame.src = resolveLiveUrl(page.pageSrc);
        frame.style.width = `${variant.width}px`;
        nodes.implementationViewport.appendChild(frame);

        let settled = false;

        const cleanup = () => {
          window.clearTimeout(timeoutId);
          window.clearInterval(pollId);
        };

        const finalize = () => {
          if (settled) {
            return true;
          }

          const doc = frame.contentDocument;
          if (doc && doc.readyState === "loading") {
            return false;
          }

          const measurement = measureImplementationFrame(frame, sourceSpec, familyRegistryEntry);
          if (!measurement) {
            return false;
          }

          settled = true;
          cleanup();
          frame.style.height = `${measurement.pageHeight}px`;
          setViewportPresentationMode(nodes.implementationViewport, state.modeId);
          scaleToFit(nodes.implementationViewport, variant.width, measurement.pageHeight, {
            fit: state.modeId === "screen" ? "both" : "width"
          });
          resolve(measurement);
          return true;
        };

        const timeoutId = window.setTimeout(() => {
          const measurement = measureImplementationFrame(frame, sourceSpec, familyRegistryEntry);
          if (measurement) {
            finalize();
            return;
          }

          settled = true;
          cleanup();
          reject(new Error(`implementation load timeout: ${frame.src}`));
        }, 12000);

        const pollId = window.setInterval(() => {
          finalize();
        }, 250);

        frame.addEventListener("load", () => {
          requestAnimationFrame(() => {
            if (!finalize()) {
              settled = true;
              cleanup();
              reject(new Error(`iframe loaded without measurable document: ${frame.src}`));
            }
          });
        }, { once: true });

        frame.addEventListener("error", () => {
          if (settled) {
            return;
          }
          settled = true;
          cleanup();
          reject(new Error(`iframe load failed: ${frame.src}`));
        }, { once: true });
      });
    }

    function renderImplementationViewport(page, variant, implementation, screen) {
      const frame = nodes.implementationViewport.querySelector("iframe");
      if (!frame) {
        return;
      }

      const isScreenMode = state.modeId === "screen" && screen && screen.id !== "full-page";
      const screenHeight = isScreenMode && Number.isFinite(screen.height)
        ? Math.max(120, Math.round(screen.height))
        : implementation.pageHeight;
      const screenTop = isScreenMode && Number.isFinite(screen.top)
        ? Math.max(0, Math.round(screen.top))
        : 0;

      nodes.implementationViewport.style.width = `${variant.width}px`;
      nodes.implementationViewport.style.height = `${screenHeight}px`;
      frame.style.width = `${variant.width}px`;
      frame.style.height = `${implementation.pageHeight}px`;
      frame.style.top = `${-screenTop}px`;
      setViewportPresentationMode(nodes.implementationViewport, state.modeId);
      scaleToFit(nodes.implementationViewport, variant.width, screenHeight, {
        fit: isScreenMode ? "both" : "width"
      });
      applyViewportGuides(nodes.implementationViewport, variant.width, screenHeight, {
        kind: "live",
        screen: state.modeId === "screen" && screen && screen.id !== "full-page" ? screen.label : "full-page"
      });
      renderPixelAuditSummary();
    }

    function renderCompareLens(cache) {
      nodes.compareLensViewport.innerHTML = "";
      clearViewportGuides(nodes.compareLensViewport);
      currentLensMetrics = null;
      issueDraft = null;
      renderIssueSummary();

      if (!cache || !cache.implementation) {
        nodes.compareLensMeta.textContent = "Линза сравнения ждёт измеримую live-верстку.";
        setPaneTag(nodes.compareLensTag, "Линза заблокирована", "warn");
      nodes.compareLensFoot.innerHTML = `<span class="notice">Линза сравнения недоступна: live-верстка ещё не готова.</span>`;
        renderPixelAuditSummary();
        return;
      }

      const { page, variant, implementation, screen, imageInfo } = cache;
      const screenCompareReady = !!imageInfo;

      if (!screenCompareReady) {
        nodes.compareLensMeta.textContent = `${page.label} / ${variant.label}px`;
        setPaneTag(nodes.compareLensTag, "Нет PNG-эталона", "danger");
        nodes.compareLensViewport.innerHTML = `
          <div class="pending">
            <div class="pending__title">Линза визуального сравнения недоступна</div>
            <div class="pending__note">Наложение и шторка доступны только когда у выбранного брейкпоинта есть реальный source PNG. Сейчас панель честно не строит фальшивое совмещение по manifest fallback.</div>
            <div><strong>Страница:</strong> <code>${escapeHtml(page.pageSrc)}</code></div>
            <div><strong>Брейкпоинт:</strong> <code>${escapeHtml(variant.id)}</code></div>
          </div>
        `;
        nodes.compareLensFoot.innerHTML = `<span class="notice">Линза заблокирована: для этого брейкпоинта нет реального экспорта из Figma.</span>`;
        renderPixelAuditSummary();
        renderIssueSummary();
        return;
      }

      const isScreenMode = state.modeId === "screen" && screen && screen.id !== "full-page";
      const sourceScale = variant.width / imageInfo.width;
      const sourceFullHeight = Math.round(imageInfo.height * sourceScale);
      const sourceCropTop = isScreenMode && Number.isFinite(screen.topRatio) ? Math.round(imageInfo.height * screen.topRatio * sourceScale) : 0;
      const sourceCropHeightRaw = isScreenMode && Number.isFinite(screen.heightRatio)
        ? Math.round(imageInfo.height * screen.heightRatio * sourceScale)
        : sourceFullHeight;
      const sourceCropHeight = Math.max(120, Math.min(sourceCropHeightRaw, sourceFullHeight - sourceCropTop));
      const implementationHeight = isScreenMode && Number.isFinite(screen.height)
        ? Math.max(120, Math.round(screen.height))
        : implementation.pageHeight;
      const implementationTop = isScreenMode && Number.isFinite(screen.top)
        ? Math.max(0, Math.round(screen.top))
        : 0;
      const stageHeight = Math.max(sourceCropHeight, implementationHeight);

      nodes.compareLensViewport.style.width = `${variant.width}px`;
      nodes.compareLensViewport.style.height = `${stageHeight}px`;

      const sourceLayer = document.createElement("div");
      sourceLayer.className = "lens-layer lens-layer--source";
      sourceLayer.style.width = `${variant.width}px`;
      sourceLayer.style.height = `${sourceCropHeight}px`;
      const sourceImg = new Image();
      sourceImg.src = imageInfo.url;
      sourceImg.alt = "Наложение эталона";
      sourceImg.style.width = `${variant.width}px`;
      sourceImg.style.height = `${sourceFullHeight}px`;
      sourceImg.style.top = `${-sourceCropTop}px`;
      sourceLayer.appendChild(sourceImg);

      const implementationLayer = document.createElement("div");
      implementationLayer.className = "lens-layer lens-layer--implementation";
      implementationLayer.style.width = `${variant.width}px`;
      implementationLayer.style.height = `${implementationHeight}px`;
      const frame = document.createElement("iframe");
      frame.src = resolveLiveUrl(page.pageSrc);
      frame.loading = "eager";
      frame.style.width = `${variant.width}px`;
      frame.style.height = `${implementation.pageHeight}px`;
      frame.style.top = `${-implementationTop}px`;
      implementationLayer.appendChild(frame);

      if (state.lensId === "wipe") {
        const topLayer = state.overlayTopLayerId === "source" ? sourceLayer : implementationLayer;
        const baseLayer = state.overlayTopLayerId === "source" ? implementationLayer : sourceLayer;
        topLayer.style.clipPath = `inset(0 ${100 - state.overlaySplit}% 0 0)`;
        topLayer.style.opacity = "1";
        baseLayer.style.opacity = "1";
        nodes.compareLensViewport.appendChild(baseLayer);
        nodes.compareLensViewport.appendChild(topLayer);
        attachWipeHandle(nodes.compareLensViewport, topLayer);
        setPaneTag(nodes.compareLensTag, "Линза: шторка", "good");
      } else if (state.lensId === "overlay") {
        const topLayer = state.overlayTopLayerId === "source" ? sourceLayer : implementationLayer;
        const baseLayer = state.overlayTopLayerId === "source" ? implementationLayer : sourceLayer;
        topLayer.style.opacity = String(state.overlayOpacity / 100);
        baseLayer.style.opacity = "1";
        nodes.compareLensViewport.appendChild(baseLayer);
        nodes.compareLensViewport.appendChild(topLayer);
        setPaneTag(nodes.compareLensTag, "Линза: наложение", "good");
      } else {
        nodes.compareLensViewport.innerHTML = `
          <div class="pending">
            <div class="pending__title">Сплит-сравнение активно выше</div>
            <div class="pending__note">Для режима <code>Split</code> основной сравнительный контур остаётся в двух верхних pane. Переключи compare mode на <code>Overlay</code> или <code>Wipe</code>, чтобы сложить source и live в одну сцену.</div>
          </div>
        `;
        setPaneTag(nodes.compareLensTag, "Линза: сплит", "good");
        nodes.compareLensMeta.textContent = `${page.label} / ${variant.label}px / ${isScreenMode ? screen.label : "Вся страница"}`;
        nodes.compareLensFoot.innerHTML = `
          <div><strong>Эталон:</strong> <code>${escapeHtml(imageInfo.url)}</code></div>
          <div><strong>Live-верстка:</strong> <code>${escapeHtml(resolveUrl(page.pageSrc))}</code></div>
          <div><strong>Линза:</strong> <code>split</code></div>
          <div><strong>Точность:</strong> <code>${escapeHtml(currentScaleSummary())}</code></div>
          <div class="notice">Overlay-сцена намеренно не строится в split-режиме, чтобы не дублировать верхний compare и не создавать лишнюю визуальную нагрузку.</div>
        `;
        nodes.overlaySummary.textContent = "Сплит-сравнение активно выше. Переключись на Наложение или Шторку, чтобы сложить оба слоя.";
        renderPixelAuditSummary();
        renderIssueSummary();
        return;
      }

      setViewportPresentationMode(nodes.compareLensViewport, state.modeId);
      scaleToFit(nodes.compareLensViewport, variant.width, stageHeight, {
        fit: isScreenMode ? "both" : "width"
      });
      applyViewportGuides(nodes.compareLensViewport, variant.width, stageHeight, {
        kind: "lens",
        screen: isScreenMode ? screen.label : "full-page"
      });
      renderPixelAuditSummary();
      attachAuditOverlay(nodes.compareLensViewport, variant.width, stageHeight, cache.scanDocument);
      attachIssueOverlay(nodes.compareLensViewport, variant.width, stageHeight);
      nodes.compareLensMeta.textContent = `${page.label} / ${variant.label}px / ${isScreenMode ? screen.label : "Вся страница"}`;
      nodes.compareLensFoot.innerHTML = `
        <div><strong>Эталон:</strong> <code>${escapeHtml(imageInfo.url)}</code></div>
        <div><strong>Live-верстка:</strong> <code>${escapeHtml(resolveUrl(page.pageSrc))}</code></div>
        <div><strong>Линза:</strong> <code>${escapeHtml(state.lensId)}</code></div>
        <div><strong>Верхний слой:</strong> <code>${escapeHtml(state.overlayTopLayerId)}</code></div>
        <div><strong>Непрозрачность:</strong> <code>${escapeHtml(String(state.overlayOpacity))}%</code></div>
        <div><strong>Разделение:</strong> <code data-lens-split-value>${escapeHtml(String(state.overlaySplit))}%</code></div>
        <div><strong>Точность:</strong> <code>${escapeHtml(currentScaleSummary())}</code></div>
      `;
      nodes.overlaySummary.textContent = state.lensId === "overlay"
        ? `Наложение готово. Верхний слой: ${state.overlayTopLayerId}. Непрозрачность ${state.overlayOpacity}%.`
        : state.lensId === "wipe"
          ? `Шторка готова. Видимое разделение: ${state.overlaySplit}%. Верхний слой: ${state.overlayTopLayerId}.`
          : "Сплит-сравнение активно выше. Переключись на Наложение или Шторку, чтобы сложить оба слоя.";
    }

    function buildReferenceCandidates(page, variant) {
      const matchingJobs = jobsForVariant(page, variant);
      const exportJobs = matchingJobs.filter((job) => job.status === "export_exists");
      const pendingJobs = matchingJobs.filter((job) => job.status !== "export_exists");
      return {
        jobs: matchingJobs,
        candidates: [...exportJobs, ...pendingJobs].flatMap((job) => job.expectedArtifacts || []),
        hasRealExport: exportJobs.length > 0
      };
    }

    async function renderBoard() {
      const family = currentFamily();
      const page = currentPage();
      const variant = currentVariant();
      const reference = buildReferenceCandidates(page, variant);
      const contract = await loadSourceContract();
      const locator = await loadSourceLocator();
      sourceLocatorData = locator;
      const screenSpecIndexRows = await loadScreenSpecIndex();
      const familyRegistry = await loadFamilyRegistry();
      const sourceSpec = getSourceSpec(contract, page);
      const familyRegistryEntry = getFamilyRegistryEntry(familyRegistry, page, variant);
      renderReferenceInventory(page, sourceSpec, screenSpecIndexRows);
      renderEthalonPackPanel();
      renderScanDocument(null);
      const locatorEntry = getLocatorEntry(locator, page);
      const screenReady = hasVisualScreenCompare(page, variant);

      if (!screenReady && state.modeId === "screen") {
        state.modeId = "page";
        state.screenId = "full-page";
        syncUrl();
      }

      nodes.referenceMeta.textContent = `${family.label} / ${page.label} / ${variant.label}px`;
      nodes.implementationMeta.textContent = `${family.label} / ${page.label} / ${variant.label}px`;
      setPaneTag(nodes.implementationTag, `${variant.label}px live`, "good");
      nodes.compareLensMeta.textContent = `${page.label} / ${variant.label}px`;
      setPaneTag(nodes.compareLensTag, "Линза ожидает", "warn");

      nodes.referenceViewport.innerHTML = "";
      nodes.implementationViewport.innerHTML = "";
      nodes.compareLensViewport.innerHTML = "";
      clearViewportGuides(nodes.referenceViewport);
      clearViewportGuides(nodes.implementationViewport);
      clearViewportGuides(nodes.compareLensViewport);
      nodes.referenceFoot.innerHTML = `<div>Загрузка состояния эталона...</div>`;
      nodes.implementationFoot.innerHTML = `<div>Загрузка live-верстки...</div><div><strong>Запрошено:</strong> <code>${escapeHtml(resolveUrl(page.pageSrc))}</code></div>`;
      nodes.compareLensFoot.innerHTML = `<div>Загрузка линзы сравнения...</div>`;
      boardRenderCache = null;

      let implementation = null;
      try {
        implementation = await loadImplementation(page, variant, sourceSpec, familyRegistryEntry);
        screenCatalog.set(screenCatalogKey(page, variant), screenReady && implementation.screens && implementation.screens.length ? implementation.screens : [defaultScreenOption()]);
        normalizeScreenChoice(currentScreenOptions());
        rerenderControls();
        const screen = currentScreenOption();
        renderImplementationViewport(page, variant, implementation, screen);
        const compareLabel = state.modeId === "screen" && screen.id !== "full-page" ? screen.label : "Вся страница";
        nodes.referenceMeta.textContent = `${family.label} / ${page.label} / ${variant.label}px / ${compareLabel}`;
        nodes.implementationMeta.textContent = `${family.label} / ${page.label} / ${variant.label}px / ${compareLabel}`;
        setPaneTag(nodes.implementationTag, state.modeId === "screen" && screen.id !== "full-page" ? `${variant.label}px экран` : `${variant.label}px live`, "good");
        nodes.implementationFoot.innerHTML = `
          <div><strong>Разрешённый источник:</strong> <code>${escapeHtml(implementation.frameSrc)}</code></div>
          <div><strong>Высота страницы:</strong> <code>${implementation.pageHeight}px</code></div>
          <div><strong>Scroll-root:</strong> <code>${escapeHtml(implementation.scrollRoot || "unknown")}</code></div>
          <div><strong>Режим сравнения:</strong> <code>${escapeHtml(state.modeId === "screen" && screen.id !== "full-page" ? `screen / ${screen.label}` : "page / full-page")}</code></div>
          <div><strong>Iframe viewport:</strong> <code>${implementation.viewport.innerWidth}x${implementation.viewport.innerHeight}</code>; <strong>DPR:</strong> <code>${implementation.viewport.devicePixelRatio}</code>; <strong>client/body:</strong> <code>${implementation.viewport.documentClientWidth}/${implementation.viewport.bodyClientWidth}/${implementation.viewport.bodyRectWidth}px</code></div>
          <div><strong>Точность панели:</strong> <code>${escapeHtml(currentScaleSummary())}</code></div>
          <div><strong>Состояние документа:</strong> <code>${escapeHtml(implementation.readyState)}</code></div>
          <div><strong>Семейство:</strong> <code>${escapeHtml(family.id)}</code></div>
        `;
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        renderImplementationError(page, variant, family, message);
        setPaneTag(nodes.implementationTag, "Live заблокирован", "danger");
        nodes.implementationFoot.innerHTML = `<span class="notice">Ошибка live-верстки: ${escapeHtml(message)}</span>`;
      }

      const screen = currentScreenOption();
      let imageInfo = null;

      try {
        imageInfo = await loadImageCandidate(reference.candidates);
        renderReferenceImage(imageInfo, variant, screen, implementation);
      } catch {
        if (sourceSpec) {
          renderSourceSpec(page, variant, sourceSpec, reference.jobs, contract, screen, locatorEntry);
        } else {
          renderPendingSource(page, variant, reference.jobs, screen, locatorEntry);
        }
      }

      boardRenderCache = {
        family,
        page,
        variant,
        screen,
        implementation,
        imageInfo,
        scanDocument: buildScanDocument({ family, page, variant, screen, sourceSpec, imageInfo, implementation, familyRegistryEntry })
      };
      renderScanDocument(boardRenderCache.scanDocument);
      renderCompareLens(boardRenderCache);
    }

    function rerenderControls() {
      const page = currentPage();
      const variant = currentVariant();
      const screenReady = hasVisualScreenCompare(page, variant);

      renderChipGroup(nodes.familyChips, FAMILIES, state.familyId, (id) => {
        state.familyId = id;
        state.pageId = currentFamily().pages[0].id;
        state.screenId = "full-page";
        syncUrl();
        rerenderControls();
        renderBoard();
      });

      renderChipGroup(nodes.pageChips, currentFamily().pages, state.pageId, (id) => {
        state.pageId = id;
        state.screenId = "full-page";
        syncUrl();
        rerenderControls();
        renderBoard();
      });

      renderChipGroup(nodes.variantChips, VARIANTS, state.variantId, (id) => {
        state.variantId = id;
        state.screenId = "full-page";
        syncUrl();
        rerenderControls();
        renderBoard();
      });

      if (!screenReady && state.modeId === "screen") {
        state.modeId = "page";
        state.screenId = "full-page";
      }

      renderChipGroup(nodes.modeChips, VIEW_MODES.map((mode) => ({
        ...mode,
        disabled: mode.id === "screen" && !screenReady
      })), state.modeId, (id) => {
        state.modeId = id;
        if (id === "page") {
          state.screenId = "full-page";
        } else {
          normalizeScreenChoice(currentScreenOptions());
        }
        syncUrl();
        rerenderControls();
        renderBoard();
      });

      renderChipGroup(nodes.lensChips, COMPARE_LENSES, state.lensId, (id) => {
        state.lensId = id;
        syncUrl();
        rerenderControls();
        renderCompareLens(boardRenderCache);
      });

      const screenOptions = currentScreenOptions();
      renderChipGroup(nodes.screenChips, screenOptions, state.screenId, (id) => {
        state.screenId = id;
        syncUrl();
        rerenderControls();
        renderBoard();
      });

      renderChipGroup(nodes.overlayLayerChips, OVERLAY_TOP_LAYERS.map((item) => ({
        ...item,
        disabled: state.lensId === "split"
      })), state.overlayTopLayerId, (id) => {
        state.overlayTopLayerId = id;
        syncUrl();
        rerenderControls();
        renderCompareLens(boardRenderCache);
      });

      updateNavigatorUi();
      renderLinkMatrix();
      renderGuideSummary();
      renderPixelAuditSummary();
      renderMacroGateSummary();
      renderAuditSummary();
      renderIssueSummary();
    }

    function bootDefaultEthalonRoute() {
      const params = new URLSearchParams(window.location.search);
      if (params.has("family") || params.has("page")) return;
      const allPsychicFamily = FAMILIES.find((family) =>
        family.id === "psychics" || (family.pages || []).some((page) => page.id === "all-psychic")
      );
      const allPsychicPage = (allPsychicFamily?.pages || []).find((page) => page.id === "all-psychic");
      if (allPsychicFamily && allPsychicPage) {
        state.familyId = allPsychicFamily.id;
        state.pageId = allPsychicPage.id;
      } else {
        const firstFamily = Array.isArray(ethalonPack?.board_families) ? ethalonPack.board_families[0] : null;
        const firstPage = Array.isArray(firstFamily?.pages) ? firstFamily.pages[0] : null;
        if (!firstFamily || !firstPage) return;
        state.familyId = firstFamily.id;
        state.pageId = firstPage.id;
      }
      state.variantId = "1200";
      state.modeId = "page";
      state.screenId = "full-page";
    }

    async function bootstrap() {
      await loadEthalonPack();
      await loadSourceContract();
      sourceLocatorData = await loadSourceLocator();
      applyStateFromUrl();
      bootDefaultEthalonRoute();
      syncUrl();
      renderEthalonPackPanel();
      renderReviewRoutes();
      rerenderControls();
      renderBoard();
    }

    function downloadJsonFile(filename, payload) {
      const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      link.remove();
      URL.revokeObjectURL(url);
    }

    function issuePayloadFilename(payload) {
      const stamp = new Date().toISOString().replace(/[:.]/g, "-");
      return `oracle-issue-${payload.page || "page"}-${payload.variant || "variant"}-${stamp}.json`;
    }

    nodes.prevScreenBtn.addEventListener("click", () => {
      const options = currentScreenOptions();
      const currentIndex = options.findIndex((item) => item.id === state.screenId);
      if (currentIndex > 0) {
        state.screenId = options[currentIndex - 1].id;
        syncUrl();
        rerenderControls();
        renderBoard();
      }
    });
    nodes.nextScreenBtn.addEventListener("click", () => {
      const options = currentScreenOptions();
      const currentIndex = options.findIndex((item) => item.id === state.screenId);
      if (currentIndex >= 0 && currentIndex < options.length - 1) {
        state.screenId = options[currentIndex + 1].id;
        syncUrl();
        rerenderControls();
        renderBoard();
      }
    });
    nodes.copyLinkBtn.addEventListener("click", async () => {
      const value = currentDeepLink();
      try {
        await navigator.clipboard.writeText(value);
        nodes.copyLinkBtn.textContent = "Ссылка скопирована";
      } catch {
        nodes.deepLinkField.focus();
        nodes.deepLinkField.select();
        nodes.copyLinkBtn.textContent = "Выдели ссылку";
      }
      window.setTimeout(() => {
        nodes.copyLinkBtn.textContent = "Копировать ссылку";
      }, 1200);
    });
    nodes.copyScanDocBtn?.addEventListener("click", async () => {
      if (!currentScanDocument) {
        return;
      }
      try {
        await navigator.clipboard.writeText(JSON.stringify(currentScanDocument, null, 2));
        nodes.copyScanDocBtn.textContent = "JSON скопирован";
      } catch {
        nodes.copyScanDocBtn.textContent = "Ошибка копирования";
      }
      window.setTimeout(() => {
        nodes.copyScanDocBtn.textContent = "Копировать JSON";
      }, 1200);
    });
    nodes.downloadScanDocBtn?.addEventListener("click", () => {
      if (!currentScanDocument) {
        return;
      }
      const blob = new Blob([JSON.stringify(currentScanDocument, null, 2)], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `oracle-scan-doc-${currentPage().id}-${currentVariant().id}.json`;
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.setTimeout(() => URL.revokeObjectURL(url), 1000);
    });
    nodes.overlayOpacity.addEventListener("input", () => {
      state.overlayOpacity = clamp(Number.parseInt(nodes.overlayOpacity.value, 10) || 55, 10, 100);
      syncUrl();
      renderCompareLens(boardRenderCache);
    });
    nodes.overlaySplit.addEventListener("input", () => {
      state.overlaySplit = clamp(Number.parseInt(nodes.overlaySplit.value, 10) || 50, 0, 100);
      syncUrl();
      renderCompareLens(boardRenderCache);
    });
    nodes.guideGrid.addEventListener("change", () => {
      state.guideGrid = !!nodes.guideGrid.checked;
      syncUrl();
      renderGuideSummary();
      renderBoard();
    });
    nodes.guideIndex.addEventListener("change", () => {
      state.guideIndex = !!nodes.guideIndex.checked;
      syncUrl();
      renderGuideSummary();
      renderBoard();
    });
    nodes.guideSafeArea.addEventListener("change", () => {
      state.guideSafeArea = !!nodes.guideSafeArea.checked;
      syncUrl();
      renderGuideSummary();
      renderBoard();
    });
    nodes.guideAnchors.addEventListener("change", () => {
      state.guideAnchors = !!nodes.guideAnchors.checked;
      syncUrl();
      renderGuideSummary();
      renderBoard();
    });
    nodes.guideColumns.addEventListener("input", () => {
      state.guideColumns = clamp(Number.parseInt(nodes.guideColumns.value, 10) || 12, 4, 24);
      syncUrl();
      renderGuideSummary();
      renderBoard();
    });
    nodes.guideBaseline.addEventListener("input", () => {
      state.guideBaseline = clamp(Number.parseInt(nodes.guideBaseline.value, 10) || 8, 4, 16);
      syncUrl();
      renderGuideSummary();
      renderBoard();
    });
    nodes.pixelAuditMode?.addEventListener("change", () => {
      state.pixelAuditMode = !!nodes.pixelAuditMode.checked;
      syncUrl();
      renderPixelAuditSummary();
      renderBoard();
    });
    nodes.issueMode.addEventListener("change", () => {
      state.issueMode = !!nodes.issueMode.checked;
      if (state.issueMode) {
        state.auditMode = false;
      }
      syncUrl();
      renderMacroGateSummary();
      renderAuditSummary();
      renderIssueSummary();
      renderCompareLens(boardRenderCache);
    });
    nodes.macroGateMode?.addEventListener("change", () => {
      state.macroGateMode = !!nodes.macroGateMode.checked;
      if (state.macroGateMode) {
        state.auditMode = false;
        state.issueMode = false;
        state.guideGrid = true;
        state.guideIndex = false;
      }
      syncUrl();
      renderGuideSummary();
      renderMacroGateSummary();
      renderAuditSummary();
      renderIssueSummary();
      updateFocusBar();
      renderCompareLens(boardRenderCache);
    });
    nodes.auditMode?.addEventListener("change", () => {
      state.auditMode = !!nodes.auditMode.checked;
      if (state.auditMode) {
        if (!macroGateAllowsDeepAudit()) {
          state.auditMode = false;
          renderMacroGateSummary();
          renderAuditSummary();
          renderIssueSummary();
          renderCompareLens(boardRenderCache);
          return;
        }
        state.issueMode = false;
        state.guideGrid = true;
        state.guideIndex = true;
      }
      syncUrl();
      renderGuideSummary();
      renderMacroGateSummary();
      renderAuditSummary();
      renderIssueSummary();
      renderCompareLens(boardRenderCache);
    });
    nodes.removeIssueBtn?.addEventListener("click", () => {
      if (state.issueActiveIndex < 0) {
        return;
      }
      state.issueRegions = state.issueRegions.filter((_, index) => index !== state.issueActiveIndex);
      syncIssueState(Math.min(state.issueActiveIndex, state.issueRegions.length - 1));
      lastIssueCheckResult = null;
      renderIssueCheckResult(null);
      syncUrl();
      renderIssueSummary();
      renderCompareLens(boardRenderCache);
    });
    nodes.clearIssueBtn?.addEventListener("click", () => {
      state.issueRegions = [];
      syncIssueState(-1);
      lastIssueCheckResult = null;
      renderIssueCheckResult(null);
      syncUrl();
      renderIssueSummary();
      renderCompareLens(boardRenderCache);
    });
    nodes.downloadIssueBtn?.addEventListener("click", () => {
      const payload = buildIssueCheckPayload();
      if (!payload) {
        return;
      }
      downloadJsonFile(issuePayloadFilename(payload), payload);
      nodes.issueSummary.textContent = "Issue JSON скачан. Это fallback, если локальный runner не запущен.";
    });
    nodes.runIssueCheckBtn?.addEventListener("click", async () => {
      const payload = buildIssueCheckPayload();
      if (!payload) {
        return;
      }
      nodes.runIssueCheckBtn.disabled = true;
      nodes.issueSummary.textContent = "Oracle issue-runner: сохраняю пакет и запускаю диагностику...";
      try {
        const response = await fetch("http://127.0.0.1:4176/oracle/issues/check", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload)
        });
        const result = await response.json();
        if (!response.ok) {
          throw new Error(result?.error || `HTTP ${response.status}`);
        }
        lastIssueCheckResult = result;
        const layer = result?.diagnosis?.recommended_layer || "unknown";
        const textCount = result?.diagnosis?.text_node_count ?? "n/a";
        const missingFonts = result?.diagnosis?.missing_font_count ?? "n/a";
        let sentToRepair = false;
        try {
          sentToRepair = await sendIssueToRepair(result);
        } catch (queueError) {
          console.warn(queueError);
        }
        nodes.issueSummary.textContent = sentToRepair
          ? `Проверка готова и сразу отправлена на доработку: ${result.status}; layer=${layer}; text nodes=${textCount}; missing fonts=${missingFonts}. Артефакты: ${result.issue_dir}`
          : `Проверка готова: ${result.status}; layer=${layer}; text nodes=${textCount}; missing fonts=${missingFonts}. Артефакты: ${result.issue_dir}`;
        renderIssueCheckResult(result);
      } catch (error) {
        console.warn(error);
        downloadJsonFile(issuePayloadFilename(payload), payload);
        nodes.issueSummary.textContent = "Локальный issue-runner не ответил. Issue JSON скачан; запусти tools/nebula-audit-factory/run-oracle-issue-server.ps1 и повтори.";
      } finally {
        nodes.runIssueCheckBtn.disabled = !state.issueRegions.length;
      }
    });
    nodes.issueResultPanel?.addEventListener("click", async (event) => {
      const button = event.target?.closest?.("[data-issue-action]");
      if (!button || !lastIssueCheckResult) {
        return;
      }
      const action = button.getAttribute("data-issue-action");
      if (action === "set-state") {
        const nextState = button.getAttribute("data-state") || "";
        const queue = lastIssueCheckResult.queue_item || {};
        const issueId = lastIssueCheckResult.issue_id || queue.issue_id || "";
        if (!issueId || !nextState) {
          nodes.issueSummary.textContent = "Не удалось обновить queue state: нет issue_id или target state.";
          return;
        }
        button.disabled = true;
        nodes.issueSummary.textContent = `Oracle queue: перевожу ${issueId} в ${nextState}...`;
        try {
          await setIssueQueueState(lastIssueCheckResult, nextState, `Set from compare-board action ${nextState}`);
          nodes.issueSummary.textContent = `Queue state обновлен: ${issueId} -> ${lastIssueCheckResult.queue_item?.state || nextState}.`;
          renderIssueCheckResult(lastIssueCheckResult);
        } catch (error) {
          console.warn(error);
          nodes.issueSummary.textContent = `Не удалось обновить queue state: ${error.message || error}`;
        } finally {
          button.disabled = false;
        }
        return;
      }
      const text = action === "copy-task"
        ? (lastIssueCheckResult.repair_task_markdown || JSON.stringify(lastIssueCheckResult.repair_task || lastIssueCheckResult, null, 2))
        : action === "copy-caster"
          ? (lastIssueCheckResult.caster_markdown || JSON.stringify(lastIssueCheckResult.caster || lastIssueCheckResult.repair_task?.assistants?.caster || lastIssueCheckResult, null, 2))
        : action === "copy-queue"
          ? JSON.stringify(lastIssueCheckResult.queue_item || lastIssueCheckResult, null, 2)
        : JSON.stringify(lastIssueCheckResult, null, 2);
      try {
        await navigator.clipboard.writeText(text);
        nodes.issueSummary.textContent = action === "copy-task"
          ? "Repair task скопирован. Это готовый bounded brief для правки без повторной интерпретации зоны."
          : action === "copy-caster"
            ? "Caster verdict task скопирован. Caster оценивает и направляет верстальщика; верстальщик исполняет правку."
          : action === "copy-queue"
            ? "Queue item скопирован. Это machine-readable запись для автономной очереди ремонта."
          : "Issue result JSON скопирован вместе с diagnosis, artifacts и repair task.";
      } catch (error) {
        nodes.issueSummary.textContent = "Не удалось скопировать результат проверки. Используй путь к артефактам из панели.";
      }
    });
    nodes.copyIssueBtn?.addEventListener("click", async () => {
      const payload = buildIssuePayload();
      if (!payload) {
        return;
      }
      try {
        await navigator.clipboard.writeText(JSON.stringify(payload, null, 2));
        const countText = payload.regions?.length > 1
          ? `${payload.regions.length} зон`
          : `${payload.grid.columns} / ${payload.grid.rows} / ${payload.region.w}x${payload.region.h}px`;
        nodes.issueSummary.textContent = `Скопировано: ${countText}.`;
      } catch (error) {
        nodes.issueSummary.textContent = "Не удалось скопировать JSON зоны. Скопируй deep-link через кнопку ссылки.";
      }
    });
    nodes.copyAuditBtn?.addEventListener("click", async () => {
      const payload = serializeAudit();
      if (!payload) {
        return;
      }
      try {
        await navigator.clipboard.writeText(JSON.stringify(payload, null, 2));
        nodes.auditSummary.textContent = `MRI audit скопирован: слой ${payload.selectedLayerLabel}, зелёных ${payload.counts.pass}, жёлтых ${payload.counts.in_progress}, красных ${payload.counts.attention}.`;
      } catch {
        nodes.auditSummary.textContent = "Не удалось скопировать аудит.";
      }
    });
    nodes.copyMacroGateBtn?.addEventListener("click", async () => {
      const payload = serializeMacroGate();
      if (!payload) {
        return;
      }
      try {
        await navigator.clipboard.writeText(JSON.stringify(payload, null, 2));
        nodes.macroGateSummary.textContent = `Macro Gate скопирован: pass ${payload.summary.pass}, yellow ${payload.summary.in_progress}, red ${payload.summary.attention}, missing ${payload.summary.missing}.`;
      } catch {
        nodes.macroGateSummary.textContent = "Не удалось скопировать Macro Gate.";
      }
    });
    nodes.copyAuditRouteBtn?.addEventListener("click", async () => {
      const payload = serializeAuditRoute();
      if (!payload) {
        return;
      }
      try {
        await navigator.clipboard.writeText(JSON.stringify(payload, null, 2));
        nodes.auditRoutingSummary.textContent = `MRI маршрут скопирован: layer ${payload.route.layerLabel}, primary ${payload.route.primary?.label || "n/a"} для ${payload.route.targetLabel}.`;
      } catch {
        nodes.auditRoutingSummary.textContent = "Не удалось скопировать verifier routing.";
      }
    });
    nodes.copyAuditHandoffBtn?.addEventListener("click", async () => {
      const payload = buildAuditHandoffPayload();
      if (!payload) {
        return;
      }
      try {
        await navigator.clipboard.writeText(JSON.stringify(payload, null, 2));
        nodes.auditRoutingSummary.textContent = `MRI handoff скопирован: ${payload.route.route.targetLabel}, layer ${payload.route.route.layerLabel}. Следующий verifier: ${payload.route.route.primary?.label || "n/a"}.`;
      } catch {
        nodes.auditRoutingSummary.textContent = "Не удалось скопировать audit handoff.";
      }
    });
    nodes.lockAuditTargetBtn?.addEventListener("click", () => {
      const payload = buildAuditLockPayload();
      if (!payload) {
        nodes.auditRoutingSummary.textContent = "Lock недоступен: target должен быть pass и без незакрытых higher-layer blockers.";
        return;
      }
      const scopeEntry = ensureAuditLockScopeEntry();
      scopeEntry.targets[payload.targetKey] = payload;
      saveAuditLockStore();
      renderAuditSummary();
      nodes.auditRoutingSummary.textContent = `Positive lock сохранён: ${payload.layerLabel} / ${payload.targetLabel}.`;
    });
    nodes.copyLockGateBtn?.addEventListener("click", async () => {
      const payload = buildAuditLockGatePayload();
      if (!payload) {
        return;
      }
      try {
        await navigator.clipboard.writeText(JSON.stringify(payload, null, 2));
        nodes.auditRoutingSummary.textContent = `Regression gate скопирован: affected locks ${payload.regressionGate.affectedLockCount}.`;
      } catch {
        nodes.auditRoutingSummary.textContent = "Не удалось скопировать regression gate.";
      }
    });
    nodes.copyLockFileBtn?.addEventListener("click", async () => {
      const payload = buildCurrentAuditLockFilePayload();
      try {
        await navigator.clipboard.writeText(JSON.stringify(payload, null, 2));
        nodes.auditRoutingSummary.textContent = `Lock file скопирован: ${payload.locks.length} locks для ${payload.page} / ${payload.variant}.`;
      } catch {
        nodes.auditRoutingSummary.textContent = "Не удалось скопировать lock file.";
      }
    });
    nodes.clearAuditLockBtn?.addEventListener("click", () => {
      const route = serializeAuditRoute();
      const target = buildAuditLockTargetDescriptor(route);
      const scopeEntry = currentAuditLockScopeEntry();
      if (!target || !scopeEntry?.targets?.[target.targetKey]) {
        return;
      }
      delete scopeEntry.targets[target.targetKey];
      saveAuditLockStore();
      renderAuditSummary();
      nodes.auditRoutingSummary.textContent = `Positive lock снят: ${target.targetLabel}.`;
    });
    nodes.copyMetricsBtn?.addEventListener("click", async () => {
      const payload = buildCurrentAuditMetricsFilePayload();
      if (!payload) {
        return;
      }
      try {
        await navigator.clipboard.writeText(JSON.stringify(payload, null, 2));
        nodes.auditMetricsSummary.textContent = `Wave 6 metrics file скопирован: families ${Object.keys(payload.metrics?.passesPerFamily || {}).length}, stop-rules ${payload.metrics?.stopRules?.length || 0}.`;
      } catch {
        nodes.auditMetricsSummary.textContent = "Не удалось скопировать Wave 6 metrics.";
      }
    });
    nodes.clearAuditBtn?.addEventListener("click", () => {
      delete auditStore[currentAuditKey()];
      saveAuditStore();
      renderAuditSummary();
      renderCompareLens(boardRenderCache);
    });
    nodes.clearMacroGateBtn?.addEventListener("click", () => {
      clearCurrentMacroGate();
      renderMacroGateSummary();
      renderAuditSummary();
      updateFocusBar();
    });
    bootstrap();
    window.addEventListener("resize", () => renderBoard());
  
