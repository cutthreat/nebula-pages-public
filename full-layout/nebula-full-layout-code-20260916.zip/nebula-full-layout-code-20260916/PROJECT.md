# Nebula Project Passport

## Назначение
Nebula is the Figma-driven static UI / landing workspace for the Neuro reference implementation.

## Stack
- HTML / CSS / JavaScript
- Figma export and browser capture workflow
- Local reference bundles and generated export packages

## Canonical location
- `F:\CodexProjects\confideline-nebula\implementation\nebula-gpt`

## Source of truth
- `F:\CodexProjects\confideline-nebula\implementation\nebula-gpt\VERSTKA_STANDARD.md`
- `F:\CodexProjects\confideline-nebula\implementation\nebula-gpt\NEURO_VERSTKA_PREP.md`
- This `PROJECT.md`

## Local run / verify
- Compare implementation with the local reference bundle.
- Keep screen order and export order aligned.
- Validate screenshots, spacing, and responsive behavior.
- Unified responsive comparison model: `figma-manifest/nebula-unified-responsive-template-graph.v1.json` (15 templates × 5 authored breakpoints × 10 lenses).
- Review navigator: `http://127.0.0.1:4180/nebula-unified-compare.html`.
- Rebuild and verify the model with `node tools/build_nebula_unified_compare_model.mjs` and `node tools/test_nebula_unified_compare_model.mjs`; refresh transport with `node tools/run_nebula_unified_compare_preflight.mjs`, DOM with `node tools/run_nebula_15_template_dom_smoke.mjs`, Split with `node tools/run_nebula_75_split_panel_smoke.mjs`, all lenses with `node tools/run_nebula_750_lens_smoke.mjs`, then verify the three evidence artifacts with `node tools/test_nebula_unified_compare_artifacts.mjs`.

## Config / env
- Keep generated exports under the documented export folders.
- Do not treat archives or packaged bundles as editable source.

## High-risk areas
- Export bundle integrity
- Screen ordering
- Figma manifest / screenshot alignment
- Reference package drift

## Codex scenarios
- Pixel-accurate HTML/CSS/JS implementation.
- Export package validation.
- Manifest and comparison updates.

## Manual checks
- Compare against reference screenshots.
- Check desktop and mobile layout.
- Verify export bundles still validate.
